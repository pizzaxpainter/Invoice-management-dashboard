// This file will always run exactly once at server start. It simply connects to the mongoDb database once.
import { MongoClient, type Db } from 'mongodb';
import process from 'process';
import { enhance } from "$app/forms";
   
const connection_str = 'mongodb+srv://1006230:BdqqPw3L5075zjpY@escinvoiceproject.hmmnzyj.mongodb.net/';
const client = new MongoClient(connection_str);
let db: Db | null = null;

let dbName;

const environment = process.env.NODE_ENV 
console.log(`Environment is: "${environment}"`)
if (environment == "test"){
    dbName= 'invoiceproject_test'
}else{
    dbName = 'invoiceproject_data'
}

try {
    db = client.db(dbName);
    console.log("Successfully connected to database.");
} catch (error) {
    console.error("database connection failed. " + error);
}

async function cleanup() {
    console.log("Closing connection to database...");
    await client.close();
    console.log("Success. Exitting...");
    process.exit();
}

// When program is done
process.on('exit', cleanup)

// This will handle kill commands, such as CTRL+C:
process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);
// process.on('SIGKILL', cleanup);

// This will prevent dirty exit on code-fault crashes:
process.on('uncaughtException', cleanup);










export { db };

import { redirect, type Handle } from '@sveltejs/kit';
import { getUserById } from './store/db';

const unProtectedRoutes = ['/', '/sign-in', '/api/saveFile', '/api/writeFile', '/api/deleteUserFolder'];
const adminOnlyRoutes = ['/sign-up'];
export const handle = async ({ event, request, resolve }) => {

    //======================== START OF TESTING MODE ========================
    //This will automatically log in the user as an admin. pls remove on deploment :3
    //This is useful for testing, as you don't have to set your own cookies before calling APIs.
    //This isn't the best practice though. But eh... time is limited.
    // event.cookies.set('session_id', '123');
    // event.cookies.set('isAdmin', 'true');
    //======================== END OF TESTING MODE ====================================
    const sessionId = event.cookies.get('session_id');
    // console.log('Session ID:', sessionId)
    if (!sessionId && !unProtectedRoutes.includes(event.url.pathname)) {
        throw redirect(303, '/');
    }

    const userInfo = await getUserById(sessionId);
    const currentUser = userInfo;
    if (event.url.pathname == '/sign-in' && currentUser) { //If user goes into /sign-in, but he is logged in already.
        //console.log('3')
        throw redirect(303, '/');
    }
    if (currentUser) {
        event.locals.user = {
            isAuthenticated: true,
            email: currentUser.email,
            id: currentUser.id,
            isAdmin: currentUser.isAdmin
        }
        if (adminOnlyRoutes.includes(event.url.pathname) && !currentUser.isAdmin) {
            throw redirect(303, '/');
        }
    } else {
        if (!unProtectedRoutes.includes(event.url.pathname)) {
            console.log('0');
            throw redirect(303, '/');
        }
    }

    const query = await event.url.searchParams.get('signout');
    //console.log('Query:', query);
    if (query == 'true') {
        
        event.cookies.delete('session_id', { path: '/' });
        event.cookies.delete('isAdmin', { path: '/' });
        throw redirect(303, '/');
    }
    else if (query == null) {
        if (currentUser && event.url.pathname == '/') {
            throw redirect(303, '/protected');
        }}
    return await resolve(event);
};