<script>
    import Input from '$lib/components/Input.svelte';
    import Button from '$lib/components/Button.svelte';
    
    let email = '';
    let password = '';
    let adminRights = false;
    /**
	 * @type {string}
	 */
    let confirmPassword = '';
/**
	 * @type {string | null}
	 */

/**
	 * @param {string} password
	 * @param {string} confirmPassword
	 */


    let error;
</script>
<!-- <form method="POST" class="space-y-5 {$$props.class}">
    <Input label="Email" id="email" name="email" type="email" bind:value={email} />
    <Input label="Password" id="password" name="password" type="password" bind:value={password} />
    <Input
        label="Confirm Password"
        id="confirm-password"
        name="confirm-password"
        type="password"
        bind:value={confirmPassword}
    />
    {#if confirmPassword !== "" && confirmPassword !== password}
        <p class="text-danger">Password not match</p>
    {/if}
    <Button type="submit" disabled="{validatePassword(password, confirmPassword)}">Sign Up</Button>
</form> -->
<form method="POST" class="space-y-5">
    <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control" id="email" name="email" bind:value={email} />
    </div>
    <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" class="form-control" id="password" name="password" bind:value={password} />
    </div>
    <div class="mb-3">
        <label for="confirm-password" class="form-label">Confirm Password</label>
        <input type="password" class="form-control" id="confirm-password" name="confirm-password" bind:value={confirmPassword} />
        {#if confirmPassword !== "" && confirmPassword !== password}
            <p class="text-danger">Password does not match</p>
        {/if}
    </div>
    <div class="mb-3">
        <label class="form-check-label" for="admin-rights">Admin Rights</label>
        <input type="checkbox" class="form-check-input" id="admin-rights" name="admin-rights" bind:checked={adminRights} />
    </div>
    <button type="submit" class="btn btn-primary" disabled="{password !== confirmPassword}" aria-disabled="false">Sign Up</button>
</form>

