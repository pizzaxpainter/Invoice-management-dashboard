<script>
	import { goto } from '$app/navigation';
	import { createEventDispatcher } from 'svelte';
	/**
	 * @type {any}
	 */
	export let user;

	const dispatch = createEventDispatcher();

	const handleSignOutclick = () => {
		user = undefined;
		dispatch('signout', {
			signout: true
		});
		window.location.href = `/?signout=true`;
	};
</script>



{#if user}
	<button on:click={handleSignOutclick} class="btn btn-outline-danger"> Sign out </button>
{/if}
		
