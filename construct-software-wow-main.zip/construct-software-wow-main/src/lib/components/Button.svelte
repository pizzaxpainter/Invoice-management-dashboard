<script>
	export let disabled = false;
</script>

<button 
	class="{disabled == true ? 'bg-indigo-200 hover:bg-grey-700': 'bg-indigo-600 hover:bg-indigo-700 focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500'} btn btn-dark"
>
	<slot />
</button>