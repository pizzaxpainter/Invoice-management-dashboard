import {it,expect} from 'vitest'
import { someVariable } from './vitest'

it('add something',() => {
    const result = someVariable(1)
    expect(result).toBe(1)
})