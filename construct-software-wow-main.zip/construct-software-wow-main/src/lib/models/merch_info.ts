import { db } from './db'
import { ObjectId } from 'mongodb';

const collectionName = 'merch_info';

export class MerchantInfo{
    _id?: ObjectId;
    merchant_name: string | null = "";
    merchant_address: string | null = "";
    merchant_phone: string | null = "";
    merchant_email: string | null = "";
    merchant_fax: string | null = "";
    merchant_website: string | null = "";
    merchant_tax_id: string | null = "";
    merchant_siret: string | null = "";
    merchant_siren: string | null = "";
    abn_number: string | null = "";
    gst_number: string | null = "";
    pan_number: string | null = "";
    vat_number: string | null = "";
}

export const empty_merchant_info: MerchantInfo = {
    merchant_name: null,
    merchant_address: null,
    merchant_phone: null,
    merchant_email: null,
    merchant_fax: null,
    merchant_website: null,
    merchant_tax_id: null,
    merchant_siret: null,
    merchant_siren: null,
    abn_number: null,
    gst_number: null,
    pan_number: null,
    vat_number: null
}

export async function all(): Promise<MerchantInfo[]> { //Find all
    const merch_info_list = await find({});
    return merch_info_list
}

//Finds all queries that matches the query
export async function find(query: any): Promise<MerchantInfo[]> {
    try {
        const collection = db.collection(collectionName);
        const cursor = collection.find(query);
        const merch_info_list: MerchantInfo[] = [];

        while (await cursor.hasNext()) {
            const dbobj: MerchantInfo = await cursor.next() as MerchantInfo; //As long as no one adds weird data, this data will always be of type MerchantInfo.
            merch_info_list.push(dbobj);
        }

        return merch_info_list;

    } catch (error) {
        printError("find", error);
    }
}


async function insertMany(merch_info: MerchantInfo[]) {
    try {
        const collection = db.collection(collectionName);
        await collection.insertMany(merch_info);
    } catch (error) {
        printError("insertMany", error);
    }
}

export async function insertOne(merch_info: MerchantInfo) {
    try {
        const collection = db.collection(collectionName);
        const result = await collection.insertOne(merch_info);
        return {status:'Success', msg: "One merchant info added", id: result.insertedId};
    } catch (error) {
        printError("insertOne", error);
    }
}

export async function isExist(query: any): Promise<boolean> {
    try {
        const collection = db.collection(collectionName);
        const document = await collection.findOne(query)

        if (document === null) {
            return false;
        }
        else {
            return true;
        }
    } catch (error) {
        printError("findOne", error);
    }
}

export async function remove(object_id_string: string){
    try {
        const collection = db.collection(collectionName);
        const object_id = new ObjectId(object_id_string);

        const result = await collection.deleteOne({_id: object_id});
        if (result.deletedCount === 1) return {status:'Success', msg: "Deleted successfully"};
        else return {status:'Warning', msg: "No deletion occured"}; //Idk when this can happen
    } catch (error) {
        printError("remove", error);
    }
}

export async function replace(object_id_string: string, merch_info: MerchantInfo){
    try {
        const collection = db.collection(collectionName);
        const object_id = new ObjectId(object_id_string);
        delete merch_info._id;
        const result = await collection.replaceOne({_id: object_id}, merch_info);
        if (result.modifiedCount === 1) return {status:'Success', msg: "Editted successfully"};
        else return {status:'Warning', msg: "No edit occured"}; //Idk when this can happen either
    } catch (error) {
        printError("remove", error);
    }
}

function printError(cause: string, error: any) {
    const msg = `Attempt for operation "${cause}" failed. Error: ${error}`;
    console.log(msg);
    return {status:'Error', msg: msg}
}

// Converts an object and returns only parameters that match MerchantInfo
export function convertToMerchantInfo(to_convert: any): MerchantInfo {
    if(typeof to_convert !== "object" || to_convert === null){
        return empty_merchant_info
    }

    const converted_object = new MerchantInfo(); //Empty MerchantInfo to return later
    for (const prop in converted_object) {
        if(prop === "_id") continue; //Don't let _id be instanized. Use MongoDB autofeature

        if (prop in to_convert && typeof converted_object[prop as keyof MerchantInfo] === typeof to_convert[prop]) {
            converted_object[prop as keyof MerchantInfo] = to_convert[prop];
            continue;
        }
        //If it reaches here, then the value is never specified. It should be null.
        converted_object[prop as keyof MerchantInfo] = null;
    }
    return converted_object
}

