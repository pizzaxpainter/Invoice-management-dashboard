import {db} from './db'
import { ObjectId } from 'mongodb';

const collectionName = 'invoice';

//In retrosrespect: Make two classes. One class is the type server use to query to db, and the other class is the type that the frontend sends an API with.
//But too late for that now...
export class Invoice {
    _id: ObjectId;
    customer_information: ObjectId | null = null;
    merchant_information: ObjectId | null = null;
    invoice_number: string | null = "";
    invoice_total: number | null = 0;
    invoice_subtotal: number | null = 0;
    gratuity: number | null = 0;
    amount_due: number | null = 0;
    previous_unpaid_balance: number | null = 0;
    discount: number | null = 0;
    taxes: Taxes[] = [new Taxes()];
    service_charge: number | null = 0;
    payment_term: string | null = "";
    purchase_order: string | null = "";
    date: Date | null = new Date();
    due_date: Date | null = new Date();
    service_date: Date | null = new Date();
    service_due_date: Date | null = new Date();
    po_number: string | null = "";
    locale: Locale = new Locale();
    bank_informations: BankInformation = new BankInformation();
    item_lines: ItemLine[] = [new ItemLine()];

    constructor(){} //empty constructor so typescript doesn't auto-intialize
}

class Taxes{
    value: number | null = 0;
    rate: number | null = 0;

    constructor(){} //empty constructor so typescript doesn't auto-intialize
}

class Locale{
    currency: string | null = "";
    language: string | null = "";

    constructor(){} //empty constructor so typescript doesn't auto-intialize
}

class BankInformation{
    account_number: string | null = "";
    iban: string | null = "";
    bsb: string | null = "";
    sort_code: string | null = "";
    vat_number: string | null = "";
    rooting_number: string | null = "";
    swift: string | null = "";

    constructor(){} //empty constructor so typescript doesn't auto-intialize
}

class ItemLine{
    description: string | null = "";
    quantity: number | null = 0;
    amount: number | null = 0;
    unit_price: number | null = 0;
    discount: number | null = 0;
    product_code: string | null = "";
    date_item: string | null = "";
    tax_item: string | null = "";
    tax_rate: number | null = 0;

    constructor(){}
}

// Find all documents in the collection
export async function all(): Promise<Invoice[]> { //Find all
    const invoice_list = await find({});
    return invoice_list
}

//Finds all queries that matches the query
export async function find(query: any): Promise<Invoice[]> {
    try {
        const collection = db.collection(collectionName);
        const cursor = collection.find(query);
        const invoice_list: Invoice[] = [];

        while (await cursor.hasNext()) {
            const dbobj: Invoice = await cursor.next() as Invoice; //As long as no one adds weird data, this data will always be of type Invoice.
            invoice_list.push(dbobj);
        }

        return invoice_list;

    } catch (error) {
        printError("find", error);
    }
}

// Insert multiple Invoice objects into the collection
async function insertMany(invoice: Invoice[]) {
    try {
        const collection = db.collection(collectionName);
        await collection.insertMany(invoice);
    } catch (error) {
        printError("insertMany", error);
    }
}

// Insert one Invoice object into the collection
export async function insertOne(invoice: Invoice) {
    try {
        const collection = db.collection(collectionName);
        const result = await collection.insertOne(invoice);
        return {status:'Success', msg: "One invoice added", _id: result.insertedId};
    } catch (error) {
        printError("insertOne", error);
    }
}

// Check if a document exists in the collection
export async function isExist(query: any): Promise<boolean> {
    try {
        const collection = db.collection(collectionName);
        const document = await collection.findOne(query)

        if (document === null) { // Document does not exist
            return false;
        }
        else { // Document exists
            return true;
        }
    } catch (error) {
        printError("findOne", error);
    }
}

// Remove document with the specified id from the collection
export async function remove(object_id_string: string){
    try {
        const collection = db.collection(collectionName);
        const object_id = new ObjectId(object_id_string);

        const result = await collection.deleteOne({_id: object_id});
        if (result.deletedCount === 1) return {status:'Success', msg: "Deleted successfully"};
        else return {status:'Warning', msg: "No deletion occured"}; //Idk when this can happen
    } catch (error) {
        printError("remove", error);
    }
}

// Replace document with the specified id with the provided Invoice object from the collection
export async function replace(object_id_string: string, invoice: Invoice){
    try {
        const collection = db.collection(collectionName);
        const object_id = new ObjectId(object_id_string);
        delete invoice._id;
        
        const result = await collection.replaceOne({_id: object_id}, invoice);
        if (result.modifiedCount === 1) return {status:'Success', msg: "Editted successfully"};
        else return {status:'Warning', msg: "No edit occured"}; //Idk when this can happen either
    } catch (error) {
        printError("remove", error);
    }
}

function printError(cause: string, error: any) {
    const msg = `Attempt for operation "${cause}" failed. Error: ${error}`;
    console.log(msg);
    return {status:'Error', msg: msg}
}

//Why did I never use Object.assign?
//Because then handling the list of object hard. Or maybe it's possible and I just dumb.
//But the function just converts
export function convertToInvoice(to_convert: any): Invoice{ 
    const converted_object = new Invoice();

    for(const prop in converted_object){
        if(prop === 'customer_information' || prop === 'merchant_information') continue; //We'll not be converting customer_info or merchant_info. We skip.

        const property_value = converted_object[prop as keyof Invoice] //Means that I'm sure prop is a key of Invoice

        // * I'm sorry for ugly code -aurel.
        if(prop in to_convert){ //Check if prop is in to_convert
            if(typeof property_value !== 'object'){
                if(typeof property_value === typeof to_convert[prop]){ //Check valid type
                    //Same type = Valid input. So just set it.
                    converted_object[prop as keyof Invoice] = to_convert[prop]
                }
                else{ //Different type! Set it to null
                    converted_object[prop as keyof Invoice] = null;
                }
            }
            else if(property_value.constructor.name === "Array"){
                if(typeof to_convert[prop] === 'object' && to_convert[prop].constructor.name === "Array"){
                    //Yay to_convert[prop] is also an array. We now create an empty list
                    const empty_list = [];
                    for(const array_elem of to_convert[prop]){ //For every element in to_convert[prop], we'll make it into a valid object
                        const empty_obj = new property_value[0].constructor(); //Make an empty object
                        for(const empty_obj_prop in empty_obj){
                            if(empty_obj_prop in array_elem && typeof empty_obj[empty_obj_prop] === typeof array_elem[empty_obj_prop]){
                                empty_obj[empty_obj_prop] = array_elem[empty_obj_prop]
                            }
                            else{
                                empty_obj[empty_obj_prop] = null
                            }
                        }

                        //Iterate through each empty_obj's value. If all are none, then we'll never push the "filled object"
                        for(const key in empty_obj){
                            if(empty_obj[key] !== null){
                                empty_list.push(empty_obj); //Push the "filled object" to the list.
                                break;
                            }
                        }
                    }
                    converted_object[prop as keyof Invoice] = empty_list; //Set the list as the value.
                }
                else{
                    //to_convert[prop] is not an array. We set the converted object's property as an empty array
                    converted_object[prop as keyof Invoice] = [] as typeof property_value;
                }
            }
            else if(property_value.constructor.name === "Date"){ //Then, it is a date. Due to
                //Check if the given string can be made into a date
                if(!isNaN(Date.parse(to_convert[prop]))){
                    //Then it's a valid date
                    converted_object[prop as keyof Invoice] = new Date(to_convert[prop]);
                }
                else{
                    converted_object[prop as keyof Invoice] = null;
                }
            }
            else{
                //Then it's a single object. We set the converted object's property as the corresponding empty object
                const empty_obj = new property_value.constructor(); //Make an empty object
                for(const empty_obj_prop in empty_obj){ //For every property in this new object
                    if(empty_obj_prop in to_convert[prop] && typeof empty_obj[empty_obj_prop] === typeof to_convert[prop][empty_obj_prop]){ //Check if that property exist in to_convert, and the type is the same.
                        empty_obj[empty_obj_prop] = to_convert[prop][empty_obj_prop]
                    }
                    else{
                        empty_obj[empty_obj_prop] = null
                    }
                }
                converted_object[prop as keyof Invoice] = empty_obj; //Set it to our converted_obj
            }
        }
        else{ //In this case, prop is not in to_convert
            if(typeof property_value !== 'object'){
                //Then it's a primitive value, we can set converted_obj's property value to null
                converted_object[prop as keyof Invoice] = null; //Ignore typescript's error cuz it's drunk as usual
            }
            else if(property_value.constructor.name === "Array"){
                //Then it's an array. We set the converted object's property as an empty array
                converted_object[prop as keyof Invoice] = [] as typeof property_value; //Ignore typescript's error cuz it's drunk again
            }
            else if(property_value.constructor.name === "Date"){
                converted_object[prop as keyof Invoice] = null;
            }
            else{
                //Then it's a single object. We set the converted object's property as the corresponding empty object
                const empty_obj = new property_value.constructor(); //Instantiate a new empty object

                for(const empty_obj_prop in empty_obj){
                    empty_obj[empty_obj_prop] = null //For each property, make it null
                }
                converted_object[prop as keyof Invoice] = empty_obj; //Set it to our converted_obj
            }
        }
    }

    return converted_object;
}