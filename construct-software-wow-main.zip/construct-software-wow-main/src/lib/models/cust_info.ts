import { db } from './db'
import { ObjectId } from 'mongodb';

const collectionName = 'cust_info';

export class CustomerInfo {
    _id?: ObjectId;
    customer_name: string | null = "";
    customer_address: string | null = "";
    customer_email: string | null = "";
    customer_id: string | null = "";
    customer_tax_id: string | null = "";
    customer_mailing_address: string | null = "";
    customer_billing_address: string | null = "";
    customer_shipping_address: string | null = "";
    customer_service_address: string | null = "";
    customer_remittance_address: string | null = "";
    abn_number: string | null = "";
    gst_number: string | null = "";
    pan_number: string | null = "";
    vat_number: string | null = "";
}

export const empty_customer_info: CustomerInfo = {
    customer_name: null,
    customer_address: null,
    customer_email: null,
    customer_id: null,
    customer_tax_id: null,
    customer_mailing_address: null,
    customer_billing_address: null,
    customer_shipping_address: null,
    customer_service_address: null,
    customer_remittance_address: null,
    abn_number: null,
    gst_number: null,
    pan_number: null,
    vat_number: null,
}

// Find all documents in the collection
export async function all(): Promise<CustomerInfo[]> { //Find all
    const cust_info_list = await find({});
    return cust_info_list
}

//Finds all queries that matches the query
export async function find(query: any): Promise<CustomerInfo[]> {
    try {
        const collection = db.collection(collectionName);
        const cursor = collection.find(query);
        const cust_info_list: CustomerInfo[] = [];

        while (await cursor.hasNext()) {
            const dbobj: CustomerInfo = await cursor.next() as CustomerInfo; //As long as no one adds weird data, this data will always be of type CustomerInfo.
            cust_info_list.push(dbobj);
        }

        return cust_info_list;

    } catch (error) {
        printError("find", error);
    }
}

// Insert multiple CustomerInfo objects into the collection
async function insertMany(cust_info: CustomerInfo[]) {
    try {
        const collection = db.collection(collectionName);
        await collection.insertMany(cust_info);
    } catch (error) {
        printError("insertMany", error);
    }
}

// Insert one CustomerInfo object into the collection
export async function insertOne(cust_info: CustomerInfo) {
    try {
        const collection = db.collection(collectionName);
        const result = await collection.insertOne(cust_info);
        return {status:'Success', msg: "One customer info added", id: result.insertedId};
    } catch (error) {
        printError("insertOne", error);
    }
}

// Check if a document exists in the collection
export async function isExist(query: any): Promise<boolean> {
    try {
        const collection = db.collection(collectionName);
        const document = await collection.findOne(query)

        if (document === null) { // Document does not exist
            return false;
        }
        else { // Document exists
            return true;
        }
    } catch (error) {
        printError("findOne", error);
    }
}

// Remove document with the specified id from the collection
export async function remove(object_id_string: string){
    try {
        const collection = db.collection(collectionName);
        const object_id = new ObjectId(object_id_string);

        const result = await collection.deleteOne({_id: object_id});
        if (result.deletedCount === 1) return {status:'Success', msg: "Deleted successfully"};
        else return {status:'Warning', msg: "No deletion occured"}; //Idk when this can happen
    } catch (error) {
        printError("remove", error);
    }
}

// Replace document with the specified id with the provided CustomerInfo object from the collection
export async function replace(object_id_string: string, cust_info: CustomerInfo){
    try {
        const collection = db.collection(collectionName);
        const object_id = new ObjectId(object_id_string);
        delete cust_info._id;
        const result = await collection.replaceOne({_id: object_id}, cust_info);
        if (result.modifiedCount === 1) return {status:'Success', msg: "Editted successfully"};
        else return {status:'Warning', msg: "No edit occured"}; //Idk when this can happen either
    } catch (error) {
        printError("remove", error);
    }
}

function printError(cause: string, error: any) {
    const msg = `Attempt for operation "${cause}" failed. Error: ${error}`;
    console.log(msg);
    return {status:'Error', msg: msg}
}

// Converts an object and returns only parameters that match CustomerInfo
// To "clean up" the object that is passed in from the Front End
export function convertToCustomerInfo(to_convert: any): CustomerInfo {
    if(typeof to_convert !== "object" || to_convert === null){
        return empty_customer_info
    }

    const converted_object = new CustomerInfo(); //Empty CustomerInfo to return later
    for (const prop in converted_object) {
        if(prop === "_id") continue; //Don't let _id be instanized. Use MongoDB autofeature

        if (prop in to_convert && typeof converted_object[prop as keyof CustomerInfo] === typeof to_convert[prop]) {
            converted_object[prop as keyof CustomerInfo] = to_convert[prop];
            continue;
        }
        //If it reaches here, then the value is never specified. It should be null.
        converted_object[prop as keyof CustomerInfo] = null;
    }
    return converted_object
}