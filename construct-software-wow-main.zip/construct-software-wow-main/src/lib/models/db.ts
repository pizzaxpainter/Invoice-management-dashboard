import { db } from "../../hooks.server";

// Collections to check and create
const collectionsToCheck = ['invoice', 'cust_info', 'merch_info', 'filename'];
//If collection doesn't exist, create it first.
for(const collectionName of collectionsToCheck){
    const collectionExists = await db.listCollections({ name: collectionName }).hasNext();
    if(!collectionExists){ //If it doesn't exist...
        await db.createCollection(collectionName);
    }
}

export { db }; //Export because other files accesses here