import { db } from './db'
import { ObjectId } from 'mongodb';

const collectionName = 'filename';

export class Filename{
    _id?: ObjectId;
    invoice_id: ObjectId;
    filename: string;
    fileheader: string;
}

//Finds all queries that matches the query
export async function find(query: any): Promise<Filename[]> {
    try {
        const collection = db.collection(collectionName);
        const cursor = collection.find(query);
        const merch_info_list: Filename[] = [];

        while (await cursor.hasNext()) {
            const dbobj: Filename = await cursor.next() as Filename; //As long as no one adds weird data, this data will always be of type MerchantInfo.
            merch_info_list.push(dbobj);
        }

        return merch_info_list;

    } catch (error) {
        printError("find", error);
    }
}

export async function insertOne(filename_info: Filename) {
    try {
        const collection = db.collection(collectionName);
        const result = await collection.insertOne(filename_info);
        return {status:'Success', msg: "One merchant info added", id: result.insertedId};
    } catch (error) {
        printError("insertOne", error);
    }
}

export async function remove(object_id_string: string){
    try {
        const collection = db.collection(collectionName);
        const object_id = new ObjectId(object_id_string);

        const result = await collection.deleteOne({_id: object_id});
        if (result.deletedCount === 1) return {status:'Success', msg: "Deleted successfully"};
        else return {status:'Warning', msg: "No deletion occured"}; //Idk when this can happen
    } catch (error) {
        printError("remove", error);
    }
}


function printError(cause: string, error: any) {
    const msg = `Attempt for operation "${cause}" failed. Error: ${error}`;
    console.log(msg);
    return {status:'Error', msg: msg}
}