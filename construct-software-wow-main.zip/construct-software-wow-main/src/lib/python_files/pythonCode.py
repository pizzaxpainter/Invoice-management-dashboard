import subprocess
import importlib

# # IDK IF ThIS WORKS
def check_package_installed(package_name):
    try:
        importlib.import_module(package_name)
        return True
    except ImportError:
        return False

def force_install(package_name):
    if check_package_installed(package_name):
        pass
    else:
        try:
            subprocess.run(["pip", "install", package_name, "--upgrade", "--force-reinstall"], check=True)
        except subprocess.CalledProcessError as e:
            pass

force_install("json")
force_install("sys")
force_install("requests")
force_install("os")

import json
import sys
import requests

filename = sys.argv[1]
username = sys.argv[2]

try:
    file = {'file': open('src/lib/python_files/tempFiles/'+username+"/"+filename,"rb")}
except:
    raise Exception("File Is Corrupted:402")


url="https://api.edenai.run/v2/ocr/invoice_parser"
data={"providers": "amazon", 'language':'en'}
try: 
    try:
        headers = {"Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYjBlOGMzMGEtNThjOC00OGYzLWJhNWYtNWQwOGQ3ZTIzMWM4IiwidHlwZSI6ImFwaV90b2tlbiJ9.KOlD48Wh71Rw3BsaYrmQOQmLbhwQqKgFojh7hxTqcDU"}

        # remeber to delete file
        response = requests.post(url, data=data, files=file, headers=headers)


        content_str = response.content.decode('utf-8')

        # Step 2: Parse str to JSON object
        json_object = json.loads(content_str)
        print(content_str)

    except:
        headers = {"Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiMTMzZjE3ZDktMjU5Yi00MDQzLWIzNGEtMjgzOWZkM2VlODdiIiwidHlwZSI6ImFwaV90b2tlbiJ9.opqx1IoncmpYVPDivhS-alo-uZ3GMTNgVx1qvRJ_b2k"}


        # remeber to delete file
        response = requests.post(url, data=data, files=file, headers=headers)


        content_str = response.content.decode('utf-8')

        # Step 2: Parse str to JSON object
        json_object = json.loads(content_str)
        print(content_str)
except:
    raise Exception("Eden API Issue:403")
        
