import { error, redirect } from "@sveltejs/kit"
import customerList from "./sample_customer.json"
import {errorListObject} from "../invoice_upload/InvoiceUploadFunctions"

async function get_customers_function(fetch) {
    const obj = {global_search:""}
    const params = new URLSearchParams(obj).toString()
    
    const response = await fetch(`/api/cust_info?${params}`)
    // console.log("response from cust_info:", response)
    if (response.status == 400) {
        console.log("err is", await response.json())
        console.log("error caught in get_customers_function")
        throw error(421, {
            message: errorListObject[421]
        })
    } else if (response.status == 500) {
        console.log("error is", await response.json())
        console.log("error caught in get_customers_function")
        throw error(430, {
            message: errorListObject[430]
        })
    }
    const responseJSON = await response.json()
    // console.log("... is ",responseJSON.result)
    const customerListFromDb = responseJSON.result
    customerListFromDb.unshift(customerList[0])
    return customerListFromDb
}

export const load = async({fetch}) => {
    try {
        // console.log("customerList are", customerList)
        // fetch from merchant database here. ideally, use a separate function
        const updatedCustomerList = await get_customers_function(fetch)
        return { 
            // customerList: customerList
            customerList: updatedCustomerList 
        };
    } catch (err) {
        console.log("err", err)
        console.log("error caught in edit_customers serverLoad method")
        throw error(err.status,{message: err.body.message})
    }
}

async function post_patch_customer_function(object_info, fetch, method) {
    let response
    if (method == "PATCH") {
        // console.log("object_info is", object_info)
        // return
        response = await fetch("/api/cust_info", {
            method:method,
            body: JSON.stringify({
                obj_id:object_info["_id"],
                editted_obj:object_info,
                add_if_null: false
            })
        })
    } else {
        response = await fetch("/api/cust_info", {
            method:method,
            body: JSON.stringify({
                obj:object_info,
                add_if_null: false
            })
        })
    } 
    if (response.status == 400) {
        console.log("error is", await response.json())
        console.log("error caught in post_patch_customer_function")
        if (method == "PATCH") {
            throw error(432, {
                message: errorListObject[432]
            })
        } else {
            throw error(424, {
                message: errorListObject[424]
            })
        }
    } else if (response.status == 401) {
        const errJson = await response.json()
        console.log(errJson)
        console.log("error caught in post_patch_customer_function")
        throw error(429, {
            message: errJson.msg
        })
    } else if (response.status == 500) {
        console.log("error is", await response.json())
        console.log("error caught in post_patch_customer_function")
        throw error(430, {
            message: errorListObject[430]
        })
    }    
    // let jsonRes = await response.json()   
    // console.log("jsonRes is", jsonRes)
}

async function delete_customer_function(fetch, customerId) {
    const response = await fetch("/api/cust_info", {
        method:"DELETE",
        body: JSON.stringify({
            obj_id:customerId
        })
    })
    if (response.status == 400) {
        console.log("error is", await response.json())
        console.log("error caught in delete_customer_function")
        throw error(427, {
            message: errorListObject[427]
        })
    } else if (response.status == 401) {
        const errJson = await response.json()
        console.log(errJson)
        console.log("error caught in delete_customer_function")
        throw error(429, {
            message: errJson.msg
        })
    } else if (response.status == 500) {
        console.log("error is", await response.json())
        console.log("error caught in delete_customer_function")
        throw error(430, {
            message: errorListObject[430]
        })
    }    
}

export const actions = {
    submitToCustDatabase:async({request, fetch,cookies}) => {
        try {
            console.log("submitToCustDatabase clicked")
            const data = await request.formData()
            // console.log("data is", data)
            const custObject = JSON.parse(data.get("invisible-input"))
            // console.log("custObject is", custObject)
            const fetchMethod = data.get("method-to-db")
            // console.log("fetchMethod is", fetchMethod)
            await post_patch_customer_function(custObject, fetch, fetchMethod)
        } catch (err){
            console.log("error caught in submitToCustDatabase formAction")
            throw error(err.status,{message: err.body.message})
        }
        cookies.set("cookie_mode","edit_customers", {path:'/upload_confirmation'})
        cookies.set("cookie_object","success", {path:'/upload_confirmation'})
        throw redirect(300,'/upload_confirmation')
    },
    deleteInCustDatabase:async({request, fetch, cookies}) => {
        try {
            console.log("deleteInCustDatabase clicked")
            const data = await request.formData()
            const customerId = data.get("customer_id")
            // console.log("merchantId is", customerId)
            await delete_customer_function(fetch,customerId)
        } catch (err){
            console.log("error caught in deleteInCustDatabase formAction")
            throw error(err.status,{message: err.body.message})
        }

        cookies.set("cookie_mode","delete_customer", {path:'/upload_confirmation'})
        cookies.set("cookie_object","success", {path:'/upload_confirmation'})
        throw redirect(300,'/upload_confirmation')
    }
}
