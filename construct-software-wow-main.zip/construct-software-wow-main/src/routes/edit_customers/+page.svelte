<script>
	import { enhance } from "$app/forms";
   
    import NestedDescriptionSubcomponent from "../invoice_upload/edit_confirm_component/NestedDescriptionSubcomponents.svelte"

    function compileDataHandler() {
        if (objectListUpdated[indexOfObject]["customer_name"] == null) {
            alert('Please fill up customer_name');
            return
        } 
        objectListUpdated[indexOfObject]["customer_name"] = objectListUpdated[indexOfObject]["customer_name"].trimStart()
        // console.log(objectListUpdated[indexOfObject])
        if (objectListUpdated[indexOfObject]["customer_name"] == "") {
            alert('Please fill up customer_name');
            return
        }
        if (objectListUpdated[indexOfObject]["customer_address"] == null) {
            alert('Please fill up customer_address');
            return
        } 
        objectListUpdated[indexOfObject]["customer_address"] = objectListUpdated[indexOfObject]["customer_address"].trimStart()
        // console.log(objectListUpdated[indexOfObject])
        if (objectListUpdated[indexOfObject]["customer_address"] == "") {
            alert('Please fill up customer_address');
            return
        }
        // console.log(objectNameList[indexOfObject])
        // console.log("compile button clicked.")
        if (indexOfObject==0) {methodToDb="POST"}
        else {
            methodToDb="PATCH"
            objectListUpdated[indexOfObject]["_id"] = objectNameList[indexOfObject]["id"]
        }
        customerJsonString = JSON.stringify(objectListUpdated[indexOfObject])
        complileButtonClicked = true
    }

    function selectFromListHandler () {
        // console.log("selectFromListHandler called")
        // console.log("value is", this.value)
        indexOfObject = objectNameList.findIndex(obj => obj.id == this.value)
        if (this.value == -1) {
            customerId = ""
            disableDeleteButton = true
        }
        else {
            customerId = this.value
            disableDeleteButton = false
        }
    }

    function groupObjectList(relevantObjectList) {
        const updatedList = relevantObjectList.map(obj => {
            const {_id, ...restOf} = obj
            // console.log("id is", _id,"restOf is", restOf)
            return restOf
        })
        // console.log("updatedList is",updatedList)
        return updatedList
    }

    export let data;

    let customerJsonString=''
    let indexOfObject = 0
    let complileButtonClicked = false
    let methodToDb = ""
    let disableDeleteButton = true
    let customerId = ""
    
    const objectList = data.customerList
    // console.log("data is", customerList)

    const objectNameList = []
    objectList.map(obj => objectNameList.push({
        object_name:obj.customer_name,
        id: obj._id
      }))
    // console.log("objectNameList is", objectNameList)

    const objectListUpdated = groupObjectList(objectList)
    
    // console.log("objectList is", objectList)
    // console.log("objectListUpdated is", objectListUpdated)
      

</script>

<style>
    * {
       /* box-sizing: border-box; */
       padding: 0 10px;
   }
</style>

<h1>Add and Edit Outlets Here!</h1>

{#if !complileButtonClicked}
    <div class="input-group mb-3">
        <label class="input-group-text" for="selectFromList">Options</label>
        <select class="form-select" id="selectFromList" on:change={selectFromListHandler}>
            <option value=-1>Create New Outlet</option>
            {#each objectNameList.slice(1) as objectName}
                <option value={objectName.id}>{objectName.object_name}</option>
            {/each}
        </select>
    </div>
    <hr>
    <div class="form">
        <NestedDescriptionSubcomponent disableInput={false} nestedDescriptionTitle="Outlet Information" 
        nestedDescriptionObject={objectListUpdated[indexOfObject]}></NestedDescriptionSubcomponent>
        <button on:click={compileDataHandler} class="btn btn-primary">Compile Data</button>
    </div>
    <br>
    <form method="POST" action="?/deleteInCustDatabase" use:enhance>
        <input name="customer_id" type="text" id="customer_id" bind:value={customerId} style="display: none;">
        <button class="btn btn-primary" type="submit" disabled={disableDeleteButton}>Delete Outlet</button>
    </form>
{:else}
    <form method="POST" action="?/submitToCustDatabase" use:enhance>
        <input name="invisible-input" type="text" id="invisible-input" bind:value={customerJsonString} style="display: none;">
        <input name="method-to-db" type="text" id="method-to-db" bind:value={methodToDb} style="display: none;">
        <button id="submitToDatabaseButton" type="submit" class="btn btn-primary" >Submit to Database</button>
    </form>
{/if}