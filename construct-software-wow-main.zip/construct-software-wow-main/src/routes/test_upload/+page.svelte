<script lang="ts">
	let file_input: any = undefined;

	async function check() {
		const fileInput = document.getElementById('formFile');
		const file = fileInput.files[0];

		const reader = new FileReader();
		reader.readAsDataURL(file);

		reader.onloadend = async function () {
			const obj = {
				customer_information: { customer_name: 'C', customer_address: 'C' },
				merchant_information: {
					merchant_name: 'B',
					merchant_address: 'B'
				},
				invoice_number: '3edcVFGHYJUNy&UIK',
				date: new Date('7 August 2023'),
				taxes: [{ value: null, rate: null }] as any[],
				item_lines: [] as any[]
			};

			const request_body = {
				obj: obj,
				cust_autoadd: false,
				cust_allownull: false,
				merch_autoadd: false,
				merch_allownull: false,
				img: reader.result
			};

			 console.log(reader.result)

			const response = await fetch('api/invoice', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				body: JSON.stringify(request_body)
			});

			const a = await response.json();

			console.log(a)

			const to_delete = a.result._id

			//=================================
			const query_url = new URLSearchParams({search_mode: 'id', object_id: to_delete}).toString()
			const c = await fetch(`/api/invoice?${query_url}`, {
				method: 'GET'
			})
			// console.log(await c.json())
			//=================================


			const b = await fetch('/api/invoice', {
				method: 'DELETE',
				headers: {
					'Content-Type': 'application/json'
				},
				body: JSON.stringify({obj_id: to_delete})
			})

			console.log(await b.json())

		};
	}
</script>

<div class="mb-3">
	<label for="formFile" class="form-label">Default file input example</label>
	<input class="form-control" type="file" id="formFile" bind:value={file_input} />
</div>

<button on:click={check} class="btn btn-success">Check the file input</button>
