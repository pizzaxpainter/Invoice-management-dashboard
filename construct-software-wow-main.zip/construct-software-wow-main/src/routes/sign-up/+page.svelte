<script>
	import SignUpForm from '$lib/components/SignUpForm.svelte';
	

	/**
	 * @type {any}
	 */
	let error;

</script>

<h1 class="text-2xl font-semibold text-start">Sign Up</h1>
<p class="text-danger">Note: Upon successful registration, will immediately log into the new account</p>
{#if error}
	<p class="text-danger">Error</p>
{/if}
<SignUpForm  />

