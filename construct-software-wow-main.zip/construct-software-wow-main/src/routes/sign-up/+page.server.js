import { redirect } from '@sveltejs/kit';
import { createSession , getUserByEmail} from '../../store/db';
import { dev } from '$app/environment';

export const actions = {
	default: async ({ request, cookies }) => {
		const form = await request.formData();
		const email = form.get('email');
		const password = form.get('password');
		const isAdmin = form.get('admin-rights') === 'on' ? true : false;

		
		if (email === '' || password === ''){
			throw redirect(303, '/sign-up');
		}
		const user = await getUserByEmail(email);

		if(user) { //If user already exists
			throw redirect(303, '/sign-up');
		}

		// console.log('from signup, '+email+ ' isAdmin = ' + isAdmin);

		const { id } = await createSession(email, password, isAdmin);
		if (id){
			cookies.delete('session_id', {path:'/'}); 
		}
		cookies.set('session_id', id, {
			path: '/',
			httpOnly: true,
			sameSite: 'strict',
			secure: !dev,
			maxAge: 60 * 60 * 24 * 7 // one week
		});
		cookies.set('isAdmin', JSON.stringify(isAdmin), {
			path: '/',
			httpOnly: true,
			sameSite: 'strict',
			secure: !dev,
			maxAge: 60 * 60 * 24 * 7
		});
		throw redirect(303, '/protected');
		
	}
};
