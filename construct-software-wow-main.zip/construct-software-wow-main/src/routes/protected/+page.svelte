<script>
    import bg from '$lib/images/background.jpg'
	// @ts-nocheck

	class AppPages {
		/**
		 * @param {any} pageName
		 * @param {any} pagePath
		 */
		constructor(pageName, pagePath) {
			this.pageName = pageName;
			this.pagePath = pagePath;
		}
		// Method
		getPageName() {
			return this.pageName;
		}
		getPathName() {
			return this.pagePath;
		}
	}
	// TODO
	// - get 2nd file to store all these variables.
	
	export let data;


</script>
<head>
    

    <title>Dashboard</title></head>
    <div style="background-image: url({bg});
height: 300vh; background-size: cover;">
<div class="container p-5">
    <div class="card shadow border-light p-2">
            <div class="row p-3">
                <div class="col-12">
                    <h2 class="text-center">Welcome, {data.user.email}!</h2>
                    <hr>
                </div>
            </div>
            <!-- Search Section -->
            <div class="row justify-content-end p-3">
        
                <div class="col-md-6 d-flex justify-content-end">
          
                </div>
            </div>
            <div class="row p-3 flex-xl-row">
                <!-- Left Column (50% width) -->
                <div class="col-xl-6 mb-xl-0 mb-4">
                    <!-- Upload Invoice Card -->
                    <div class="card mb-3">
                        <div class="card-body p-3">
                            <div class="numbers">
                                <p class="text-sm mb-0 text-uppercase font-weight-bold">Upload Invoice</p>
                                <a href="/invoice_upload" class="btn btn-outline-primary mt-3" data-sveltekit-reload="true">Upload Invoice</a>
                            </div>
                            <div class="numbers">
                                <p class="text-sm mb-0 text-uppercase font-weight-bold">Invoice Search</p>
                                <a href="/invoice_search" class="btn btn-outline-primary mt-3" data-sveltekit-reload="true">Invoice Search</a>
                            </div>
                            <div class="numbers">
                                <p class="text-sm mb-0 text-uppercase font-weight-bold">Add/Edit Suppliers</p>
                                <a href="/edit_merchants" class="btn btn-outline-primary mt-3" data-sveltekit-reload="true">Add/Edit Suppliers</a>
                            </div>
                            <div class="numbers">
                              <p class="text-sm mb-0 text-uppercase font-weight-bold">Add/Edit Outlets</p>
                              <a href="/edit_customers" class="btn btn-outline-primary mt-3" data-sveltekit-reload="true">Add/Edit Outlets</a>
                          </div>
                            <div
                                class="icon icon-shape bg-gradient-primary shadow-primary text-center rounded-circle"
                            >
                                <i class="ni ni-money-coins text-lg opacity-10" aria-hidden="true" />
                            </div>
                        </div>
                    </div>    
                        <div class="card-body p-3">
                            <div class="numbers">
                                <p class="text-sm mb-0 text-uppercase font-weight-bold">Need Help?</p>
                                <a href="/help_page"><h5 class="font-weight-bolder">Click here to view the user manual.</h5></a>
                            </div>
                            <div
                                class="icon icon-shape bg-gradient-success shadow-success text-center rounded-circle"
                            >
                                <i class="ni ni-paper-diploma text-lg opacity-10" aria-hidden="true" />
                            </div>
                        </div>
                    </div>
                </div>
    </div>
</div>
    </div>
    