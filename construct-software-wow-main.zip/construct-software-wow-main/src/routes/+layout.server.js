
import { createSession, getUserById } from '../../src/store/db.js';
let isAdmin;
export const load = async ({ cookies, request, locals }) => {
    
    await createSession("master@master.com", "master", true);
    await createSession("user@master.com", "user", false);
    isAdmin = cookies.get('isAdmin')
    
    // bool to check if user is logged in
    let loggedIn = false
    if (cookies.get('session_id')) loggedIn = true
    return {
        isAdmin: isAdmin,
        user: locals.user,
        loggedIn:loggedIn
    };
    
};