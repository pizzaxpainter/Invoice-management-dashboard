import { json } from '@sveltejs/kit';
import * as MercInfo from "$lib/models/merch_info"
import { ObjectId } from 'mongodb';
import { isExist as isExistInvoice } from '$lib/models/invoice.js';


// ? API for querying things in merch_info collection.

// ? KEYWORDS
// * POST == Add one (Add multiple not implemented)
// * PATCH == Edit by Id.
// * GET == Find all users matching query
// * DELETE == Remove by Id.
// ? What will be returned in general
// * Will return an object with 2-3 parameters. Say the returned value is obj
// * The obj.status property will be either "Success", "Warning", "Error"
// "Success" means the operation is successful
// "Warning" means that something might be wrong. Kinda redundant with error but it's more like a "Are u sure u wanna do this"
// "Error" means a fatal mistake (Wrong usage of API, invalid data, etc)
// * The .msg property will be a message of what was successful / what went wrong
// * In case of GET (find), there will be a .result property that will be the result of what you're trying to get

/**
 * * Adds a MerchantInfo document into the db collection of merch_info
 * @param  {Object} {request} - JSON object
 * @param  {MerchantInfo} {request.obj} - MerchantInfo object to add. _id property, invalid properties, and valid properties with wrong variable types will be ignored and set to null.
 * ! Note that this means mistakes in sending the MerchantInfo object (writing merchant_emil instead of merchant_email) may still be queried.
 * @param  {boolean} {request.add_if_null} - Toggle MerchantInfo to be added even if either the name or address is null.
 */
export async function POST({ request }) {
    let json_obj, obj, add_if_null;
    
    try {
        json_obj = await request.json()
        obj = json_obj.obj;
        add_if_null = json_obj.add_if_null;
    } catch (error) {
        return json({ status: "Error", msg: `Error parsing the json body. Error is ${error}` }, { status: 400 })
    }

    if (typeof add_if_null !== 'boolean') return json({ status: "Error", msg: "The add_if_null you provided isn't a boolean value!" }, { status: 400 })
    if (typeof obj !== 'object' || obj === null) return json({ status: "Error", msg: "The object you provided isn't an object" }, { status: 400 })

    const converted_obj = MercInfo.convertToMerchantInfo(obj);

    if ((converted_obj.merchant_address === null || converted_obj.merchant_name === null) && !add_if_null) { //If either name or address is null, and add_if_null is False
        return json({ status: "Warning", msg: "merchant_name or merchant_address is null, but add_if_null is false. Set it to true and send again" }, { status: 400 });
    }

    const query = {
        $and: [
            { merchant_address: converted_obj.merchant_address },
            { merchant_name: converted_obj.merchant_name },
        ],
    };
    if (await MercInfo.isExist(query)) {
        return json({ status: "Error", msg: "Duplicate entry with same merchant name and address exists already." }, { status: 401 });
    }

    const msg = await MercInfo.insertOne(converted_obj);
    return json(msg);
}

/**
 * * Edits a specific MerchantInfo document in the db collection of merch_info
 * @param  {Object} {request} - JSON object
 * @param  {string} {request.obj_id} - Stringified ObjectId that you want to edit
 * @param  {MerchantInfo} {request.editted_obj} - MerchantInfo object to replace the whole document with.
 * So If a property (eg: merchant_name) is not set, then the document's merchant_name will be editted to null
 * @param  {boolean} {request.add_if_null} - Toggle MerchantInfo to be editted into something where the name/address is null
 */
export async function PATCH({ request }) {
    const json_obj = await request.json();
    const id = json_obj.obj_id;
    const editted_obj = json_obj.editted_obj;
    const add_if_null = json_obj.add_if_null;

    if (typeof id !== 'string') return json({ status: "Error", msg: "The id you provided isn't a string!" }, { status: 400 });
    if (!await MercInfo.isExist({ _id: new ObjectId(id) })) return json({ status: "Error", msg: "The id you provided doesn't exist!" }, { status: 400 });
    if (typeof add_if_null !== 'boolean') return json({ status: "Error", msg: "The add_if_null you provided isn't a boolean value!" }, { status: 400 });

    const converted_editted_obj = MercInfo.convertToMerchantInfo(editted_obj);
    if ((converted_editted_obj.merchant_address === null || converted_editted_obj.merchant_name === null) && !add_if_null) { //If either name or address is null, and add_if_null is False
        return json({ status: "Warning", msg: "merchant_name or merchant_address is editted to null, but add_if_null is false. Set it to true and send again" }, { status: 400 });
    }

    const query = {
        $and: [
            { merchant_address: converted_editted_obj.merchant_address },
            { merchant_name: converted_editted_obj.merchant_name },
            { _id: { $ne: new ObjectId(id) } }, //So the editted object doesn't trigger the duplicate flag itself (if we're the name+address we're editting into stays same)
        ],
    };
    if (await MercInfo.isExist(query)) {
        return json({ status: "Error", msg: "Duplicate entry with same merchant name and address exists already." }, { status: 401 });
    }

    const msg = await MercInfo.replace(id, converted_editted_obj);
    if (msg.status === 'Warning') return json(msg, { status: 400 })
    else return json(msg);
}


/**
 * * Deletes a specific MerchantInfo document in the db collection of merch_info
 * @param  {Object} {request} - JSON object
 * @param  {string} {request.obj_id} - Stringified ObjectId that you want to delete
 */
export async function DELETE({ request }) {
    const json_obj = await request.json();
    const id = json_obj.obj_id;

    if (!ObjectId.isValid(id)) return json({ status: "Error", msg: `Invalid object_id given. Detected object_id: ${id}` }, { status: 400 });
    if (!await MercInfo.isExist({ _id: new ObjectId(id) })) return json({ status: "Error", msg: "The id you provided doesn't exist!" }, { status: 400 });

    //Check if there is an invoice linked with this customer_info. If there is, reject the delete request
    const query = { merchant_information: new ObjectId(id) }
    if (await isExistInvoice(query)) return json({ status: "Error", msg: `An invoice that uses this merchant information is found. Can't delete.` }, { status: 401 });


    const msg = await MercInfo.remove(id);
    if (msg.status === 'Warning') return json(msg, { status: 400 })
    else return json(msg);
}

/**
 * * Finds all documents containing a specific phrase
 * @param  {Object} {url} - JSON object
 *      Note that since this is a GET request, a body isn't allowed. Instead, you can do the following:
 *          Say you want to search "duck pte". Create an object. const obj = {global_search: "duck pte"} 
 *          Transform this object into a string. You can do this easily with the following. const params = new URLSearchParams(obj).toString()
 *          Call the API with params embedded into the URL. In this case, you'll do:
 *              await fetch(`/api/merch_info/?${params}`, {
 *                  method: 'GET',
 *                  headers: {
 *                      'Content-Type': 'application/json'
 *                  }
 *              })
 * @param  {string} {url.searchParams.global_search} - String separated by spaces. Case insensitive
 *      !global_search is case insensitive.
 *      If "AA BB" is given, then it will find all documents containing aa in a property, and bb in another property.
 *      If empty string "" is given, then it will return all documents
 * The returned value will be a list of MerchantInfo objects. However, the _id property will contain the stringified version of the document's ObjectId
 */
export async function GET({ url }) {
    const result = await MercInfo.all();
    return json({ status: "Success", msg: `Search done. ${result.length} results found.`, result: result });
}