import { json } from '@sveltejs/kit';
import * as Invoice from "$lib/models/invoice";
import { writeFile, unlink, readFile } from 'fs/promises'
import { convertToCustomerInfo, isExist as isExistCustomer, insertOne as insertOneCustomer, find as findCustomer } from '$lib/models/cust_info';
import { convertToMerchantInfo, isExist as isExistMerchant, insertOne as insertOneMerchant, find as findMerchant } from '$lib/models/merch_info';
import { ObjectId } from 'mongodb';
import { v4 as uuidv4 } from 'uuid';
import * as Filename from "$lib/models/filename"

// ? API for querying things in invoice collection.

// ? KEYWORDS
// * POST == Add one (Add multiple not implemented)
// * PATCH == Edit by Id.
// * GET == Find all users matching query
// * DELETE == Remove by Id.
// ? What will be returned in general
// * Will return an object with 2-3 parameters. Say the returned value is obj
// * The obj.status property will be either "Success", "Warning", "Error"
// "Success" means the operation is successful
// "Warning" means that something might be wrong. Kinda redundant with error but it's more like a "Are u sure u wanna do this"
// "Error" means a fatal mistake (Wrong usage of API, invalid data, etc)
// * The .msg property will be a message of what was successful / what went wrong
// * In case of GET (find), there will be a .result property that will be the result of what you're trying to get

/**
 * * Adds a Invoice document into the db collection of invoice
 * @param  {Object} {request} - JSON object
 * @param  {Invoice} {request.obj} - Invoice object to add. _id property, invalid properties, and valid properties with wrong variable types will be ignored and set to null.
 * ! Note that this means mistakes in sending the Invoice object (writing invoic_number instead of invoice_number) may still be queried.
 * ! customer_info and merchant_info properties are required!
 * @param  {boolean} {request.cust_autoadd} - Toggle customer_info object to be added if it doesn't exist yet.
 * @param  {boolean} {request.cust_allownull} - If cust_autoadd is true, toggles merchant_info to be added even if either the name or address is null.
 * @param  {boolean} {request.merch_autoadd} - Toggle merchant_info object to be added if it doesn't exist yet.
 * @param  {boolean} {request.merch_allownull} - If merch_autoadd is true, toggles merchant_info to be added even if either the name or address is null.
 * @param  {string} {request.img} - The image file in base64 format. To do that, do something like this:
    * const fileInput = document.getElementById('formFile');
            const file = fileInput.files[0];

            const reader = new FileReader();

            reader.onloadend = async function (event) {
                const fileContent = reader.result
                const jsonPayload = { img: fileContent };
                const response = await fetch('api/invoice', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(jsonPayload)
                });
            };

            reader.readAsDataURL(file);
 * 
 * On success, returns a response object. response.json().result will be the JSON object that got added
 * The _id of this returned object will be the document's ObjectId in string format.
 */
// TODO: Race conditions. If customer_info is checked to exist, then someone immediately deletes it before the ObjectID can be fetched, then error.
export async function POST({ request }: { request: Request }) {
    const json_obj = await request.json();
    const obj = json_obj.obj;
    const cust_autoadd = json_obj.cust_autoadd;
    const cust_allownull = json_obj.cust_allownull;
    const merch_autoadd = json_obj.merch_autoadd;
    const merch_allownull = json_obj.merch_allownull;
    const img = json_obj.img;
    let filedata, file_object, filetype, filename, fileheader;

    if (typeof (img) !== 'string') {
        return json({ status: "Error", msg: "The image you provided haven't been converted to a string!" }, { status: 400 });
    }

    //Check filetype
    const valid_files = ['png', 'jpeg', 'jpg', 'pdf'];
    try { //Try to get the filetype
        fileheader = img.split(',')[0]
        filetype = img.split(',')[0].split('/')[1].split(';')[0] //Because one gets data in the form of data:image/png;base64iVBlablablabla. We want the 'png' part
        filedata = img.split(',')[1]

        if (!(valid_files.includes(filetype))) {
            return json({ status: "Error", msg: "Invalid filetype given" }, { status: 401 });
        }

        file_object = Buffer.from(filedata, 'base64')
        filename = `${uuidv4()}.${filetype}`

        await writeFile(`./src/lib/images/temp`, file_object, 'base64'); //Try to write it. If it fails, then it will fail later
        //! Yes, this is bad practice. But the coder didn't know how to handle the errors otherwise
        // Because if I make it a try block down the line, the invoice will be uploaded to db, but I should then throw an error..?
        // But then the invoice data has been uploaded!
    } catch (error) {
        return json({ status: "Error", msg: "File given is of weird format. Unable to parse image/pdf" }, { status: 401 });
    }

    //Make sure the variables are boolean
    if (typeof cust_autoadd !== 'boolean' || typeof cust_allownull !== 'boolean' || typeof merch_autoadd !== 'boolean' || typeof merch_allownull !== 'boolean') {
        return json({ status: "Error", msg: "One of either (cust/merch)_(autoadd/allownull) you provided isn't a boolean value!" }, { status: 400 });
    }

    //Make sure obj is an object
    if (typeof obj !== 'object') {
        return json({ status: "Error", msg: `obj isn't an object! We detect that it is a ${typeof obj}` }, { status: 400 });
    }

    //Check if obj has both customer_information and merchant_information property
    if (!('customer_information' in obj && 'merchant_information' in obj)) {
        return json({ status: "Error", msg: `obj doesn't contain customer_information or merchant_information property.` }, { status: 400 });
    }


    //=== Check if customer_info, customer_name combination exist already ===
    const converted_customer_info = convertToCustomerInfo(obj.customer_information);
    const cust_info_query = {
        $and: [
            { customer_address: converted_customer_info.customer_address },
            { customer_name: converted_customer_info.customer_name },
        ],
    };
    const is_customer_need_to_be_added = !await isExistCustomer(cust_info_query);
    if (is_customer_need_to_be_added) { //Then customer_info doesn't exist yet.
        if (!cust_autoadd) { //If autoadd is false, then we'll throw a warning
            return json({ status: "Warning", msg: "customer_name or customer_address combination doesn't exist, but cust_autoadd is false. Set it to true and send again" }, { status: 400 });
        }
        if ((converted_customer_info.customer_name === null || converted_customer_info.customer_address === null) && !cust_allownull) { //If either is null
            return json({ status: "Warning", msg: "customer_name or customer_address is null, but cust_allownull is false. Set it to true and send again" }, { status: 400 });
        }
    }

    //=== Check if merchant_info, merchant_name combination exist already ===
    const converted_merchant_info = convertToMerchantInfo(obj.merchant_information);
    const merch_info_query = {
        $and: [
            { merchant_address: converted_merchant_info.merchant_address },
            { merchant_name: converted_merchant_info.merchant_name },
        ],
    };
    const is_merchant_need_to_be_added = !await isExistMerchant(merch_info_query)
    if (is_merchant_need_to_be_added) { //Then merchant_info doesn't exist yet.
        if (!merch_autoadd) { //If autoadd is false, then we'll throw a warning
            return json({ status: "Warning", msg: "merchant_name or merchant_address combination doesn't exist, but merch_autoadd is false. Set it to true and send again" }, { status: 400 });
        }
        if ((converted_merchant_info.merchant_name === null || converted_merchant_info.merchant_address === null) && !merch_allownull) { //If either is null
            return json({ status: "Warning", msg: "merchant_name or merchant_address is null, but merch_allownull is false. Set it to true and send again" }, { status: 400 });
        }
    }

    //On verifying that both inputs are valid, we'll insert customer or/and merchant (if necessary)
    if (is_customer_need_to_be_added) {
        const msg_insert_customer = await insertOneCustomer(converted_customer_info);
        if (msg_insert_customer.status !== 'Success') { //Check if adding it is successful
            return json({ status: "Warning", msg: "For some reason, customer_info can't be added. Maybe try again?" }, { status: 400 });
        }
    }
    if (is_merchant_need_to_be_added) {

        const msg_insert_merchant = await insertOneMerchant(converted_merchant_info);
        if (msg_insert_merchant.status !== 'Success') { //Check if adding it is successful
            return json({ status: "Warning", msg: "For some reason, merchant_info can't be added. Maybe try again?" }, { status: 400 });
        }
    }

    //In the end, find the customer and merchant, and get their id
    const arr_inserted_customer = await findCustomer(cust_info_query);
    const customer_info_id = arr_inserted_customer[0]._id;
    const arr_inserted_merchant = await findMerchant(merch_info_query);
    const merchant_info_id = arr_inserted_merchant[0]._id;

    //=== Insert the ids we just made into the converted_obj Invoice object ===
    const converted_obj = Invoice.convertToInvoice(obj);
    converted_obj.customer_information = customer_info_id;
    converted_obj.merchant_information = merchant_info_id;


    //=== Check for duplicate invoices. We shall check if similar invoice with same merchant_info and number exist ===
    //Note that this means that a duplicate invoice may still create a new customer_information before returning an error
    //Not ideal... but eh...
    const query = { $and: [{ merchant_information: converted_obj.merchant_information }, { invoice_number: converted_obj.invoice_number }] }
    if (await Invoice.isExist(query)) {
        return json({ status: "Error", msg: "Duplicate invoice with same merchant information and invoice number detected" }, { status: 401 });
    }

    //Wahoo... and we just add it now.
    const msg: any = await Invoice.insertOne(converted_obj);
    converted_obj._id = msg._id.toJSON();

    //Guaranteed to succeed, because we've tried it above there.
    await writeFile(`./src/lib/images/${filename}`, file_object, 'base64');

    //Store the filename in db
    const filename_for_db = new Filename.Filename();
    filename_for_db.filename = filename;
    filename_for_db.invoice_id = msg._id;
    filename_for_db.fileheader = fileheader;
    await Filename.insertOne(filename_for_db);

    delete msg._id;
    msg.result = converted_obj;
    msg.filename = filename;
    return json(msg);
}

/**
 * * Finds all invoice documents containing a specific phrase. This includes if the invoice contain keywords normally in the CustomerInfo / MerchantInfo section
 * @param  {Object} {url} - JSON object
 *      Note that since this is a GET request, a body isn't allowed. Instead, you can do the following:
 *          Say you want to search "duck pte". Create an object. const obj = {global_search: "duck pte"} 
 *          Transform this object into a string. You can do this easily with the following. const params = new URLSearchParams(obj).toString()
 *          Call the API with params embedded into the URL. In this case, you'll do:
 *              await fetch(`/api/invoice?${params}`, {
 *                  method: 'GET',
 *                  headers: {
 *                      'Content-Type': 'application/json'
 *                  }
 *              })
 * @param  {"all" || "id" || "search"} {url.searchParams.search_mode} - The search_mode used first to determine the type of query. It can be either 'all', 'id', or 'search'. Only 'id' will return the image
 * * Case 1: 'all' (Search all)
 *      Then no other search parameters is required
 * * Case 2: 'id' (Search by object id) Since this will always return a single invoice object, it will also return the image file
 *      The following parameter is needed
 *      @param {string} {url.searchParams.object_id} - This will be the stringified version of the Invoice's object ID you want
 * * Case 3: 'search'
 *      The following parameters are needed
 *      @param {array} {url.searchParams.customer} - Array of stringified object ids of the customers
 *      @param {array} {url.searchParams.merchant} - Array of stringified object ids of the merchants
 *      @param {array} {url.searchParams.user} - Array of stringified object ids of the users. Finds all invoices where the invoice was created by a particular user.
 *      @param {array} {url.searchParams.product} - Array of string. Finds all invoice where this string will appear at least once in the item_list
 *      @param {Date} {url.searchParams.start_date}
 *      @param {Date} {url.searchParams.end_date} - Both are date objects. It will find all invoices with a date X where  start_date <= X < end_date
 *      These queries will be combined with an AND
 *      If any of the queries are left blank, then it will be ignored.
 */
export async function GET({ url }) {

    const search_mode = url.searchParams.get('search_mode');
    let img: string; //To store the image for later on

    //Check if the search_mode is valid
    const valid_search_modes = ['all', 'id', 'search'];
    if (!valid_search_modes.includes(search_mode)) {
        return json({ status: "Error", msg: `Invalid search_mode. Detected search_mode: ${search_mode}` }, { status: 400 });
    }

    let result: any[]; //Not defined as an array of because we'll be editting it later.
    if (search_mode === 'all') {
        result = await Invoice.all();
    }
    else if (search_mode === 'id') {
        const object_id_string = url.searchParams.get('object_id');
        if (!ObjectId.isValid(object_id_string)) {
            return json({ status: "Error", msg: `Invalid object_id given. Detected object_id: ${object_id_string}` }, { status: 400 });
        }
        const object_id = new ObjectId(object_id_string);
        const query = { _id: object_id };
        //Check if it exists
        if (!await Invoice.isExist(query)) {
            return json({ status: "Error", msg: `No invoice object_id of ${object_id_string} found.` }, { status: 401 });
        }
        const get_filename_obj = (await Filename.find({ invoice_id: object_id }))[0] //Get the filename data
        if (get_filename_obj !== undefined) {
            const filename_to_give = get_filename_obj.filename
            const fileheader_to_prepend = get_filename_obj.fileheader

            img = fileheader_to_prepend + (await readFile(`./src/lib/images/${filename_to_give}`, 'base64'))
        } else {
            img = ""
        }
        
        result = await Invoice.find(query);
    }
    else if (search_mode === 'search') {
        //Raw means they're in string
        const customer_raw = url.searchParams.get('customer');
        const merchant_raw = url.searchParams.get('merchant');
        const product = url.searchParams.get('product');
        const start_date_raw = url.searchParams.get('start_date');
        const end_date_raw = url.searchParams.get('end_date');

        const query = { $and: [] as any[] };

        if (customer_raw !== null && customer_raw !== "") {
            const customer_list = customer_raw.split(',');
            const additional_query = { customer_information: { $in: [] as ObjectId[] } };
            for (const customer of customer_list) { //For every customer, check if its a valid object id, then push it to the query
                if (ObjectId.isValid(customer)) {
                    additional_query.customer_information.$in.push(new ObjectId(customer));
                }
            }
            query.$and.push(additional_query) //Push the final query
        }
        if (merchant_raw !== null && merchant_raw !== "") {
            const merchant_list = merchant_raw.split(',');
            const additional_query = { merchant_information: { $in: [] as ObjectId[] } };
            for (const merchant of merchant_list) {
                if (ObjectId.isValid(merchant)) {
                    additional_query.merchant_information.$in.push(new ObjectId(merchant));
                }
            }
            query.$and.push(additional_query);
            console.log(additional_query)
        }
        if (product !== null && product !== "") {
            const product_list = product.split(',');
            const regex_query = product_list.map(term => `(${term})`).join("|"); //regex to check occurence of each element
            const additional_query = { item_lines: { $elemMatch: { description: { $regex: regex_query, $options: 'i' } } } };
            query.$and.push(additional_query);
        }
        if (start_date_raw !== null && end_date_raw !== null && start_date_raw !== "" && end_date_raw !== "") {
            if (!isNaN(Date.parse(start_date_raw)) && !isNaN(Date.parse(end_date_raw))) {
                const additional_query = { date: { $gte: new Date(start_date_raw), $lte: new Date(end_date_raw) } }
                query.$and.push(additional_query);
            }
        }
        result = await Invoice.find(query);
    }

    //Now result contains an array of Invoice objects. We're not done! We'll still have to insert the CustomerInfo and MerchantInfo into EACH Invoice object

    //Get the array of customer_information and merchant_information object IDs, then query them
    // ? Now, as the list of all merchant/cust_info gets very very large, this may become overhead.
    // ? In that case, consider using mongoDB's aggregation pipeline to query all invoices and their merchant/cust_info at once
    // ? At the time of writing the code, the writer of the code simply didn't have enough time to learn all these
    const customer_information_id_array = result.map(invoice_document => (invoice_document.customer_information));
    const merchant_information_id_array = result.map(invoice_document => (invoice_document.merchant_information));
    const customer_information_items_array = await findCustomer({ _id: { $in: customer_information_id_array } });
    const merchant_information_items_array = await findMerchant({ _id: { $in: merchant_information_id_array } });

    //Convert it to a map for quick access
    const customer_information_items_map = new Map();
    customer_information_items_array.forEach((customer_item) => customer_information_items_map.set(customer_item._id.toJSON(), customer_item));
    const merchant_information_items_map = new Map();
    merchant_information_items_array.forEach((merchant_item) => merchant_information_items_map.set(merchant_item._id.toJSON(), merchant_item));

    //Map the contents to the respective value of each Invoice Document in the array
    console.log(result)
    for (const invoice_document of result) {
        invoice_document.customer_information = customer_information_items_map.get(invoice_document.customer_information.toJSON());
        invoice_document.merchant_information = merchant_information_items_map.get(invoice_document.merchant_information.toJSON());
    }

    //If searching by object_id was used, then we'll have to return the image too.
    if (search_mode === "id") {
        return json({ status: "Success", msg: `Search done. ${result.length} results found.`, result: result, img: img });
    }

    return json({ status: "Success", msg: `Search done. ${result.length} results found.`, result: result });
}

/**
 * * Edits a specific Invoice document in the db collection of cust_info
 * @param  {Object} {request} - JSON object
 * @param  {string} {request.obj_id} - Stringified ObjectId that you want to edit
 * @param  {Invoice} {request.editted_obj} - Invoice object to replace the whole document with.
 * So If a property (eg: invoice number) is not set, then the document's invoice number will be editted to null
 */
export async function PATCH({ request }: { request: Request }) {
    const json_obj = await request.json();
    const id = json_obj.obj_id;
    const editted_obj = json_obj.editted_obj;

    if (!ObjectId.isValid(id)) return json({ status: "Error", msg: "The id you provided isn't valid!" }, { status: 400 });
    if (!await Invoice.isExist({ _id: new ObjectId(id) })) return json({ status: "Error", msg: "There is no invoice with the id you provided!" }, { status: 400 });

    //Make sure obj is an object
    if (typeof editted_obj !== 'object') {
        return json({ status: "Error", msg: `obj isn't an object! We detect that it is a ${typeof obj}` }, { status: 400 });
    }

    //Check if obj has both customer_information and merchant_information property
    if (!('customer_information' in editted_obj && 'merchant_information' in editted_obj)) {
        return json({ status: "Error", msg: `obj doesn't contain customer_information or merchant_information property.` }, { status: 400 });
    }

    //=== Check if customer_info, customer_name combination exist already ===
    const converted_customer_info = convertToCustomerInfo(editted_obj.customer_information);
    const cust_info_query = {
        $and: [
            { customer_address: converted_customer_info.customer_address },
            { customer_name: converted_customer_info.customer_name },
        ],
    };
    const is_customer_need_to_be_added = !await isExistCustomer(cust_info_query);
    if (is_customer_need_to_be_added){
        return json({ status: "Error", msg: `Customer information specified doesn't exist in database` }, { status: 400 });
    }

    //=== Check if merchant_info, merchant_name combination exist already ===
    const converted_merchant_info = convertToMerchantInfo(editted_obj.merchant_information);
    const merch_info_query = {
        $and: [
            { merchant_address: converted_merchant_info.merchant_address },
            { merchant_name: converted_merchant_info.merchant_name },
            { _id: { $ne: new ObjectId(id)}}
        ],
    };
    const is_merchant_need_to_be_added = !await isExistMerchant(merch_info_query);
    if (is_merchant_need_to_be_added){
        return json({ status: "Error", msg: `Merchant information specified doesn't exist in database` }, { status: 400 });
    }


    //In the end, find the customer and merchant, and get their id
    const arr_inserted_customer = await findCustomer(cust_info_query);
    const customer_info_id = arr_inserted_customer[0]._id;
    const arr_inserted_merchant = await findMerchant(merch_info_query);
    const merchant_info_id = arr_inserted_merchant[0]._id;

    //=== Insert the ids we just made into the converted_obj Invoice object ===
    const converted_obj = Invoice.convertToInvoice(editted_obj);
    converted_obj.customer_information = customer_info_id;
    converted_obj.merchant_information = merchant_info_id;

    //=== Check for duplicate invoices. We shall check if similar invoice with same merchant_info and number exist ===
    // const query = { $and: [{ merchant_information: converted_obj.merchant_information }, { invoice_number: converted_obj.invoice_number }] }
    const query = {
        $and: [
            { merchant_information: converted_obj.merchant_information },
            { invoice_number: converted_obj.invoice_number },
            { _id: { $ne: new ObjectId(id) } }
        ]
    }
    if (await Invoice.isExist(query)) {
        return json({ status: "Error", msg: "Duplicate invoice with same merchant information and invoice number detected. Can't edit to this." }, { status: 401 });
    }

    //Wahoo... and we just add it now.
    const msg = await Invoice.replace(id, converted_obj);
    if (msg.status === 'Warning') return json(msg, { status: 400 })
    else return json(msg);
}

/**
 * * Deletes a specific Invoice document in the db collection of cust_info
 * @param  {Object} {request} - JSON object
 * @param  {string} {request.obj_id} - Stringified ObjectId that you want to delete
 */
export async function DELETE({ request }: { request: Request }) {
    const json_obj = await request.json();
    const id = json_obj.obj_id;

    if (typeof id !== 'string') return json({ status: "Error", msg: "The id you provided isn't a string!" }, { status: 400 });
    if (!ObjectId.isValid(id)) return json({ status: "Error", msg: `The id you provided isn't a valid ObjectId. Detected: ${id}` }, { status: 400 });
    if (!await Invoice.isExist({ _id: new ObjectId(id) })) return json({ status: "Error", msg: "The id you provided doesn't exist!" }, { status: 400 });

    const get_filename_obj = (await Filename.find({ invoice_id: new ObjectId(id) }))[0] //Get the filename info to remove the file associated with invoice
    const filename_to_delete = get_filename_obj.filename
    await unlink(`./src/lib/images/${filename_to_delete}`) //Remove it from filesystem.
    await Filename.remove(get_filename_obj._id.toJSON()) //Remove filename info entry from database

    const msg = await Invoice.remove(id); //Finally, remove the Invoice object itself

    if (msg.status === 'Warning') return json(msg, { status: 400 })
    else return json(msg);
}