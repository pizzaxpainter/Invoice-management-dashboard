import { json } from '@sveltejs/kit';
import * as CustInfo from "$lib/models/cust_info"
import { ObjectId } from 'mongodb';
import { isExist as isExistInvoice } from '$lib/models/invoice.js';

// ? API for querying things in cust_info collection.

// ? KEYWORDS
// * POST == Add one (Add multiple not implemented)
// * PATCH == Edit by Id.
// * GET == Find all users matching query
// * DELETE == Remove by Id.
// ? What will be returned in general
// * Will return an object with 2-3 parameters. Say the returned value is obj
// * The obj.status property will be either "Success", "Warning", "Error"
// "Success" means the operation is successful
// "Warning" means that something might be wrong. Kinda redundant with error but it's more like a "Are u sure u wanna do this"
// "Error" means a fatal mistake (Wrong usage of API, invalid data, etc)
// * The .msg property will be a message of what was successful / what went wrong
// * In case of GET (find), there will be a .result property that will be the result of what you're trying to get

/**
 * * Adds a CustomerInfo document into the db collection of cust_info
 * @param  {Object} {request} - JSON object
 * @param  {CustomerInfo} {request.obj} - CustomerInfo object to add. _id property, invalid properties, and valid properties with wrong variable types will be ignored and set to null.
 * ! Note that this means mistakes in sending the CustomerInfo object (writing customer_emil instead of customer_email) may still be queried.
 * @param  {boolean} {request.add_if_null} - Toggle CustomerInfo to be added even if either the name or address is null.
 */
export async function POST({ request }: { request: Request }) {
    let json_obj, obj, add_if_null;

    try {
        json_obj = await request.json()
        obj = json_obj.obj;
        add_if_null = json_obj.add_if_null;
    } catch (error) {
        return json({ status: "Error", msg: `Error parsing the json body. Error is ${error}` }, { status: 400 })
    }

    if (typeof add_if_null !== 'boolean') return json({ status: "Error", msg: "The add_if_null you provided isn't a boolean value!" }, { status: 400 })
    if (typeof obj !== 'object' || obj === null) return json({ status: "Error", msg: "The object you provided isn't an object" }, { status: 400 })

    const converted_obj = CustInfo.convertToCustomerInfo(obj);

    if ((converted_obj.customer_address === null || converted_obj.customer_name === null) && !add_if_null) { //If either name or address is null
        return json({ status: "Warning", msg: "customer_name or customer_address is null, but add_if_null is false. Set it to true and send again" }, { status: 400 });
    }

    const query = {
        $and: [
            { customer_address: converted_obj.customer_address },
            { customer_name: converted_obj.customer_name },
        ],
    };
    if (await CustInfo.isExist(query)) {
        return json({ status: "Error", msg: "Duplicate entry with same customer name and address exists already." }, { status: 401 });
    }

    const msg = await CustInfo.insertOne(converted_obj);
    return json(msg);
}

/**
 * * Edits a specific CustomerInfo document in the db collection of cust_info
 * @param  {Object} {request} - JSON object
 * @param  {string} {request.obj_id} - Stringified ObjectId that you want to edit
 * @param  {CustomerInfo} {request.editted_obj} - CustomerInfo object to replace the whole document with.
 * So If a property (eg: customer_name) is not set, then the document's customer_name will be editted to null
 * @param  {boolean} {request.add_if_null} - Toggle CustomerInfo to be editted into something where the name/address is null
 */
export async function PATCH({ request }: { request: Request }) {
    const json_obj = await request.json();
    const id = json_obj.obj_id;
    const editted_obj = json_obj.editted_obj;
    const add_if_null = json_obj.add_if_null;

    if (typeof id !== 'string') return json({ status: "Error", msg: "The id you provided isn't a string!" }, { status: 400 });
    if (!await CustInfo.isExist({ _id: new ObjectId(id) })) return json({ status: "Error", msg: "The id you provided doesn't exist!" }, { status: 400 });
    if (typeof add_if_null !== 'boolean') return json({ status: "Error", msg: "The add_if_null you provided isn't a boolean value!" }, { status: 400 });

    const converted_editted_obj = CustInfo.convertToCustomerInfo(editted_obj);
    if ((converted_editted_obj.customer_address === null || converted_editted_obj.customer_name === null) && !add_if_null) { //If either name or address is null, and add_if_null is False
        return json({ status: "Warning", msg: "customer_name or customer_address is editted to null, but add_if_null is false. Set it to true and send again" }, { status: 400 });
    }

    const query = {
        $and: [
            { customer_address: converted_editted_obj.customer_address },
            { customer_name: converted_editted_obj.customer_name },
            { _id: { $ne: new ObjectId(id) } }, //So the editted object doesn't trigger the duplicate flag itself (if we're the name+address we're editting into stays same)
        ],
    };
    if (await CustInfo.isExist(query)) {
        return json({ status: "Error", msg: "Duplicate entry with same customer name and address exists already." }, { status: 401 });
    }

    const msg = await CustInfo.replace(id, converted_editted_obj);
    if (msg.status === 'Warning') return json(msg, { status: 400 })
    else return json(msg);
}


/**
 * * Deletes a specific CustomerInfo document in the db collection of cust_info
 * @param  {Object} {request} - JSON object
 * @param  {string} {request.obj_id} - Stringified ObjectId that you want to delete
 */
export async function DELETE({ request }: { request: Request }) {
    const json_obj = await request.json();
    const id = json_obj.obj_id;

    if (!ObjectId.isValid(id)) return json({ status: "Error", msg: `Invalid object_id given. Detected object_id: ${id}` }, { status: 400 });
    if (!await CustInfo.isExist({ _id: new ObjectId(id) })) return json({ status: "Error", msg: "The id you provided doesn't exist!" }, { status: 400 });

    //Check if there is an invoice linked with this customer_info. If there is, reject the delete request
    const query = { customer_information: new ObjectId(id) }

    if (await isExistInvoice(query)) return json({ status: "Error", msg: `An invoice that uses this customer information is found. Can't delete.` }, { status: 401 });

    const msg = await CustInfo.remove(id);
    if (msg.status === 'Warning') return json(msg, { status: 400 })
    else return json(msg);
}

/**
 * * Finds all documents containing a specific phrase
 * @param  {Object} {url} - JSON object
 *      Note that since this is a GET request, a body isn't allowed. Instead, you can do the following:
 *          Say you want to search "duck pte". Create an object. const obj = {global_search: "duck pte"} 
 *          Transform this object into a string. You can do this easily with the following. const params = new URLSearchParams(obj).toString()
 *          Call the API with params embedded into the URL. In this case, you'll do:
 *              await fetch(`/api/cust_info/?${params}`, {
 *                  method: 'GET',
 *                  headers: {
 *                      'Content-Type': 'application/json'
 *                  }
 *              })
 * @param  {string} {url.searchParams.global_search} - String separated by spaces. Case insensitive
 *      !global_search is case insensitive.
 *      If "AA BB" is given, then it will find all documents containing aa in a property, and bb in another property.
 *      If empty string "" is given, then it will return all documents
 * The returned value will be a list of CustomerInfo objects. However, the _id property will contain the stringified version of the document's ObjectId
 */
export async function GET({ url }) {
    const result = await CustInfo.all();
    return json({ status: "Success", msg: `Search done. ${result.length} results found.`, result: result });
}