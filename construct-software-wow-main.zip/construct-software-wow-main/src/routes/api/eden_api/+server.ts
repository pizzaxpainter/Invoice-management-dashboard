import { json } from '@sveltejs/kit';
import {PythonShell} from 'python-shell';

export async function POST({request}) {
    try{
        const json_obj = await request.json();
        const user_name = json_obj.username;
        const file_name = json_obj.filename;
        
        const ocrValue = await PythonShell.run('./src/lib/python_files/pythonCode.py',{
            pythonOptions: ['-u'],
            args: [file_name,user_name],
        })
        let output = JSON.parse(ocrValue)
        return json({
            status: 200,
            body: { msg: `OCR return Successfully`,invoice: output.amazon.extracted_data[0]} ,
          });
          
    }catch(err){
        return json({
            status: 403,
            body: { msg: `OCR Error Due To:, ${err}`,invoice:null},
          });
    }
}

