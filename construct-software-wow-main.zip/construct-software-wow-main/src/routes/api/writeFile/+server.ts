import fs from 'fs-extra';
import { json } from '@sveltejs/kit';
import { join } from 'path';

export async function POST({ request }) {
  try {
    const json_obj = await request.json();
    const fileName = json_obj.filename;
    const data = json_obj.data;
    const userName = json_obj.username;
    // Convert the base64 data to a Buffer
    const fileData = Buffer.from(data, 'base64');

    // Construct the file path where you want to save the file
    const userFolder = join('./src/lib/python_files/tempFiles/', userName);
    await fs.ensureDir(userFolder); // Ensure the directory exists, or create it

    const filePath = join(userFolder, fileName);

    // Write the file data to the file
    await fs.writeFile(filePath, fileData);

    return json({
      status: 200,
      body: { msg: `File created successfully: ${fileName}` },
    });
  } catch (error) {
    return json({
      status: 500,
      body: { error: 'Error creating the file.' },
    });
  }
}
