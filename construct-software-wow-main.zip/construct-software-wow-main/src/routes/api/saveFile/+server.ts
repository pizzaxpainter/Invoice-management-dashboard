
import { json } from '@sveltejs/kit';

export async function POST({request}) {

// Function to convert the item_lines array to a CSV string
async function itemLinesToCSV(itemLines,itemHeaders,RealHeaders,everythingElseFields,everythingElseData,i) {
  // Combine all fields into the header
  var headers = RealHeaders

  const csvRows = itemLines.map(item => {
    // Combine the original item_line values
      var returnVal = headers.map(header => `"${item[header] || "null"}"`)
      for (const value of everythingElseData){
          var temp = [];
          for (const val of value){
              if (typeof val == "string"){
                  temp.push(`${val.replace("\n"," ")}`);
              }else{
                  temp.push(`${val}`)
              }
          }
          returnVal = returnVal.concat(temp);
      }
      // console.log(returnVal.join(","))
      return returnVal.join(',');
  });

  for (const value of everythingElseFields){
      itemHeaders = itemHeaders.concat(value)
  }
  const csvHeader = itemHeaders.join(',');

  if (i == 0){
      const ans =  `${csvHeader}\n${csvRows.join('\n')}`;
      return ans
  }else{
      const ans =  `${csvRows.join('\n')}`;
      return ans
  }

}

async function generatetheStarts(data,headerItems=null,realItems=null,headerCust=null,realCust=null,headerMerch=null,realMerch=null,headerTaxes=null,realTaxes=null,headerLocale=null,realLocale=null,headerBank=null,realBank=null,headerOthers=null,realOthers=null,i){
  // Check if "amazon" exists in the data object
    try{
      
      const entry= data
      // console.log(extractedData)
      const allItemLines = [];
      const otherFields = [];
      const otherFieldsData = [];
      const custInfo = [];
      const custInfoData = [];
      const merchInfo = [];
      const merchInfoData = [];
      const bankInfo = [];
      const bankInfoData = [];
      const taxes = [];
      const taxesData = [];
      const locale = [];
      const localeData = [];

      for(const key in entry){
          if (key == "customer_information" ) {
              if (!(headerCust == null )&& realCust != null){
                  if (headerCust == "all" && realCust == "all"){
                      for (const attr in entry[key]){
                          custInfo.push(attr);
                          custInfoData.push(entry[key][attr]);
                      }
                  }else{
                      if (headerCust.length == realCust.length){
                          for (const head of headerCust){
                              custInfo.push(head)
                          }
                          for (const attr of realCust){
                              custInfoData.push(`"${entry[key][attr] || "null"}"`)
                          }
                      }
                  }
              }
          }else if (key == "merchant_information"){
              if (!(headerMerch == null )&& realMerch != null){
                  if (headerMerch == "all" && realMerch == "all"){
                      for (const attr in entry[key]){
                          merchInfo.push(attr);
                          merchInfoData.push(entry[key][attr]);
                      }
                  }else{
                      if (headerMerch.length == realMerch.length){
                          for (const head of headerMerch){
                              merchInfo.push(head)
                          }
                          for (const attr of realMerch){
                              merchInfoData.push(`"${entry[key][attr] || "null"}"`)
                          }
                      }
                  }
              }
          }else if (key == "taxes"){
              if (!(headerTaxes == null )&& realTaxes != null){
                  if (headerTaxes == "all" && realTaxes == "all"){
                      for (const attr in entry[key]){
                          taxes.push(attr);
                          taxesData.push(entry[key][0][attr]);
                      }
                  }else{
                      if (headerTaxes.length == realTaxes.length){
                          for (const head of headerTaxes){
                              taxes.push(head)
                          }
                          for (const attr of realTaxes){
                              taxesData.push(`"${entry[key][0][attr] || "null"}"`)
                          }
                      }
                  }
              }
          }else if (key == "locale"){
              if (!(headerLocale == null )&& realLocale != null){
                  if (headerLocale == "all" && realLocale == "all"){
                      for (const attr in entry[key]){
                          locale.push(attr);
                          localeData.push(entry[key][attr]);
                      }
                  }else{
                      if (headerLocale.length == realLocale.length){
                          for (const head of headerLocale){
                              locale.push(head)
                          }
                          for (const attr of realLocale){
                              localeData.push(`"${entry[key][attr] || "null"}"`)
                          }
                      }
                  }
              }
          }else if (key == "bank_informations"){
              if (!(headerBank == null )&& realBank != null){
                  if (headerBank == "all" && realBank == "all"){
                      for (const attr in entry[key]){
                          bankInfo.push(attr);
                          bankInfoData.push(entry[key][attr]);
                      }
                  }else{
                      if (headerBank.length == realBank.length){
                          for (const head of headerMerch){
                              bankInfo.push(head)
                          }
                          for (const attr of realMerch){
                              bankInfoData.push(`"${entry[key][attr] || "null"}"`)
                          }
                      }
                  }
              }
          }else if (key == "item_lines"){
              const itemLinesData = entry.item_lines;
              if (itemLinesData) {
              allItemLines.push(...itemLinesData);
              }
          }else{
              if (!(headerOthers == null )&& realOthers != null){
                  if (headerOthers == "all" && realOthers == "all"){
                      otherFields.push(key);
                      otherFieldsData.push(entry[key]);
                  }
          }
      }
      if (!(headerOthers == null )&& realOthers != null){
          if (headerOthers == "all" && realOthers == "all"){
          }else{
              if (headerOthers.length == realOthers.length){
                  for (const head of headerOthers){
                      otherFields.push(head)
                  }
                  for (const attr of realOthers){
                      otherFieldsData.push(`"${entry[attr] || "null"}"`)
                  }
              }
          }
      }
      
  }   

      const everythingElseFields = [otherFields,taxes,custInfo,merchInfo,bankInfo,locale]
      const everythingElseData = [otherFieldsData,taxesData,custInfoData,merchInfoData,bankInfoData,localeData]
      // Convert the "item_lines" array to CSV
      const csvContent = await itemLinesToCSV(allItemLines,itemHeaders,realHeaders,everythingElseFields,everythingElseData,i);
  
      // Save the CSV data to a file (replace 'output.csv' with your desired filename)
      console.log('CSV file created successfully.');
      return csvContent
  } catch {
      console.log('Data for "amazon" not found.');
  }

}


async function multiInvoicetoCSV(invoiceArray = null,headerItems=null,realItems=null,headerCust=null,realCust=null,headerMerch=null,realMerch=null,headerTaxes=null,realTaxes=null,headerLocale=null,realLocale=null,headerBank=null,realBank=null,headerOthers=null,realOthers=null){
  if(invoiceArray == null){
      return null
  }else{
      console.log("part1")
      let output = ''
      for (const i in invoiceArray){
              output += await generatetheStarts(invoiceArray[i],headerItems,realItems,headerCust,realCust,headerMerch,realMerch,headerTaxes,realTaxes,headerLocale,realLocale,headerBank,realBank,headerOthers,realOthers,i)
              output += "\n"
          }
          return output
      }
  
  }
const itemHeaders = ["CategoryName","ItemNo","ItemName","ItemDescription","UOM","Qty","CostPrice"];
const realHeaders = ["catName","product_code","description","description","quantityUOM","quantity","unit_price"]

// generatetheSampleFormat(data)
// main part 
    try{
        const json_obj = await request.json();
        const strings = json_obj.json_array
      return json({status:200,csvSTRING: await multiInvoicetoCSV(strings,itemHeaders,realHeaders),})
    } catch (error) {
        return json({
          status: 500,
          body: { error: 'Error creating the file.' },
        });
  
  }
}

