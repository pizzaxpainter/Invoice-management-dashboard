import fs from 'fs-extra';
import { json } from '@sveltejs/kit';
import { join } from 'path';

export async function POST({ request }) {
  try {
    const json_obj = await request.json();
    const userName = json_obj.username;
    // Check if the "userName" folder exists before deleting it
    const userFolder = join('./src/lib/python_files/tempFiles/', userName);
    if (await fs.pathExists(userFolder)) {
      await fs.remove(userFolder); // Use fs.remove() to delete the folder recursively

      return json({ status: 200, body: { msg: 'Folder deleted successfully.' } });
    } else {
      return json({ status: 404, body: { error: 'Folder not found.' } });
    }
  } catch (error) {
    return json({ status: 500, body: { error: 'Error deleting the folder.' } });
  }
}
