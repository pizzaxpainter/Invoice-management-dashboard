<script>
	export let data;
</script>

{#if data.user}
	<h1 class="text-2xl text-center">Hi, You are already logged in</h1>
{:else}
	<h1 class="text-2xl text-center">Hi, login/register to get started</h1>
{/if}
