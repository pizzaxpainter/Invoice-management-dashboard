<script>
    import {page} from "$app/stores"
    import NavigationSubcomponent from "./upload_confirmation/NavigationSubcomponent.svelte"
    
    export let data
</script>

<h1> {$page.error.message}</h1> 
<hr>
{#if data.loggedIn}
    <NavigationSubcomponent></NavigationSubcomponent>
{/if}
