<script>
	let a = 'Bobby';
	let b = 'Smith';
	let total = 0;

	async function search_wahoo() {
		const customer_info = {};
		customer_info.customer_name = "I'm a new name yay! 7yhJU&YTg";
		customer_info.customer_address = "I'm a new address yay! df%Tghn*91";
		customer_info._id = '64cbe0c5629dfc83f9b67097';

		const cust_edit_request = {
			obj_id: '64cbe0c3469dfc83f9b67097',
			editted_obj: customer_info,
			add_if_null: false
		};

		const query = {search_mode: "all"}
		const url_params = new URLSearchParams(query).toString()
		const response = await fetch(`api/invoice?${url_params}`, {
			method: 'GET',
		});

		console.log(await response.json());

	}
</script>

<input type="input" bind:value={a} />
<input type="input" bind:value={b} />
{total}

<button on:click={search_wahoo} class="btn btn-danger">Submit the query</button>
