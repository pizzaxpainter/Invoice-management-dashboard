<script lang="ts">
	// @ts-nocheck

	class AppPages {
		/**
		 * @param {any} pageName
		 * @param {any} pagePath
		 */
		constructor(pageName, pagePath) {
			this.pageName = pageName;
			this.pagePath = pagePath;
		}
		// Method
		getPageName() {
			return this.pageName;
		}
		getPathName() {
			return this.pagePath;
		}
	}
	// TODO
	// - get 2nd file to store all these variables.
	
	
	import Navigation from '$lib/components/Navigation.svelte';
	import { goto } from '$app/navigation';
	import { getUserById } from '../store/db.js';

	export let data;


	/**
	 * @param {{ detail: { signout: any; }; }} event
	 */
	async function handleSignOut(event) {
		const status = event.detail.signout;
		await goto(`/?signout=${status}`);
	}
  // TODO
  // - get 2nd file to store all these variables.
  export let appName = "Dashboard";
  export let appPagesList = [];
  appPagesList.push(new AppPages("Invoice Upload", "/invoice_upload"));
  appPagesList.push(new AppPages("Invoice Search", "/invoice_search"));
  appPagesList.push(new AppPages("Add/Edit Suppliers", "/edit_merchants"));
  appPagesList.push(new AppPages("Add/Edit Outlets", "/edit_customers"));

</script>

<nav class="navbar navbar-expand-lg bg-dark navbar-dark">
	<div class="container-fluid">
		<a class="navbar-brand" href="/protected" data-sveltekit-reload="true">{appName}</a>

		<button
			class="navbar-toggler"
			type="button"
			data-bs-toggle="collapse"
			data-bs-target="#navbarNavAltMarkup"
			aria-controls="navbarNavAltMarkup"
			aria-expanded="false"
			aria-label="Toggle navigation"
		>
			<span class="navbar-toggler-icon" />
		</button>
		<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
			{#if data.user}
				<div class="navbar-nav">
					{#each appPagesList as appPages}
						<!-- TOFIX: manipulate the bool value of reload to be false if you are already on the current page. -->
						<a class="nav-link" href={appPages.getPathName()} data-sveltekit-reload="true"
							>{appPages.getPageName()}</a
						>
					{/each}
					{#if data.isAdmin === 'true'}
						<a href="/sign-up" class="nav-link"> Sign up </a>
					{/if}
					<Navigation user={data.user} on:signout={handleSignOut} />
				</div>
			{:else}
				<div class="navbar-nav">
					<a href="/sign-in" class="nav-link"> Sign in </a>
				</div>
			{/if}
		</div>
	</div>
</nav>

<div class="app">

	  <div class="container mx-auto mt-8 antialiased">
		  <div class="container p-5">
			  <div class="card shadow border-light p-2">
		  <slot />
			  </div>
		  </div>
	  </div>

  </div>