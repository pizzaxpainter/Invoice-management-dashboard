<script>
	import SignInForm from '$lib/components/SignInForm.svelte';

	 /** @type {import('./$types').ActionData} */
	 export let form;
	
</script>
<svelte:head>
  <title>Login</title>
  <meta name="description" content="About this app" />
</svelte:head>
<h1 class="text-2xl font-semibold text-start">Sign In</h1>
{#if form?.incorrect}
	<p class="text-danger">Invalid email/password</p>
{/if}
<SignInForm />
