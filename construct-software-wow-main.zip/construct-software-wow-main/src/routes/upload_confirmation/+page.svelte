<script>
    import NavigationSubcomponent from './NavigationSubcomponent.svelte';
    // import {submitDatabaseButtonClicked,submitOcrButtonClicked,renderSubmitButton} from "../stores"
    import 'bootstrap/dist/css/bootstrap.css';

    export let data;
    
    const allowInvoiceNavigation = ["invoice_upload", "invoice_search/invoice/slugs"].includes(data.loaded_mode)
    
    let invoiceNavigation = "/invoice_search/invoice/"+data.loaded_object
</script>

{#if data.loaded_object && allowInvoiceNavigation}
    <h1>Invoice Submitted</h1>
    <button><a href={invoiceNavigation}>Check out your recently uploaded invoice!</a></button>
{:else if data.loaded_mode=="edit_merchants"}
    <h1>Supplier has been uploaded</h1>
{:else if data.loaded_mode=="edit_customers"}
    <h1>Outlet has been uploaded</h1>
{:else if data.loaded_mode=="delete_merchant"}
    <h1>Supplier has been deleted</h1>
{:else if data.loaded_mode=="delete_customer"}
    <h1>Outlet has been deleted</h1>
{:else if data.loaded_mode=="delete_invoice"}
    <h1>Invoice has been deleted</h1>
{:else}
    <h1>No uploads detected.</h1>
{/if}
<hr>
<NavigationSubcomponent></NavigationSubcomponent>
