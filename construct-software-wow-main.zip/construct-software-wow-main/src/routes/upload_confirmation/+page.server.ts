export function load({ cookies }) {
	const cookieObject = cookies.get('cookie_object');
	const cookieMode = cookies.get('cookie_mode')
	cookies.set("cookie_object","", {path:'/upload_confirmation'})
	cookies.set("cookie_mode","", {path:'/upload_confirmation'})
	let loaded_object
	let loaded_mode
	// console.log("cookieObject is", cookieObject)
	// console.log("cookieMode is", cookieMode)

	const modeList = ["invoice_upload","edit_merchants", "edit_customers", "invoice_search/invoice/slugs",
						"delete_merchant", "delete_customer", "delete_invoice"]
	if (modeList.includes(cookieMode)) {
		loaded_object = cookieObject
		loaded_mode = cookieMode
	} 
	// console.log("loaded_object is",loaded_object)

	return {
		loaded_object:loaded_object,
		loaded_mode:loaded_mode

	};
}