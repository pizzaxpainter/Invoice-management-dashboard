<h2>Navigation to other pages</h2>
<button class="btn btn-outline-primary"><a href="/protected" data-sveltekit-reload>Dashboard</a></button>
<button class="btn btn-outline-primary"><a href="/invoice_upload" data-sveltekit-reload>Invoice Upload</a></button>
<button class="btn btn-outline-primary"><a href="/invoice_search" data-sveltekit-reload>Invoice Search</a></button>
<button class="btn btn-outline-primary"><a href="/edit_merchants" data-sveltekit-reload>Add/Edit Suppliers</a></button>
<button class="btn btn-outline-primary"><a href="/edit_customers" data-sveltekit-reload>Add/Edit Outlets</a></button>
