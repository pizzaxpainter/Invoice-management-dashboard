<script>
	import bg from '$lib/images/background.jpg' 
</script>


<div style="background-image: url({bg});
height: 300vh; background-size: cover;">
    <div class="container p-5">
        <div class="card shadow border-light p-2">
            <h2>Help Section</h2>
            
            <br>
            <h3>User Manual</h3>
            <p class="p-1">
				This user manual is intended to provide a brief overview of the features of the application and how to use them.
            </p>
			<br>
			<hr>
			<h3>Login Page</h3>
			<p class="p-1">
				The login page is the first page that you will see when you open the application. You will be asked to enter your username and password. To protect your data, the "Sign Up" feature can only be accessed after you login to add new members to the application.
			</p>
			<br>
			<hr>
			<h3>Sign Up Page</h3>
			<p class="p-1">
				The sign up page allows you to add new members to the application. You can add a new member by entering a new username and password after clicking on the "Sign Up" button.
			</p>
			<br>
			<hr>
			<h3>Dashboard</h3>
			<p class="p-1">
				The dashboard is the main page of the application that you will view after signing into the website. The dashboard can be easily accessed from any page on the app by simply clicking on the "Dashboard" text at the left most corner of the navigation bar at the top of the page. 
			</p>
			<p>
				The Dashboard contains buttons that allow you to access the essential features of the webapp in one click. You can upload an invoice or search for an invoice that you have uploaded using the buttons on the dashboard. 
			</p>
			<p>
				You can also access this user manual by clicking the link under the "Need Help?" section.
			</p>
			<br>
			<hr>
			<h3>Invoice Upload</h3>
			<p class="p-1">
				The invoice upload page allows you to upload an invoice to the webapp. You can upload an invoice by clicking on the "Choose File" button and selecting the invoice file from your computer.
			</p>
			<h3>Invoice Search</h3>
			<p class="p-1">
				This page can be accessed from the dashboard buttons and from the navigation bar. This is a general search page that allows you to search for Supplier names, Product names and Outlet names that can be filtered using a date range. 

				After filling up the desired field(s), click on the blue ‘search button’ below to view the search results that are displayed below the form. 

				If the details are valid, the appropriate invoice(s) will be listed. You can view the invoice(s) by clicking on the grey button with the ID of your desired invoice. 

				You will be directed to a page with the invoice details. (Continued in the next sections)
			<br>
			<hr>
			<h3>Add/ Edit Suppliers</h3>
			<p class="p-1">
			This page can be accessed from the dashboard buttons and from the navigation bar. 
			</p>
			<p>
			Upon clicking the “add/edit suppliers” button you will be directed to a page with a “supplier information” form. This form allows you to enter all necessary details about the new supplier that you want to add. 
			</p>
			<p>
			You can also access and view previously added supplier information by clicking on the “option” drop-down feature above the form.
			</p>
			<p>
			After completing the form, click on the “compile data” button to save your changes and add the supplier information to the database. 
			</p>
			<p>
			You will be directed to another page where you should click on the “submit to Database” button to further save your changes to the database. 
			</p>
			<br>
			<hr>
			<h3>Add/ Edit Outlets</h3>
			<p class="p-1">
			This page can be accessed from the dashboard buttons as well as from the navigation bar. 
			</p>
			<p>
			Upon clicking the “add/edit outlets” button you will be directed to a page with a “outlet information” form. This form allows you to enter all necessary details about the new outlet that you want to add. 
			</p>
			<p>
			You can also access and view previously added outlet information by clicking on the “option” drop-down feature above the form. 
			</p>
			<p>
			After completing the form, click on the “compile data” button to save your changes and add the outlet information to the database. 
			</p>
			<p>
			You will be directed to another page where you should click on the “submit to Database” button to further save your changes to the database. 
			</p>
        </div>
    </div>
</div>
