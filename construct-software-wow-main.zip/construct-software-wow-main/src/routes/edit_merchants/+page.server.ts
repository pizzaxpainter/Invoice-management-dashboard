import { error, redirect } from "@sveltejs/kit"
import merchantList from "./sample_merchant.json"
import {errorListObject} from "../invoice_upload/InvoiceUploadFunctions"

async function get_merchants_function(fetch) {
    const obj = {global_search:""}
    const params = new URLSearchParams(obj).toString()
    
    const response = await fetch(`/api/merch_info?${params}`)
    // console.log("response from merch_info:", response)
    if (response.status == 400) {
        console.log("err is", await response.json())
        console.log("error caught in get_merchants_function")
        throw error(422, {
            message: errorListObject[422]
        })
    } else if (response.status == 500) {
        console.log("error is", await response.json())
        console.log("error caught in get_merchants_function")
        throw error(430, {
            message: errorListObject[430]
        })
    }
    const responseJSON = await response.json()
    // console.log("... is ",responseJSON.result)
    const merchantListFromDb = responseJSON.result
    merchantListFromDb.unshift(merchantList[0])
    return merchantListFromDb  
}

export const load = async({fetch}) => {
    try {
        // console.log("merchantList are", merchantList)
        // fetch from merchant database here. ideally, use a separate function
        const updatedMerchantList = await get_merchants_function(fetch)
        return { 
            // merchantList: merchantList
            merchantList: updatedMerchantList 
        };
    } catch (err) {
        console.log("err", err)
        console.log("error caught in edit_merchants serverLoad method")
        throw error(err.status,{message: err.body.message})
    }
}

async function post_patch_merchant_function(object_info, fetch, method) {
    let response
    if (method == "PATCH") {
        // console.log("object_info is", object_info)
        // return
        response = await fetch("/api/merch_info", {
            method:method,
            body: JSON.stringify({
                obj_id:object_info["_id"],
                editted_obj:object_info,
                add_if_null: false
            })
        })
    } else {
        response = await fetch("/api/merch_info", {
            method:method,
            body: JSON.stringify({
                obj:object_info,
                add_if_null: false
            })
        })
    }
    if (response.status == 400) {
        console.log("error is", await response.json())
        console.log("error caught in post_patch_merchant_function")
        if (method == "PATCH") {
            throw error(433, {
                message: errorListObject[433]
            })
        } else {
            throw error(425, {
                message: errorListObject[425]
            })
        }
    } else if (response.status == 401) {
        const errJson = await response.json()
        console.log(errJson)
        console.log("error caught in post_patch_merchant_function")
        throw error(429, {
            message: errJson.msg
        })
    } else if (response.status == 500) {
        console.log("error is", await response.json())
        console.log("error caught in post_patch_merchant_function")
        throw error(430, {
            message: errorListObject[430]
        })
    }    
    // let jsonRes = await response.json()
    // console.log("jsonRes is", jsonRes)
}

async function delete_merchant_function(fetch, merchantId) {
    const response = await fetch("/api/merch_info", {
        method:"DELETE",
        body: JSON.stringify({
            obj_id:merchantId
        })
    })
    if (response.status == 400) {
        console.log("error is", await response.json())
        console.log("error caught in delete_merchant_function")
        throw error(428, {
            message: errorListObject[428]
        })
    } else if (response.status == 401) {
        const errJson = await response.json()
        console.log(errJson)
        console.log("error caught in delete_merchant_function")
        throw error(429, {
            message: errJson.msg
        })
    } else if (response.status == 500) {
        console.log("error is", await response.json())
        console.log("error caught in delete_merchant_function")
        throw error(430, {
            message: errorListObject[430]
        })
    }    
}

export const actions = {
    submitToMerchDatabase:async({request, fetch, cookies}) => {
        try {
            console.log("submitToMerchDatabase clicked")
            const data = await request.formData()
            // console.log("data is", data)
            const custObject = JSON.parse(data.get("invisible-input"))
            // console.log("custObject is", custObject)
            const fetchMethod = data.get("method-to-db")
            // console.log("fetchMethod is", fetchMethod)
            await post_patch_merchant_function(custObject, fetch, fetchMethod)
        } catch (err){
            console.log("error caught in submitToMerchDatabase formAction")
            throw error(err.status,{message: err.body.message})
        }
        cookies.set("cookie_mode","edit_merchants", {path:'/upload_confirmation'})
        cookies.set("cookie_object","success", {path:'/upload_confirmation'})
        throw redirect(300,'/upload_confirmation')
    }, 
    deleteInMerchDatabase:async({request, fetch, cookies}) => {
        try {
            console.log("deleteInMerchDatabase clicked")
            const data = await request.formData()
            const merchantId = data.get("merchant_id")
            // console.log("merchantId is", merchantId)
            await delete_merchant_function(fetch,merchantId)
        } catch (err){
            console.log("error caught in deleteInMerchDatabase formAction")
            throw error(err.status,{message: err.body.message})
        }

        cookies.set("cookie_mode","delete_merchant", {path:'/upload_confirmation'})
        cookies.set("cookie_object","success", {path:'/upload_confirmation'})
        throw redirect(300,'/upload_confirmation')
    }
}
