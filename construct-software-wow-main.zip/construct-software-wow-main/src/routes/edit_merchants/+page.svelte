<script>
    import { enhance } from "$app/forms";
    
    import NestedDescriptionSubcomponent from "../invoice_upload/edit_confirm_component/NestedDescriptionSubcomponents.svelte"

    function compileDataHandler() {
        if (objectListUpdated[indexOfObject]["merchant_name"] == null) {
            alert('Please fill up merchant_name');
            return
        } 
        objectListUpdated[indexOfObject]["merchant_name"] = objectListUpdated[indexOfObject]["merchant_name"].trimStart()
        // console.log(objectListUpdated[indexOfObject])
        if (objectListUpdated[indexOfObject]["merchant_name"] == "") {
            alert('Please fill up merchant_name');
            return
        }
        if (objectListUpdated[indexOfObject]["merchant_address"] == null) {
            alert('Please fill up merchant_address');
            return
        } 
        objectListUpdated[indexOfObject]["merchant_address"] = objectListUpdated[indexOfObject]["merchant_address"].trimStart()
        // console.log(objectListUpdated[indexOfObject])
        if (objectListUpdated[indexOfObject]["merchant_address"] == "") {
            alert('Please fill up merchant_address');
            return
        }
        // console.log(objectNameList[indexOfObject])
        // console.log("compile button clicked.")
        if (indexOfObject==0) {methodToDb="POST"}
        else {
            methodToDb="PATCH"
            objectListUpdated[indexOfObject]["_id"] = objectNameList[indexOfObject]["id"]
        }
        merchantJsonString = JSON.stringify(objectListUpdated[indexOfObject])
        complileButtonClicked = true
    }

    function selectFromListHandler () {
        // console.log("selectFromListHandler called")
        // console.log("value is", this.value)
        indexOfObject = objectNameList.findIndex(obj => obj.id == this.value)
        if (this.value == -1) {
            merchantId = ""
            disableDeleteButton = true
        }
        else {
            merchantId = this.value
            disableDeleteButton = false
        }
    }

    function groupObjectList(relevantObjectList) {
        const updatedList = relevantObjectList.map(obj => {
            const {_id, ...restOf} = obj
            // console.log("id is", _id,"restOf is", restOf)
            return restOf
        })
        // console.log("updatedList is",updatedList)
        return updatedList
    }

    export let data;
    
    let merchantJsonString=''
    let indexOfObject = 0
    let complileButtonClicked = false
    let methodToDb = ""
    let disableDeleteButton = true
    let merchantId = ""

    const objectList = data.merchantList
    // console.log("data is", merchantList)

    const objectNameList = []
    objectList.map(obj => objectNameList.push({
        object_name:obj.merchant_name,
        id: obj._id
      }))
    // console.log("objectNameList is", objectNameList)

    const objectListUpdated = groupObjectList(objectList)

    // console.log("objectList is", objectList)
    // console.log("objectListUpdated is", objectListUpdated)
      

</script>

<style>
    * {
       /* box-sizing: border-box; */
       padding: 0 10px;
   }
</style>

<h1>Add and Edit Suppliers Here!</h1>

{#if !complileButtonClicked}
    <div class="input-group mb-3">
        <label class="input-group-text" for="selectFromList">Options</label>
        <select class="form-select" id="selectFromList" on:change={selectFromListHandler}>
            <option value=-1>Create New Supplier</option>
            {#each objectNameList.slice(1) as objectName}
                <option value={objectName.id}>{objectName.object_name}</option>
            {/each}
        </select>
    </div>
    <hr>
    <div class="form">
        <NestedDescriptionSubcomponent disableInput={false} nestedDescriptionTitle="Supplier Information" 
        nestedDescriptionObject={objectListUpdated[indexOfObject]}></NestedDescriptionSubcomponent>
        <button on:click={compileDataHandler} class="btn btn-primary">Compile Data</button>
    </div>
    <br>
    <form method="POST" action="?/deleteInMerchDatabase" use:enhance>
        <input name="merchant_id" type="text" id="merchant_id" bind:value={merchantId} style="display: none;">
        <button class="btn btn-primary" type="submit" disabled={disableDeleteButton}>Delete Supplier</button>
    </form>
{:else}
    <form method="POST" action="?/submitToMerchDatabase" use:enhance>
        <input name="invisible-input" type="text" id="invisible-input" bind:value={merchantJsonString} style="display: none;">
        <input name="method-to-db" type="text" id="method-to-db" bind:value={methodToDb} style="display: none;">
        <button id="submitToDatabaseButton" type="submit" class="btn btn-primary" >Submit to Database</button>
    </form>
{/if}  