<script> 
    import 'bootstrap/dist/css/bootstrap.css';
    import SearchResults from './search_result_component.svelte';
    // import sampleData from './sample_invoicedata.json'

	let errorMessage = '';
	let results = [];
	let searchMade = false;

	export let data;

	let supplierNames = data.merchantList.map(
		(merchant_information) => merchant_information.merchant_name
	);
	// console.log(data.merchantList);
	let outlet = data.customerList.map((customer_information) => customer_information.customer_name);
	// let supplierNames = sampleData.map(invoice => invoice.merchant_information.merchant_name);
	// let outlet = sampleData.map(invoice => invoice.customer_information.customer_name);

	function findAddressesByNames(mainList, names, fromProperty) {
		const ids = [];
		for (const element of mainList) {
			const name = element[fromProperty];
			if (names.includes(name)) {
				ids.push(element._id);
			}
		}
		return ids;
	}

	let searchParams = {
		'Supplier Names': ['Choose supplier name'],
		'Product Names': [''],
		Outlet: ['Choose outlet name'],
		'Date Range': [['', '']]
	};

	function addField(param) {
		if (param === 'Date Range') return;
		searchParams[param].push(
			param === 'Supplier Names'
				? 'Choose supplier name'
				: param === 'Outlet'
				? 'Choose outlet name'
				: ''
		);
		searchParams = { ...searchParams };
	}

	function removeField(param, index) {
		if (param === 'Date Range' || index === 0) return;
		searchParams[param].splice(index, 1);
		searchParams = { ...searchParams };
	}

	function clearFields() {
		searchParams['Supplier Names'] = ['Choose supplier name'];
		searchParams['Product Names'] = [''];
		searchParams['Outlet'] = ['Choose outlet name'];
		searchParams['Date Range'] = [['', '']];
		searchMade = false;
	}

	async function search() {
		const [startDate, endDate] = searchParams['Date Range'][0];

		// Validate date range logic
		if ((startDate && !endDate) || (!startDate && endDate)) {
			errorMessage = 'Both start date and end date must be provided.';
			return;
		} else if (startDate && endDate && startDate > endDate) {
			errorMessage = 'Invalid date range. Start date must be before or equal to end date.';
			return;
		} else {
			errorMessage = '';
		}

		// Check if any field is entered (excluding date range)
		const isAnyFieldEntered = Object.keys(searchParams).some(
			(key) =>
				key !== 'Date Range' &&
				searchParams[key].some(
					(value) => value && value !== 'Choose supplier name' && value !== 'Choose outlet name'
				)
		);

		if (!isAnyFieldEntered && (!startDate || !endDate)) {
			errorMessage = 'Please enter at least one search field.';
			return;
		}

		const supplierSearch = searchParams['Supplier Names'].filter(
			(name) => name !== 'Choose supplier name'
		);
		const outletSearch = searchParams['Outlet'].filter((name) => name !== 'Choose outlet name');
		const productSearch = searchParams['Product Names'].filter((name) => name);

		const merchIDS = findAddressesByNames(
			data.merchantList,
			searchParams['Supplier Names'],
			'merchant_name'
		);
		const custIDS = findAddressesByNames(data.customerList, searchParams['Outlet'], 'customer_name');
		const startdate = searchParams['Date Range'][0][0];
		const enddate = searchParams['Date Range'][0][1];
		const productlist = searchParams['Product Names'];

		const search_obj = {
			search_mode: 'search',
			customer: custIDS,
			merchant: merchIDS,
			start_date: new Date(startdate),
			end_date: new Date(enddate),
			product: productlist
		};
		const searchURL = new URLSearchParams(search_obj).toString();
		const result = await fetch(`/api/invoice?${searchURL}`, {
				method: 'GET',
				headers: {
					'Content-Type': 'application/json'
				}
		});
		// console.log("status is", result.status)
		if (result.status == 400 || result.status == 500) {
			alert('Database is currently facing an issue. Please try again later.');
            return
		}
        const arrayofInvoices = (await result.json()).result

		results = arrayofInvoices.filter((invoice) => {
			// Filter by Supplier Names
			if (
				supplierSearch.length > 0 &&
				!supplierSearch.includes(invoice.merchant_information.merchant_name)
			) {
				return false;
			}

			// Filter by Outlets
			if (
				outletSearch.length > 0 &&
				!outletSearch.includes(invoice.customer_information.customer_name)
			) {
				return false;
			}

			// Filter by Product Names
			if (
				productSearch.length > 0 &&
				!productSearch.some((product) =>
					invoice.item_lines.some((line) => line.description.includes(product))
				)
			) {
				return false;
			}

			// Filter by Date Range
			if (startDate && endDate) {
				const invoiceDate = new Date(invoice.date);
				if (invoiceDate < new Date(startDate) || invoiceDate > new Date(endDate)) {
					return false;
				}
			}
			return true;
		});
		searchMade = true;
	}
</script>

<div class="m-3">
	<h1>Invoice Search</h1>
	{#if errorMessage}
		<div class="alert alert-danger" role="alert">
			{errorMessage}
		</div>
	{/if}
	{#each Object.keys(searchParams) as param}
		<div>
			<h2>{param}</h2>
			{#each searchParams[param] as field, index}
				<div class="input-group mb-3">
					{#if param === 'Supplier Names' || param === 'Outlet'}
						<select bind:value={searchParams[param][index]} class="form-control">
							<option disabled style="color: grey;"
								>{param === 'Supplier Names' ? 'Choose supplier name' : 'Choose outlet name'}</option
							>
							{#each param === 'Supplier Names' ? supplierNames : outlet as option}
								<option>{option}</option>
							{/each}
						</select>
						{#if index > 0}
							<div class="input-group-append">
								<button
									class="btn btn-outline-danger"
									type="button"
									on:click={() => removeField(param, index)}>Remove</button
								>
							</div>
						{/if}

					{:else if param === 'Date Range'}
						<input
							type="date"
							class="form-control"
							bind:value={searchParams[param][index][0]}
							placeholder="Start date"
						/>
						<input
							type="date"
							class="form-control"
							bind:value={searchParams[param][index][1]}
							placeholder="End date"
						/>
					{:else}
						<input
							class="form-control"
							type="text"
							bind:value={searchParams[param][index]}
							placeholder={`Enter ${param.slice(0, -1)}...`}
						/>
						{#if index > 0}
						<div class="input-group-append">
							<button
								class="btn btn-outline-danger"
								type="button"
								on:click={() => removeField(param, index)}>Remove</button
							>
						</div>
						{/if}
					{/if}
				</div>
			{/each}
			{#if param !== 'Date Range'}
				<button class="btn btn-outline-primary" type="button" on:click={() => addField(param)}
					>Add {param}</button
				>
			{/if}
			<br />
		</div>
	{/each}
	<button class="btn btn-primary" type="button" on:click={search}>Search</button>
	<button class="btn btn-outline-secondary" type="button" on:click={clearFields}
		>Clear Fields</button
	>
	{#if searchMade}
		<SearchResults {results} />
	{/if}
	<br /><br />
</div>
