<script>
    import 'bootstrap/dist/css/bootstrap.css';
    export let results = [];
    let selectedResults = [];

    function selectResult(index) {
        if (selectedResults.includes(index)) {
            selectedResults = selectedResults.filter(item => item !== index);
        } else {
            selectedResults.push(index);
            isAnyResultSelected = selectedResults.length > 0;
        }
    }

    async function exportToCSV() {
            const resultstoExport = selectedResults.map(index => results[index]);
            console.log(resultstoExport)
        // Export selected results to CSV
            const finalCSV = await convertCSV(resultstoExport)
            downloadCSV(finalCSV,"invoices.csv")
        }


  $: isAnyResultSelected = selectedResults.length > 0;

    //RYAN PART
    async function convertCSV(inputs){
        try {
            // Use await within an async function
            const response = await fetch('/api/saveFile', {
            method: 'POST',
            body: JSON.stringify({
                json_array: inputs
                })
            });
            if (response.ok) {
            const jsonRes = await response.json()
            return jsonRes.csvSTRING
            } else {
            const errorData = await response.json();
            console.error('Error converting', errorData.error);
            }
        } catch (error) {
            console.error('Error during fetch request:', error);
        }
    }

    function downloadCSV(csvString, filename) {
        // Convert the CSV string to a Blob object
        const blob = new Blob([csvString], { type: 'text/csv' });

        // Create an anchor element
        const a = document.createElement('a');

        // Set the anchor's attributes
        a.href = URL.createObjectURL(blob);
        a.download = filename;

        // Trigger the download
        a.click();

        // Clean up by revoking the URL object
        URL.revokeObjectURL(a.href);
    }


    // RYAN PART End FUncitons

</script>

<div>
  <h1>Search Results</h1>
  <h3>Select checkbox to export to CSV.</h3>
  {#if results.length === 0}
      <p>No results to display.</p>
  {:else}
        {#if isAnyResultSelected}
            <button class="btn btn-outline-primary" on:click={exportToCSV}>Export to CSV</button>
        {/if}
      {#each results as result, index}
          <div>
              <p>Supplier: {result.merchant_information.merchant_name}, User: {result.customer_information.customer_name}, Date: {result.date}</p>
              <button class="btn btn-outline-primary" type="button" on:click={() => window.open(`invoice_search/invoice/${result._id}`)}>Click to view invoice {result.invoice_number}</button>
              <input class="form-check-input" type="checkbox" on:change={() => selectResult(index)}>
          </div>
      {/each}
  {/if}
</div>
