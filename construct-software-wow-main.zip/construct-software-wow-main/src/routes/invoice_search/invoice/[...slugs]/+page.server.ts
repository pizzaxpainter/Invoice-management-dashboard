import invoiceJson from "../../../invoice_upload/json_test_objects/sample_invoicedata.json"
import customerList from "../../../invoice_upload/json_test_objects/sample_customer.json"
import merchantList from "../../../invoice_upload/json_test_objects/sample_merchant.json"
import {groupProperties, ungroupProperties} from "../../../invoice_upload/InvoiceUploadFunctions"
import { error, redirect } from "@sveltejs/kit"
import { errorListObject } from "../../../invoice_upload/InvoiceUploadFunctions"

async function get_customers_function(fetch) {
    // init to get_request in cust_info
    const obj = {global_search:""}
    const params = new URLSearchParams(obj).toString()
    
    const response = await fetch(`/api/cust_info?${params}`)
    // console.log("response from cust_info:", response)
    if (response.status == 400) {
        console.log("err is", await response.json())
        console.log("error caught in get_customers_function")
        throw error(421, {
            message: errorListObject[421]
        })
    } else if (response.status == 500) {
        console.log("error is", await response.json())
        console.log("error caught in get_customers_function")
        throw error(430, {
            message: errorListObject[430]
        })
    }
    const responseJSON = await response.json()
    // console.log("... is ",responseJSON.result)
    const customerListFromDb = responseJSON.result
    // console.log("url search results,",customerListFromDb)
    customerListFromDb.unshift(customerList[0])
    // console.log("url search results 222,",customerListFromDb)
    // return responseJSON.result
    return customerListFromDb
}

async function get_merchants_function(fetch) {
    // init to get_request in cust_info
    const obj = {global_search:""}
    const params = new URLSearchParams(obj).toString()
    
    const response = await fetch(`/api/merch_info?${params}`)
    // console.log("response from cust_info:", response)
    if (response.status == 400) {
        console.log("err is", await response.json())
        console.log("error caught in get_merchants_function")
        throw error(422, {
            message: errorListObject[422]
        })
    } else if (response.status == 500) {
        console.log("error is", await response.json())
        console.log("error caught in get_merchants_function")
        throw error(430, {
            message: errorListObject[430]
        })
    }
    const responseJSON = await response.json()
    // console.log("... is ",responseJSON.result)
    const merchantListFromDb = responseJSON.result
    merchantListFromDb.unshift(merchantList[0])
    // return responseJSON.result
    return merchantListFromDb
    
}

async function get_invoice_function(fetch, invoiceId) {
    const paramObj = {
        search_mode:'id',
        object_id: invoiceId
    }
    const params = new URLSearchParams(paramObj).toString()
    
    const response = await fetch(`/api/invoice?${params}`)
    if (response.status == 400) {
        console.log("err is", await response.json())
        console.log("error caught in get_invoice_function")
        throw error(420, {
            message: errorListObject[420]
        }) 
    } else if (response.status == 401) {
        const errJson = await response.json()
        console.log(errJson)
        console.log("error caught in post_updated_invoice_function")
        throw error(429, {
            message: errJson.msg
        })
    } else if (response.status == 500) {
        console.log("error is", await response.json())
        console.log("error caught in get_invoice_function")
        throw error(430, {
            message: errorListObject[430]
        })
    }
    // console.log("response is", response)
    const responseJSON = await response.json()
    // console.log("responseJSON is ",responseJSON.result[0])
    const returnObject = responseJSON.result[0]
    const imgString = responseJSON.img
    if (imgString) {
        // console.log("Invoice String is received in server ([...slugs]]/+page.server.ts) from database (invoice/+server.ts), redirecting to frontend...")
        // console.log(imgString.slice(0,50))
    }
    else {
        console.log("Error reading Invoice String ([...slugs]]/+page.server.ts)")
    }
    // remove_for_final_presentation
    if (returnObject.date) returnObject.date = returnObject.date.slice(0,10) // shouldn't have if statement
    if (returnObject.due_date) returnObject.due_date = returnObject.due_date.slice(0,10)
    if (returnObject.service_date) returnObject.service_date = returnObject.service_date.slice(0,10)
    if (returnObject.service_due_date) returnObject.service_due_date = returnObject.service_due_date.slice(0,10)
    // console.log("returnObject is", returnObject)
    return {
        invoice:returnObject,
        imgString:imgString
    }
}

export async function load({params, fetch}) {
    try {
        // handling of customer list
        const updatedCustomerList = await get_customers_function(fetch)
        // console.log("updatedCustomerList is", updatedCustomerList)

        // handling of merchant list
        const updatedMerchantList = await get_merchants_function(fetch)
        // console.log("updatedMerchantList is", updatedMerchantList)

        // handling of invoice
        const {invoice: _invoice, imgString} = await get_invoice_function(fetch, params.slugs);
        const {_id, ...invoiceInstance} = _invoice;
        
        // let invoiceInstance = invoiceJson
        // console.log("invoiceInstance is", invoiceInstance)
        // invoiceInstance["customer_information"] = updatedCustomerList[1] // to comment out when invoice is from db
        // invoiceInstance["merchant_information"] = updatedMerchantList[2] // to comment out when invoice is from db
        groupProperties(invoiceInstance)
        // console.log("invoiceInstance right before return is", invoiceInstance)

        return {
            invoice_id: _id,
            invoiceInstance: invoiceInstance,
            customerList: updatedCustomerList,
            merchantList: updatedMerchantList,
            invoiceString: imgString
            // merchantList:merchantList,
            // customerList:customerList
        }
    } catch (err) {
        console.log("err", err)
        console.log("error caught in invoice/slugs serverLoad method")
        throw error(err.status,{message: err.body.message})
    }
}

async function delete_invoice_function(fetch, invoice_id) {
    const response = await fetch("/api/invoice", {
        method:"DELETE",
        body: JSON.stringify({
            obj_id:invoice_id,
        })
    })
    if (response.status == 400) {
        console.log("error is", await response.json())
        console.log("error caught in delete_invoice_function")
        throw error(426, {
            message: errorListObject[426]
        })
    } else if (response.status == 500) {
        console.log("error is", await response.json())
        console.log("error caught in delete_invoice_function")
        throw error(430, {
            message: errorListObject[430]
        })
    }
    // console.log("response is", await response.json())
}

async function post_updated_invoice_function(fetch, object_info, imgType, imgString) {
    const response = await fetch("/api/invoice", {
        method:"POST",
        body: JSON.stringify({
            obj:object_info,
            cust_autoadd: false,
            cust_allownull: false,
            merch_autoadd: false,
            merch_allownull: false,
            type: imgType,
            img: imgString
        })
    })
    if (response.status == 400) {
        console.log("error is", await response.json())
        console.log("error caught in post_updated_invoice_function")
        throw error(423, {
            message: errorListObject[423]
        })
    } else if (response.status == 401) {
        const errJson = await response.json()
        console.log(errJson)
        console.log("error caught in post_updated_invoice_function")
        throw error(429, {
            message: errJson.msg
        })
    } else if (response.status == 500) {
        console.log("error is", await response.json())
        console.log("error caught in post_updated_invoice_function")
        throw error(430, {
            message: errorListObject[430]
        })
    }
    const resJson = await response.json()
    // console.log("response is", resJson)

    return resJson.result._id
}

async function patch_invoice_function(fetch, object_info, object_id){
    const response = await fetch("/api/invoice", {
        method:"PATCH",
        body: JSON.stringify({
            editted_obj:object_info,
            obj_id:object_id
        })
    })
    if (response.status == 400) {
        console.log("error is", await response.json())
        console.log("error caught in post_updated_invoice_function")
        throw error(431, {
            message: errorListObject[431]
        })
    } else if (response.status == 401) {
        const errJson = await response.json()
        console.log(errJson)
        console.log("error caught in post_updated_invoice_function")
        throw error(429, {
            message: errJson.msg
        })
    } else if (response.status == 500) {
        console.log("error is", await response.json())
        console.log("error caught in post_updated_invoice_function")
        throw error(430, {
            message: errorListObject[430]
        })
    }
}

export const actions = {
    submitToDatabase:async({request, fetch, cookies}) => {
        let jsonRes
        try {
            const data = await request.formData()
            const invoiceId = data.get("invoice_id")
            // console.log("invoiceId is", invoiceId)
            // await delete_invoice_function(fetch, invoiceId)
            const invoiceObject = JSON.parse(data.get("invisible-input"))
            ungroupProperties(invoiceObject)
            // console.log("invoiceObject is", invoiceObject)
            // const imgType = data.get("invoiceType")
            // const imgType = invoiceObject.type
            // delete invoiceObject.type
            // if (imgType) {
            //     // console.log("Invoice Type is received in server ([...slugs]/+page.server.ts) from frontend (EditConfirmComponent.svelte), submitting to database...")
            //     // console.log(imgType)
            // }
            // else {
            //     console.log("Error reading Invoice Type ([...slugs]/+page.server.ts)")
            // }
            // // const imgString = data.get("invoiceString")
            // const imgString = invoiceObject.img
            // delete invoiceObject.img
            // if (imgString) {
            //     // console.log("Invoice String is received in server ([...slugs]/+page.server.ts) from frontend (EditConfirmComponent.svelte), submitting to database...")
            //     // console.log(imgString.slice(0, 50))
            // }
            // else {
            //     console.log("Error reading Invoice String ([...slugs]/+page.server.ts)")
            // }

            await new Promise(r => setTimeout(r, 100));
            // await post_updated_invoice_function(fetch, invoiceObject)
            await patch_invoice_function(fetch, invoiceObject, invoiceId)
            jsonRes = invoiceId
        } catch (err) {
            console.log("error caught in patchToDatabase formAction")
            throw error(err.status,{message: err.body.message})
        }
        cookies.set("cookie_mode","invoice_upload", {path:'/upload_confirmation'})
        cookies.set("cookie_object",jsonRes, {path:'/upload_confirmation'})
        throw redirect(300,'/upload_confirmation')
    },
    deleteInDatabase:async({request, fetch, cookies})=> {
        try {
            console.log("deleteInDatabase clicked")
            const data = await request.formData()
            const invoiceId = data.get("invoice_id")
            // console.log("invoiceId is", invoiceId)
            await delete_invoice_function(fetch, invoiceId)
        } catch (err) {
            console.log("error caught in deleteInDatabase formAction")
            throw error(err.status,{message: err.body.message})
        }
        cookies.set("cookie_mode","delete_invoice", {path:'/upload_confirmation'})
        cookies.set("cookie_object","success", {path:'/upload_confirmation'})
        throw redirect(300,'/upload_confirmation')
        
    }
}