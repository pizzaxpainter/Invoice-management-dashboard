<script>
    import EditConfirmComponent from  "../../../invoice_upload/edit_confirm_component/EditConfirmComponent.svelte";
    import {selectedFileStoreString} from "../../../invoice_upload/stores";
    let disableInput = true
    export let data
    if (data.invoiceString) {
        // console.log("Invoice String is received in frontend ([...slugs]]/+page.svelte) from server ([...slugs]]/+page.server.ts), redirecting to EditConfirmComponent")
        // console.log((data.invoiceString).slice(0, 50))
    }
    else{
        ("Error reading Invoice String ([...slugs]]/+page.svelte)")
    }
    selectedFileStoreString.set(data.invoiceString);
    // console.log("data is", data.invoiceInstance)

</script>

<h1>Invoice Details</h1>
<EditConfirmComponent invoice_id={data.invoice_id} merchantList={data.merchantList} customerList={data.customerList} allowEditViewInvoice={true} disableInput={disableInput} invoiceInstance={data.invoiceInstance}></EditConfirmComponent>