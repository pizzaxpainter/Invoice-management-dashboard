// import invoiceJson from "../invoice_upload/json_test_objects/sample_invoicedata.json"
// import customerList from "../invoice_upload/json_test_objects/sample_customer.json"
// import merchantList from "../invoice_upload/json_test_objects/sample_merchant.json"

import { error} from "@sveltejs/kit"
import { errorListObject } from "../invoice_upload/InvoiceUploadFunctions"

/**
 * 1. get invoice# from url
 * 2. fetch from db api using invoice #
 * 3. return it to browser
 */

async function get_customers_function(fetch) {
    // init to get_request in cust_info
    const obj = {global_search:""}
    const params = new URLSearchParams(obj).toString()
    
    const response = await fetch(`/api/cust_info?${params}`)
    // console.log("response from cust_info:", response)
    if (response.status == 400) {
        console.log("err is", await response.json())
        console.log("error caught in get_customers_function")
        throw error(421, {
            message: errorListObject[421]
        })
    } else if (response.status == 500) {
        console.log("error is", await response.json())
        console.log("error caught in get_customers_function")
        throw error(430, {
            message: errorListObject[430]
        })
    }
    const responseJSON = await response.json()
    // console.log("... is ",responseJSON.result)
    const customerListFromDb = responseJSON.result
    return customerListFromDb
}

async function get_merchants_function(fetch) {
    // init to get_request in cust_info
    const obj = {global_search:""}
    const params = new URLSearchParams(obj).toString()
    
    const response = await fetch(`/api/merch_info?${params}`)
    // console.log("response from merch_info:", response)
    if (response.status == 400) {
        console.log("err is", await response.json())
        console.log("error caught in get_merchants_function")
        throw error(422, {
            message: errorListObject[422]
        })
    } else if (response.status == 500) {
        console.log("error is", await response.json())
        console.log("error caught in get_merchants_function")
        throw error(430, {
            message: errorListObject[430]
        })
    }
    const responseJSON = await response.json()
    // console.log("... is ",responseJSON.result)
    const merchantListFromDb = responseJSON.result
    return merchantListFromDb
}

export async function load({fetch}) {
    try {
        // handling of customer
        const updatedCustomerList = await get_customers_function(fetch)
        // console.log("updatedCustomerList is", updatedCustomerList)

        // handling of merchant
        const updatedMerchantList = await get_merchants_function(fetch)
        // console.log("updatedMerchantList is", updatedMerchantList)


        return {
            customerList: updatedCustomerList,
            merchantList: updatedMerchantList
            // merchantList:merchantList,
            // customerList:customerList
        }
    } catch (err) {
        console.log("err", err)
        console.log("error caught in invoice_search serverLoad method")
        throw error(err.status,{message: err.body.message})
    }
}