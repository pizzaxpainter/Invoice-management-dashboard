<script>
    import { goto } from '$app/navigation';

    let searchParams = {
        Invoice: {
            Total: { condition: 'contains', value: '' },
            Number: { condition: 'contains', value: '' },
            Date: { condition: 'contains', value: '' },
            AmountDue: { condition: 'contains', value: '' },
            AmountDueDate: { condition: 'contains', value: '' },
        },
        CustomerInformation: {
            CustomerName: { condition: 'contains', value: '' },
            CustomerABNNumber: { condition: 'contains', value: '' },
        },
        MerchantInformation: {
            MerchantName: { condition: 'contains', value: '' },
            MerchantABNNumber: { condition: 'contains', value: '' },
        },
        ItemInformation: {
            ItemDescription: { condition: 'contains', value: '' },
        },
    };


    let conditions = {
        'string': {
            'contains': { display: 'Contains', mongo: '$regex' },
            '<': { display: 'Less Than', mongo: '$lt' },
            '>': { display: 'More Than', mongo: '$gt' },
            '=': { display: 'Same As', mongo: '$eq' },
        },
        'number': {
            'contains': { display: 'Contains', mongo: '$regex' },
            '<': { display: 'Less Than', mongo: '$lt' },
            '>': { display: 'Greater Than', mongo: '$gt' },
            '=': { display: 'Equivalent To', mongo: '$eq' },
        },
        'date': {
            'contains': { display: 'Contains', mongo: '$regex' },
            '<': { display: 'Before', mongo: '$lt' },
            '>': { display: 'After', mongo: '$gt' },
            '=': { display: 'On', mongo: '$eq' },
        },
    };


    let dateFields = ['Date', 'AmountDueDate'];
    let numberFields = ['Total', 'AmountDue'];
    let alertUser = false;
   
    function search() {
        console.log("Search clicked");
        for(let category in searchParams) {
            for(let param in searchParams[category]) {
                if(searchParams[category][param].value && !searchParams[category][param].condition) {
                    alertUser = true;
                    return;
                }
            }
        }
        performSearch();
    }
    
    function proceedWithoutConditions() {
        alertUser = false;
        performSearch();
    }

    function performSearch() {
        let filledSearchParams = {};
        for(let category in searchParams) {
            for(let param in searchParams[category]) {
                if(searchParams[category][param].condition && searchParams[category][param].value) {
                    if (!filledSearchParams[category]) filledSearchParams[category] = {};
                    filledSearchParams[category][param] = {
                        condition: conditions[
                            dateFields.includes(param) ? 'date' : (numberFields.includes(param) ? 'number' : 'string')
                        ][searchParams[category][param].condition].mongo,
                        value: searchParams[category][param].value,
                    };
                }
            }
        }
        console.log(JSON.stringify(filledSearchParams));
    }
</script>

<div class="m-3">
    <h1>Advanced Search</h1>
    <h2>Click each category for search fields</h2>
    {#each Object.keys(searchParams) as category}
    <button class="btn btn-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#{category}Collapse">Click for {category}</button>
    <div id="{category}Collapse" class="collapse">
        {#each Object.keys(searchParams[category]) as key}
        <label for={key} class="form-label display-5">{key}</label>
        <div class="input-group mb-3">
            <select class="form-select" id={category + key + 'Condition'} bind:value={searchParams[category][key].condition}>
                <option selected>Choose...</option>
                {#each Object.entries(conditions[dateFields.includes(key) ? 'date' : (numberFields.includes(key) ? 'number' : 'string')]) as [conditionKey, condition]}
                    <option value={conditionKey}>{condition.display}</option>
                {/each}
            </select>
            {#if dateFields.includes(key)}
            <input class="form-control" id={category + key + 'Value'} type="date" bind:value={searchParams[category][key].value}>
            {:else}
            <input class="form-control" id={category + key + 'Value'} type="text" bind:value={searchParams[category][key].value}>
            {/if}
        </div>
        {/each}
    </div>
    <br>
    {/each}
    
    <br>
    {#if alertUser}
        <div class="alert alert-warning">
            Some fields have a value but no condition. Do you want to add conditions or proceed without them?
            <button class="btn btn-primary" on:click={() => alertUser = false}>Add conditions</button>
            <!--<button class="btn btn-secondary" on:click={proceedWithoutConditions}>Proceed without conditions</button>-->
        </div>
    {/if}
    <br>
    <button type="button" on:click={search} class="btn btn-primary" id="searchButton">Search</button> 
    <button class="btn btn-outline-secondary" on:click={() => goto('/invoice_search')}>Go to General Search</button>

</div>
