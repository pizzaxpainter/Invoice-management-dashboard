<script>
    import ResultComponent from "./edit_confirm_component/EditConfirmComponent.svelte";
    import {submitOcrButtonClicked, submitDatabaseButtonClicked,sessionID} from "./stores.js";
    import UploadFileComponent from "./UploadFileComponent.svelte";
    
    export let form;
    export let data;
    
    sessionID.set(data.session_id)    

    let triggerOcrResultComponent = false;
    submitOcrButtonClicked.subscribe((value)=> {
        triggerOcrResultComponent = value
    })
    
    // let triggerSubmittingDatabaseComponent = false;
    // submitDatabaseButtonClicked.subscribe((value)=>{
    //     triggerSubmittingDatabaseComponent = value
    // })
</script>


{#if !form?.successOcr}
    <UploadFileComponent></UploadFileComponent>
{/if}

{#if !form?.successOcr && triggerOcrResultComponent}
    <div class="m-3">
        <button class="btn btn-primary" type="button" disabled style="font-size: large;">
            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
            Please wait as your invoice is being processed
        </button>
    </div>
{:else if form?.successOcr && triggerOcrResultComponent}
    <h1>OCR Result</h1>
    <ResultComponent invoice_id={null} allowEditViewInvoice={false} 
        disableInput={false} invoiceInstance={form?.invoiceJson}
        customerList={form?.customerList} merchantList={form?.merchantList}></ResultComponent> 
{/if}