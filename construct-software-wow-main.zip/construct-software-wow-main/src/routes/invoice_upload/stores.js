import {writable, readable} from 'svelte/store'

export const submitOcrButtonClicked = writable(false)

export const submitDatabaseButtonClicked = writable(false)

export const renderSubmitButton = writable(false)

export const sessionID = writable("");

// Elvern's code
export const selectedFileStore = writable(null) 
export const selectedFileStoreString = writable(null) 

// }
// // not needed
// export const nestedDescriptionTitlesReadable = readable(nestedDescriptionTitles, (set)=>{
//     set(nestedDescriptionTitles)
//     return () => {}
// })

// to limit the input fields in editConfirmComponent
const inputFieldTypes = {
    
    customer_name: "text",
    customer_address: "text",
    customer_email: "text",
    customer_id: "text",
    customer_tax_id: "text",
    customer_mailing_address: "text",
    customer_billing_address: "text",
    customer_shipping_address: "text",
    customer_service_address: "text",
    customer_remittance_address: "text",
    abn_number: "text",
    gst_number: "text",
    pan_number: "text",
    vat_number: "text",
   
    merchant_name: "text",
    merchant_address: "text",
    merchant_phone: "text",
    merchant_email: "text",
    merchant_fax: "text",
    merchant_website: "text",
    merchant_tax_id: "text",
    merchant_siret: "text",
    merchant_siren: "text",
    
    invoice_number: "text",
    invoice_total: "number",
    invoice_subtotal: "number",
    gratuity: "number",
    amount_due: "number",
    previous_unpaid_balance: "number",
    discount: "number",
    
    value: "number", 
    rate: "number",

    service_charge: "number",
    payment_term: "text",
    purchase_order: "text",
    date: "date",
    due_date: "date",
    service_date: "date",
    service_due_date: "date",
    po_number: "text",
    
    currency: "text", 
    language: "text" ,
    
    account_number: "text",
    iban: "text",
    bsb: "text",
    sort_code: "text",
    rooting_number: "text",
    swift: "text",
   
    description: 'text',
    quantity: 'number',
    amount: "number",
    unit_price: "number",
    product_code: "text",
    date_item: "text",
    tax_item: "text",
    tax_rate: "number"
}

export const inputFieldTypesReadable = readable(inputFieldTypes, (set)=>{
    set(inputFieldTypes)
    return () => {}
})