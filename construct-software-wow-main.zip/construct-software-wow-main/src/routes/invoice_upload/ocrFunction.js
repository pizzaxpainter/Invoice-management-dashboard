import { errorListObject, changeDateToHtmlFormat } from "./InvoiceUploadFunctions"
import { error } from "@sveltejs/kit"

export async function ocr_function (python_input,user_name,fetch) {
    
    const response = await fetch("/api/eden_api", {
        method:"POST",
        body: JSON.stringify({
            filename: python_input,
            username: user_name,
        })
    })

    const jsonRes = await response.json()
    const responsestatus = jsonRes.status
    const responseBody = jsonRes.body
    if (responsestatus == 200){
        responseBody.invoice.date = changeDateToHtmlFormat(responseBody.invoice.date)
        responseBody.invoice.due_date = changeDateToHtmlFormat(responseBody.invoice.due_date)
        responseBody.invoice.service_due_date = changeDateToHtmlFormat(responseBody.invoice.service_due_date)
        responseBody.invoice.service_date = changeDateToHtmlFormat(responseBody.invoice.service_date)
        return responseBody.invoice
    }else if (responsestatus > 400){
        console.log("Error caught in OCR API")
        throw error(responsestatus, {
            message: errorListObject[responsestatus]
        })
    }
}