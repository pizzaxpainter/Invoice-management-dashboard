// @ts-nocheck

export function groupProperties(jsonObj) {
    if (jsonObj.direct_access) return
    const directAccessProps = {};

    for (const key in jsonObj) {
        // console.log(key)
        if (typeof jsonObj[key] !== 'object' || jsonObj[key]===null) {
            directAccessProps[key] = jsonObj[key];
            delete jsonObj[key];
        }
    }
    jsonObj.direct_access = directAccessProps;
    return jsonObj
}

export function ungroupProperties(jsonObj){
    // const jsonObj = JSON.parse(JSON.stringify(jsonObj))
    for (const key in jsonObj.direct_access){
        jsonObj[key] = jsonObj.direct_access[key];
    }
    delete jsonObj.direct_access;
}

export function checkFileType(file) {
    const acceptedFileType = ["image/png", "image/jpeg", "application/pdf"]
    // console.log("file is", file)
    if (file) return acceptedFileType.includes(file.type) 
    else return false   
}

export function changeItemLine (item_lines,addItem=true) {
    // if you want to add itemLine
    if (addItem) {
        let newLine = {
            description: null,
            quantity: null,
            amount: null,
            unit_price: null,
            discount: null,
            product_code: null,
            date_item: null,
            tax_item: null,
            tax_rate: null
        }
        item_lines.push(newLine)
    } else {
        item_lines.pop()
    } 
}

export function changeTaxes (taxes, addItem=true) {
    if (addItem) {
        let newLine = {
            value:null,
            rate:null,
        }
        taxes.push(newLine)
    } else {
        taxes.pop()
    }
}

export function changeDateToHtmlFormat(dateString) {
    // console.log("before, dateString is", dateString)
    if (dateString == null || ![8,10].includes(dateString.length)) {
        return ""
    }
    const day = dateString.slice(0,2)
    const month = dateString.slice(3,5)
    let year = dateString.slice(6)
    if (year.length == 2) {
        year = "20" + year
    }
    // console.log(day, month, year)
    return year + "-" + month + "-" + day
}

export const errorListObject = {
    400: "You did not upload any file.",
    401: "Only png, jpeg and pdf files are accepted.",
    402: "Only png, jpeg and pdf files are accepted.",
    403: "There is a problem with Eden AI server. Please try again later.",
    
    // 420 > reserved for database errors
    // 420 to 428 is if database api return err code 400
    420: "There is a problem getting the invoice's data. Please try again later.",
    421: "There is a problem getting the outlets' data. Please try again later.", 
    422: "There is a problem getting the suppliers' data. Please try again later.",

    423: "There is a problem posting the invoice's data. Please try again later.",
    424: "There is a problem posting the oulet's data. Please try again later.",
    425: "There is a problem posting the supplier's data. Please try again later.",

    426: "There is a problem deleting the invoice's data. Please try again later.",
    427: "There is a problem deleting the outlet's data. Please try again later.",
    428: "There is a problem deleting the supplier's data. Please try again later.",

    // 429 is reserved for user relevant error messages from database, 
    //      ie if database api returns code 401

    // if database api return err code 500 
    430: "There is a problem with database. Please try again later.",

    431: "There is a problem patching the invoice's data. Please try again later.",
    432: "There is a problem patching the outlet's data. Please try again later.",
    433: "There is a problem patching the supplier's data. Please try again later.",

}

export const inputFieldNames = {
    "#":"#",
    customer_name: "Outlet's Name",
    customer_address: "Outlet's Address",
    customer_email: "Outlet's Email",
    customer_id: "Outlet's Id",
    customer_tax_id: "Outlet's Tax Id",
    customer_mailing_address: "Outlet's Mailing Address",
    customer_billing_address: "Outlet's Billing Address",
    customer_shipping_address: "Outlet's Shipping Address",
    customer_service_address: "Outlet's Service Address",
    customer_remittance_address: "Outlet's Remittance Address",
    abn_number: "ABN Number",
    gst_number: "GST Number",
    pan_number: "PAN Number",
    vat_number: "VAT Number",
    
   
    merchant_name: "Supplier's Name",
    merchant_address: "Supplier's Address",
    merchant_phone: "Supplier's Phone",
    merchant_email: "Supplier's Email",
    merchant_fax: "Supplier's Fax",
    merchant_website: "Supplier's Website",
    merchant_tax_id: "Supplier's Tax Id",
    merchant_siret: "Supplier's Siret",
    merchant_siren: "Supplier's Siren",
    
    invoice_number: "Invoice Number",
    invoice_total: "Invoice Total",
    invoice_subtotal: "Invoice Subtotal",
    gratuity: "Gratuity",
    amount_due: "Amount Due",
    previous_unpaid_balance: "Previous Unpaid Balance",
    discount: "Discount",
    
    value: "Value", 
    rate: "Rate",

    service_charge: "Service Charge",
    payment_term: "Payment Term",
    purchase_order: "Purchase Order",
    date: "Date",
    due_date: "Due Date",
    service_date: "Service Date",
    service_due_date: "Service Due Date",
    po_number: "PO number",
    
    currency: "Currency", 
    language: "Language" ,
    
    account_number: "Account Number",
    iban: "IBAN",
    bsb: "BSB",
    sort_code: "Sort Code",
    rooting_number: "Rooting Number",
    swift: "Swift",
   
    description: 'Description',
    quantity: 'Quantity',
    amount: "Amount",
    unit_price: "Unit Price",
    product_code: "Product Code",
    date_item: "Date Item",
    tax_item: "Tax Item",
    tax_rate: "Tax Rate"
}