<script>
    //@ts-nocheck
    // Elvern's code
    import {submitOcrButtonClicked, renderSubmitButton, selectedFileStore} from './stores'
    import { enhance } from "$app/forms";
    import {checkFileType} from "./InvoiceUploadFunctions"
    import { sessionID } from './stores';

  // The function you want to run on component load
    let userName = "";   
    sessionID.subscribe((value)=>{
        userName = value;
    });

    const submitFile = () => {
        // if (filename="") {
        //     alert("nooo")
        //     return
        // }
        // console.log("UploadToOcr clicked");
        // console.log("selectedFile is",selectedFile);   
        submitOcrButtonClicked.set(true)
    } 

    let selectedFile;
    let filename = ""; 

    let resetBool = false
    let allowSubmit = false
    renderSubmitButton.subscribe((value)=> allowSubmit=value)

    async function handleUpload() {
        if (selectedFile) {
            const reader = new FileReader();
            reader.onloadend = async function() {
                const base64Data = reader.result.split(",")[1];
                filename = selectedFile.name
                await testingfilecreation(filename,base64Data)
            };
            reader.readAsDataURL(selectedFile);
            renderSubmitButton.set(true);
            // Elvern's code
            // 'selectedFile' will change the value of 'selectedFileStore' in ./stores.js (if it is a correct file)
            selectedFileStore.set(selectedFile);
        }else {
            console.log('No file selected.');
        } 
    }
    function handleFileInput(event) {
        selectedFile = event.target.files[0];
        // console.log("file selected");
        if (checkFileType(selectedFile)) handleUpload();
        else {
            renderSubmitButton.set(false)
            // console.log("choose another file")
        }
    }
    async function testingfilecreation(fileName,fileData){
        try {
            // Use await within an async function
            const response = await fetch('/api/writeFile', {
            method: 'POST',
            body: JSON.stringify({
                    filename: fileName,
                    username: userName,
                    data: fileData
                })
            });

            if (response.ok) {
            // console.log('File created successfully.');
            } else {
            const errorData = await response.json();
            console.error('Error creating the file:', errorData.error);
            }
        } catch (error) {
            console.error('Error during fetch request:', error);
        }
    }

</script>

<style>
    .customBorder {
        border: 0cap;
        /* border-style:dashed;
        border-color: rgb(36, 208, 227); */
    }
</style>

<div class="m-3">
    <h1>Please select your invoice here</h1>
    {#key resetBool}
        <form method="POST" enctype="multipart/form-data" action="?/submitToOcr" use:enhance>
            <div class="input-group mb-3">
            <!-- <label for="formFileMultiple" class="form-label display-5">Please upload your invoice here.</label><br> -->
            <input class="form-control customBorder" name="file_input" type="file" on:change={handleFileInput} value=""/>
            <!-- {#if allowSubmit} -->
                <div class="input-group-append">
                    <button type="submit" on:click={submitFile} class="btn btn-primary" disabled={!allowSubmit}>Upload to OCR software</button> 
                </div>  
            <!-- {/if} -->
            <input name="fileName" type="text" bind:value={filename} style="display: none;">
            <input name="userName" type="text" bind:value={userName} style="display: none;">
        </div>
        </form>
    {/key}
</div>