import {error, redirect} from '@sveltejs/kit'
import {ungroupProperties, groupProperties, errorListObject} from  './InvoiceUploadFunctions';
import { ocr_function } from './ocrFunction';
import invoiceInstance from "./json_test_objects/sample_invoicedata.json"
import customerList from "./json_test_objects/sample_customer.json"
import merchantList from "./json_test_objects/sample_merchant.json"

export const load = async ({ cookies, request, locals }) => {
  const session_id = cookies.get('session_id');
  cookies.set("username",session_id)
  return {
    session_id: session_id,
  };
};

async function get_customers_function(fetch) {
    // init to get_request in cust_info
    const obj = {global_search:""}
    const params = new URLSearchParams(obj).toString()
    
    const response = await fetch(`/api/cust_info?${params}`)
    // console.log("response from cust_info:", response)
    if (response.status == 400) {
        console.log("err is", await response.json())
        console.log("error caught in get_customers_function")
        throw error(421, {
            message: errorListObject[421]
        })
    } else if (response.status == 500) {
        console.log("error is", await response.json())
        console.log("error caught in get_customers_function")
        throw error(430, {
            message: errorListObject[430]
        })
    }
    const responseJSON = await response.json()
    // console.log("... is ",responseJSON.result)
    const customerListFromDb = responseJSON.result
    customerListFromDb.unshift(customerList[0])
    // return responseJSON.result
    return customerListFromDb    
}

async function get_merchants_function(fetch) {
    // init to get_request in cust_info
    const obj = {global_search:""}
    const params = new URLSearchParams(obj).toString()
    
        const response = await fetch(`/api/merch_info?${params}`)
        // console.log("response from cust_info:", response)
        if (response.status == 400) {
            console.log("err is", await response.json())
            console.log("error caught in get_merchants_function")
            throw error(422, {
                message: errorListObject[422]
            })
        } else if (response.status == 500) {
            console.log("error is", await response.json())
            console.log("error caught in get_merchants_function")
            throw error(430, {
                message: errorListObject[430]
            })
        }
        const responseJSON = await response.json()
        // console.log("... is ",responseJSON.result)
        const merchantListFromDb = responseJSON.result
        merchantListFromDb.unshift(merchantList[0])
        // return responseJSON.result
        return merchantListFromDb
    
        // console.log(err)
        console.log("error caught in get_merchants_function")
        throw error(422, {message:errorListObject[422]})
    
}

async function post_invoice_function(fetch, object_info, imgType, imgString) {
    const response = await fetch("/api/invoice", {
        method:"POST",
        body: JSON.stringify({
            obj:object_info,
            cust_autoadd: false,
            cust_allownull: false,
            merch_autoadd: false,
            merch_allownull: false,
            type: imgType,
            img: imgString
        })
    })
    // console.log("response is", response)
    if (response.status == 400) {
        console.log("error is", await response.json())
        console.log("error caught in post_invoice_function")
        throw error(423, {
            message: errorListObject[423]
        })
    } else if (response.status == 401) {
        const errJson = await response.json()
        console.log(errJson)
        console.log("error caught in post_invoice_function")
        throw error(429, {
            message: errJson.msg
        })
    } else if (response.status == 500) {
        console.log("error is", await response.json())
        console.log("error caught in post_invoice_function")
        throw error(430, {
            message: errorListObject[430]
        })
    }
    const resJson = await response.json()
    // console.log("response is", resJson)

    return resJson.result._id
}

export const actions = {
    submitToOcr:async({request,fetch}) => {
        const data = await request.formData()
        // console.log("submitToOcr formAction Done")
        // console.log("data is", data)
        const needed_file = data.get("fileName")
        const needed_user = data.get("userName")
        
        // console.log(needed_file)
        // console.log("needed_file is ", needed_file)
        try {
            let OCRJSON = await ocr_function(needed_file,needed_user,fetch)
            
            // console.log("OCRJSON from ocr_function:", OCRJSON)
            const updatedCustomerList = await get_customers_function(fetch)
            // console.log("updatedCustomerList is",updatedCustomerList)

            const updatedMerchantList = await get_merchants_function(fetch)
            // console.log("updatedMerchantList is", updatedMerchantList)
            
            OCRJSON["customer_information"] = customerList[0]
            OCRJSON["merchant_information"] = merchantList[0]
            groupProperties(OCRJSON)
            // console.log("OCRJSON after groupProperties:",OCRJSON)

            console.log("ocrApi return successful")

            const response = await fetch('/api/deleteUserFolder', {
                method: 'POST',
                body: JSON.stringify({
                        username: needed_user,
                    })
                });
        
                if (response.ok) {
                    console.log("user's tempFile deleted successfully.");
                } else {
                    const errorData = await response.json();
                    console.error('Error deleting the file:', errorData.error);
                }
            
            // await new Promise(r => setTimeout(r, 5000));

            return {
                successOcr:true,
                customerList:updatedCustomerList,
                merchantList:updatedMerchantList,
                invoiceJson: OCRJSON                
                // customerList: customerList,
                // merchantList: merchantList,
                // invoiceJson: invoiceInstance
            }
        } catch(err) {
            console.log("error caught in submitToOcr formAction")
            // console.log("err is",err.body.message)
            throw error(err.status,{message: err.body.message})
        }  
    },
    submitToDatabase:async({request,fetch, cookies}) => {
        let jsonRes;
        try {
            // throw(error); // for testing 
            console.log("submitToDatabase clicked")
            const data = await request.formData()
            console.log("data is", data)
            const data_needed = data.get("invisible-input")
            // console.log("data_needed is", data_needed)
            const needed_file = JSON.parse(data_needed)
            // console.log("Needed_file is, ",needed_file)
            ungroupProperties(needed_file)
            console.log("Image processing started")
            console.log("imgType", data.get("invoiceType"))
            // console.log("invoiceString", data.get("invoiceString"))
            // const imgType = data.get("invoiceType")
            const imgType = data.get("invoiceType")
            delete needed_file.type
            if (imgType) {
                // console.log("Invoice Type is received in server (invoice_upload/+page.server.ts) from frontend (EditConfirmComponent.svelte), submitting to database...")
                // console.log(imgType)
            }
            else {
                console.log("Error reading Invoice Type (invoice_upload/+page.server.ts)")
            }
            // const imgString = data.get("invoiceString")
            const imgString = data.get("invoiceString")
            delete needed_file.img
            if (imgString) {
                // console.log("Invoice String is received in server (invoice_upload/+page.server.ts) from frontend (EditConfirmComponent.svelte), submitting to database...")
                // console.log(imgString.slice(0, 50))
            }
            else {
                console.log("Error reading Invoice String (invoice_upload/+page.server.ts)")
            }
            console.log("Image Processed")
            // console.log("needed_file is ", needed_file)
            jsonRes = await post_invoice_function(fetch, needed_file, imgType, imgString)
        }
        catch(err) {
            console.log("err is", err)
            console.log("error caught in submitToDatabase formAction")
            throw error(err.status,{
                message: err.body.message
            })
        }
        // console.log("finished uploading, redirecting now")
        // console.log("response from DB is", jsonRes)
        cookies.set("cookie_mode","invoice_upload", {path:'/upload_confirmation'})
        cookies.set("cookie_object",jsonRes, {path:'/upload_confirmation'})
        throw redirect(300,'/upload_confirmation')
    }
}