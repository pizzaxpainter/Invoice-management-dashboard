<script>
    import {inputFieldTypesReadable} from "../stores"
    import {changeItemLine, inputFieldNames} from "../InvoiceUploadFunctions"
    

    function itemLinesChangeHandler () {
        // @ts-ignore
        // console.log("this is", this.id)
        // @ts-ignore
        let [itemNumberTitle, itemFieldTitle] = this.id.split(",")
        // @ts-ignore
        if (this.type=="number") item_lines[itemNumberTitle][itemFieldTitle] = parseFloat(this.value)
        else item_lines[itemNumberTitle][itemFieldTitle] = this.value
    }
    function triggerAddItemLine() {
        changeItemLine(item_lines)
        itemLineRefresher = !itemLineRefresher
    }
    function triggerRemoveItemLine() {
        changeItemLine(item_lines, false)
        itemLineRefresher = !itemLineRefresher
    }

    let inputFieldTypes={}
    inputFieldTypesReadable.subscribe((value)=>{
        inputFieldTypes=value
        // console.log("inputFieldTypes is",inputFieldTypes)
    })

    export let item_lines
    export let disableInput

    let itemLineRefresher = false;
    let itemLineParameters = [
        "#",
        "description",
        "quantity",
        "amount",
        "unit_price",
        "discount",
        "product_code",
        "date_item",
        "tax_item",
        "tax_rate"
    ]
</script>

<style>
    * {
       /* box-sizing: border-box; */
       padding: 0 10px;
   }
</style>

<div>
    <h3>Products</h3>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead class="table-light">
                <tr>
                    {#each itemLineParameters as parameter}
                        <th scope="col">{inputFieldNames[parameter]}</th>
                    {/each}
                </tr>
            </thead>
            <tbody class="table-group-divider">
                {#key itemLineRefresher}
                    {#each item_lines as item_line, itemNumber}
                        <tr>
                            <th scope="row">{itemNumber+1}</th>
                            {#each Object.keys(item_line) as _,itemPosition}
                                <td><input id="{itemNumber},{itemLineParameters[itemPosition+1]}" value={item_line[itemLineParameters[itemPosition+1]]} 
                                    on:change={itemLinesChangeHandler} type={inputFieldTypes[itemLineParameters[itemPosition+1]]}
                                    disabled={disableInput}></td>
                            {/each}
                        </tr>
                    {/each}
                {/key}
            </tbody>
        </table>
    </div>
    <button class="btn btn-secondary" type="button" on:click={triggerAddItemLine} disabled={disableInput}>Add item</button>
    <button class="btn btn-secondary" type="button" on:click={triggerRemoveItemLine} disabled={disableInput}>Remove item</button>
</div>
<hr>