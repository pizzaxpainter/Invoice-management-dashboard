<script>
	import { goto } from "$app/navigation";

    function selectFromListHandler() {
      // console.log("selectFromListHandler() called")
      // console.log("id value of",subject,"is" , this.value)
      // console.log("before of object_information", object_information)
      // console.log("before of objectList", objectList)
      const objectListCopy = JSON.parse(JSON.stringify(objectList))
      const result = objectListCopy.filter((obj)=>{
        return obj._id == this.value
      })
      const resultObj = JSON.parse(JSON.stringify(result[0]))
      // console.log("result is", resultObj)
      if (subject=="customer") {
        invoiceInstance.customer_information = resultObj
      } else if (subject=="merchant") {
        invoiceInstance.merchant_information = resultObj
      }
    }
    
    export let objectList
    export let objectTitle
    export let subject
    export let invoiceInstance
    export let disableInput

    let defaultValueForSelect = -1
    let AddSubjectLink ="/"
    let AddSubjectTitle = ""
    
    const objectNameList = []
    if (subject=="customer") {
      AddSubjectTitle = "outlets"
      AddSubjectLink = "/edit_customers"
      defaultValueForSelect = invoiceInstance.customer_information._id
      objectList.map(obj => objectNameList.push({
        object_name:obj.customer_name,
        id: obj._id
      }))
      // console.log("subject is", subject)
      // console.log("defaultValueForSelect is", defaultValueForSelect)
      // console.log("objectList is", objectList)
      // console.log("objectNameList is", objectNameList)

    } else if (subject=="merchant") {
      AddSubjectTitle = "suppliers"
      AddSubjectLink = "/edit_merchants"
      defaultValueForSelect = invoiceInstance.merchant_information._id
      objectList.map(obj => objectNameList.push({
        object_name:obj.merchant_name,
        id: obj._id
      }))
      // console.log("subject is", subject)
      // console.log("defaultValueForSelect is", defaultValueForSelect)
      // console.log("objectList is", objectList)
      // console.log("objectNameList is", objectNameList)
    }
</script>

<style>
    * {
       /* box-sizing: border-box; */
       padding: 0 10px;
   }
</style>

<h3>{objectTitle}</h3>
<div class="input-group mb-3">
    <label class="input-group-text" for="selectFromList">Options</label>
    <select class="form-select" id="selectFromList" on:change={selectFromListHandler} 
    disabled={disableInput} bind:value={defaultValueForSelect}>
      {#each objectNameList as objectName}
        <option value={objectName.id}>{objectName.object_name}</option>
      {/each}
    </select>
</div><div title="Click this to add new {AddSubjectTitle}">
  <button class="btn btn-outline-primary" on:click={() => goto(AddSubjectLink)} >
    add/edit {AddSubjectTitle}
  </button>
</div>
<hr>
