<script>
    import {inputFieldTypesReadable} from "../stores"
    import {inputFieldNames} from "../InvoiceUploadFunctions"

    // console.log("nestedDescriptionTitle is: ",nestedDescriptionTitle)
    // console.log("nestedDescriptionObject is: ",nestedDescriptionObject)
    function nestedDescriptionChangeHandler () {
        // @ts-ignore
        // console.log("this is",this.type == "number")
        // console.log("nestedDescriptionChangeHandler called")
        
        // @ts-ignore
        let descriptionTitle = this.id
        // console.log(nestedDescriptionTitle, descriptionTitle)
        
         // @ts-ignore
        if (this.type=="number") nestedDescriptionObject[descriptionTitle] = parseFloat(this.value)
         // @ts-ignore
        else nestedDescriptionObject[descriptionTitle] = this.value
    }

    let inputFieldTypes={}
    inputFieldTypesReadable.subscribe((value)=>{
        inputFieldTypes=value
        // console.log("inputFieldTypes is",inputFieldTypes)
    })

    export let nestedDescriptionTitle;
    export let nestedDescriptionObject;
    export let disableInput;
</script>

<style>
    * {
       /* box-sizing: border-box; */
       padding: 0 10px;
   }
</style>

<h3>{nestedDescriptionTitle}</h3>
<div class="row gy-2 gx-3 align-items-center">
    {#each Object.entries(nestedDescriptionObject) as nestedDescriptionEntry}
        <div class="form-floating col-auto" style="padding: 5px; width:25%;" >
            <input class="form-control" id="{nestedDescriptionEntry[0]}" value={nestedDescriptionEntry[1]} 
                on:change={nestedDescriptionChangeHandler} type={inputFieldTypes[nestedDescriptionEntry[0]]} 
                placeholder="something" disabled={disableInput}>
            <label for="{nestedDescriptionEntry[0]}">{inputFieldNames[nestedDescriptionEntry[0]]}</label>
        </div>
    {/each}
</div>
<hr>