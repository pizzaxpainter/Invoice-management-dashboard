<script>
    import {submitDatabaseButtonClicked,inputFieldTypesReadable, selectedFileStore, selectedFileStoreString} from "../stores"
    import { onMount } from 'svelte';
    import { enhance } from "$app/forms";
    import {ungroupProperties} from  '../InvoiceUploadFunctions'
    import TaxesSubcomponent from "./TaxesSubcomponent.svelte"
    import NestedDescriptionSubcomponent from "./NestedDescriptionSubcomponents.svelte"
    import ItemLinesSubcomponent from "./ItemLinesSubcomponent.svelte"
    import ObjectInformationSubcomponent from "./ObjectInformationSubcomponent.svelte"
    import jsPDF from 'jspdf';
    import html2canvas from 'html2canvas';
    import 'bootstrap/dist/css/bootstrap.css';

    function compileDataHandler() {
        if (invoiceInstance.direct_access.invoice_number == null || invoiceInstance.direct_access.invoice_number =="") {
            alert("Please enter an invoice number")
            return
        }
        if (invoiceInstance.direct_access.date == null || invoiceInstance.direct_access.date =="") {
            alert("Please select the date of the invoice")
            return
        }
        if (invoiceInstance.customer_information._id == -1) {
            alert('Please choose a customer');
            return
        }
        if (invoiceInstance.merchant_information._id == -1) {
            alert('Please choose a merchant');
            return
        }
        if (!allowEditViewInvoice) invoice_id=""
        // console.log("compileData clicked")
        invoiceJsonString = JSON.stringify(invoiceInstance)
        // console.log("On compile, invoiceInstance is",invoiceInstance)
        // console.log(invoiceJsonString)
        // console.log("invoice_id is", invoice_id)
        complileButtonClicked = true
        disableEditViewButton = true
    }

    async function convertFileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
        });
    }

    function base64ToFile(base64String, filename) {
        var arr = base64String.split(','),
            mime = arr[0].match(/:(.*?);/)[1],
            bstr = atob(arr[1]), 
            n = bstr.length, 
            u8arr = new Uint8Array(n);
        while(n--){
            u8arr[n] = bstr.charCodeAt(n);
        }
        return new File([u8arr], filename, {type:mime});
    }

    // Treat the result as a component, and not as a second page.
    function submitToDBHandler() {
        // console.log("submitToDBHandler clicked")
        submitDbButtonClicked = true
        submitDatabaseButtonClicked.set(true);        
        
        // goto('/invoice_upload/invoice_upload_confirmation')
        selectedFile = null;
        selectedFileString = null;
        selectedFileResult = null;
        invoiceString = "";
        invoiceType = "";
        fileUrl = "";
        // Invoke the deleteLink function here
        deleteLink();
    }

    function editViewHandler() {
        disableInput = !disableInput
        if (disableInput) editViewDescription = "Edit Invoice"
        else editViewDescription = "Finish Edit"
    }

    let inputFieldTypes={}
    inputFieldTypesReadable.subscribe((value)=>{
        inputFieldTypes=value
        // console.log("inputFieldTypes is",inputFieldTypes)
    })

    // step 1
    // import invoiceInstance from '../sample_invoicedata.json'
    export let invoiceInstance;
    export let disableInput
    export let allowEditViewInvoice;
    export let customerList;
    export let merchantList;
    export let invoice_id;
    // export let invoiceLocation;
    // const invoiceLocationStore = readable(invoiceLocation);
    let invoiceJsonString = ""
    let editViewDescription = "Edit Invoice"
    
    
    // variables that affect UI behaviour
    // can include merchantInformationRefresher
    // submitDbButtonClicked can be implemented as a popup notification too,
    //      just like how you confirm submission on edimension
    let complileButtonClicked = false;
    let submitDbButtonClicked = false;
    let disableEditViewButton = false
    
    const {
        item_lines, taxes, 
        bank_informations,
        customer_information, direct_access, 
        locale, merchant_information
    } = invoiceInstance 

    // console.log("customerList is", customerList)
    // console.log("merchantList is",merchantList)
    // console.log("before ",invoiceInstance)

    let selectedFile = null;
    let selectedFileString = null;
    let selectedFileResult = null;
    let fileUrl = "";
    let invoiceString = "";
    let invoiceType = "";

    let invoiceImageString
    let invoiceImageType
    
    if (allowEditViewInvoice) {
        selectedFileStoreString.subscribe((fileString) => {
        selectedFileString = fileString;
        if (selectedFileString) {
                // console.log("Invoice String is received in frontend (EditConfirmComponent.svelte) from frontend ([...slugs]]/+page.svelte)")
                // console.log(selectedFileString)
                selectedFileString = selectedFileString.replace("base64", "base64,");
                try {
                    selectedFileResult = base64ToFile(selectedFileString, "invoice.pdf");
                    // console.log("Base64 to File conversion success");
                    // console.log(selectedFileResult);
                    selectedFileStore.set(selectedFileResult);
                    // console.log(selectedFileStore);
                    // console.log("Set is successful");
                } catch (error) {
                    console.error("Base64 to File conversion error:", error);
                }
            }
        });
    }

    selectedFileStore.subscribe((file) => {
        // console.log(file);
        onMount(() => {
        selectedFile = file;
        if (selectedFile) {
            // Create a base-64 and type
            async function asyncTask() {
                // console.log("asyncTask() 2 is executed")
                invoiceType = selectedFile.type;
                invoiceString = await convertFileToBase64(selectedFile);
                if (invoiceString) {
                    // console.log("File to Base64 conversion success")
                    // console.log(invoiceString.slice(0, 50))
                }
                invoiceImageType = selectedFile.type;
                invoiceImageString = invoiceString;
            }
            if (selectedFile.type == "application/pdf"){
                fileUrl = URL.createObjectURL(selectedFile);
                // console.log("asyncTask() 1 is executed")
                asyncTask();
            }
            else {
                    // Create a new image element
                    const imgElem = document.createElement("img");
                    
                    // Set the src to the selected file
                    imgElem.src = URL.createObjectURL(selectedFile);

                    // Append the image to the body
                    document.body.appendChild(imgElem);
                    

                    html2canvas(imgElem).then((canvas) => {
                        let pdf = new jsPDF('p', 'mm', 'a4'); // A4 size page of PDF
                        let imgData = canvas.toDataURL('image/png');
                        let imgProps = pdf.getImageProperties(imgData);
                        let pdfWidth = pdf.internal.pageSize.getWidth();
                        let pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
                        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
                        
                        // Convert the PDF to a Blob object
                        let pdfBlob = new Blob([pdf.output('blob')], {type: 'application/pdf'});
                        
                        // Create an object URL from the Blob
                        fileUrl = URL.createObjectURL(pdfBlob);
                        // console.log("URL is created")
                        // console.log(fileUrl)
                        document.body.removeChild(imgElem);
                        // console.log("asyncTask() 1 is executed")
                        asyncTask();
                    });
                }   
            }
        });
    });

    function openFile() {
        if (fileUrl) {
            window.open(fileUrl, "_blank");
            }
    }

    function deleteLink() {
        if (fileUrl) {
            URL.revokeObjectURL(fileUrl);
            }
    }

</script>


<style>
    .form {
        font-size:large;
    }
</style>


<h2>
    <button class="btn btn-outline-primary" on:click={openFile}>Click me to see image of invoice</button>
    {#if allowEditViewInvoice}
        <div style="display: flex; align-items: center;">
            <button class="btn btn-outline-primary" on:click={editViewHandler} disabled={disableEditViewButton}>{editViewDescription}</button>
            <form method="POST" action="?/deleteInDatabase" use:enhance>
                <input name="invoice_id" type="text" id="invoice_id" bind:value={invoice_id} style="display: none;">
                <button class="btn btn-outline-primary" type="submit" disabled={disableEditViewButton}>Delete invoice</button>
            </form>
        </div>
    {/if}
</h2>
<hr>
{#if !complileButtonClicked}
    <div class="form" >
        <NestedDescriptionSubcomponent disableInput={disableInput} nestedDescriptionTitle="Direct Access" nestedDescriptionObject={direct_access}></NestedDescriptionSubcomponent>
        <ObjectInformationSubcomponent subject="customer" disableInput={disableInput} objectTitle="Outlet Information" objectList={customerList} invoiceInstance={invoiceInstance}></ObjectInformationSubcomponent>
        <ObjectInformationSubcomponent subject="merchant" disableInput={disableInput} objectTitle="Supplier Information" objectList={merchantList} invoiceInstance={invoiceInstance}></ObjectInformationSubcomponent>
        <NestedDescriptionSubcomponent disableInput={disableInput} nestedDescriptionTitle="Locale" nestedDescriptionObject={locale}></NestedDescriptionSubcomponent>
        <NestedDescriptionSubcomponent disableInput={disableInput} nestedDescriptionTitle="Bank Informations" nestedDescriptionObject={bank_informations}></NestedDescriptionSubcomponent>
        <TaxesSubcomponent disableInput={disableInput} taxes={taxes}></TaxesSubcomponent>
        <ItemLinesSubcomponent disableInput={disableInput} item_lines={item_lines}></ItemLinesSubcomponent>
        <button type="submit" on:click={compileDataHandler} class="btn btn-primary">Compile Data</button>
    </div>
{:else}
    <form method="POST" action="?/submitToDatabase" use:enhance>
        <input name="invisible-input" type="text" id="invisible-input" bind:value={invoiceJsonString} style="display: none;">
        <input name="invoice_id" type="text" id="invoice_id" bind:value={invoice_id} style="display: none;">
        <input name="invoiceType" type="text" id="invoiceType" bind:value={invoiceImageType} style="display: none;">
        <input name="invoiceString" type="text" id="invoiceString" bind:value={invoiceImageString} style="display: none;">
        <button id="submitToDatabaseButton" type="submit" class="btn btn-primary" on:click={submitToDBHandler}>Submit to Database</button>
    </form>
    {#if submitDbButtonClicked}
        <h2>Submitting to database, please wait....</h2>
    {/if}
{/if}


