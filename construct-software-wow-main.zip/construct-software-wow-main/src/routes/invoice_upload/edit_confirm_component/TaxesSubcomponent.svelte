<script>
    import {inputFieldTypesReadable} from "../stores"
    import {inputFieldNames, changeTaxes} from "../InvoiceUploadFunctions"

    function taxesChangeHandler() {
        // @ts-ignore
        // console.log("this is", this.type)
        // @ts-ignore
        let [taxNumberTitle, taxFieldTitle] = this.id.split(",")
        // @ts-ignore
        taxes[taxNumberTitle][taxFieldTitle] = parseFloat(this.value)
    }
    
    function triggerAddTaxes() {
        changeTaxes(taxes)
        taxesRefresher = !taxesRefresher
    }
    function triggerRemoveTaxes() {
        changeTaxes(taxes,false)
        taxesRefresher = !taxesRefresher
    }

    let inputFieldTypes={}
    inputFieldTypesReadable.subscribe((value)=>{
        inputFieldTypes=value
        // console.log("inputFieldTypes is",inputFieldTypes)
    })

    export let taxes;
    export let disableInput
    
    let taxesRefresher = false

</script>

<style>
     * {
        /* box-sizing: border-box; */
        padding: 0 10px;
    }
</style>

<h4>Taxes</h4>
{#key taxesRefresher}
    {#each taxes as tax, taxNumber}
        <div class="row gy-2 gx-3 align-items-center">
            {#each Object.entries(tax) as tax_entry}
                <div class="form-floating col-auto" style="padding: 5px; width:25%;" >
                    <input class="form-control" id="{taxNumber},{tax_entry[0]}" value={tax_entry[1]} on:change={taxesChangeHandler} 
                        type={inputFieldTypes[tax_entry[0]]} placeholder="something" disabled={disableInput}>
                    <label for="{taxNumber},{tax_entry[0]}">{inputFieldNames[tax_entry[0]]}</label>
                    <!-- <br> -->
                </div>
            {/each}
        </div>
    {/each}
{/key}
<button class="btn btn-secondary" type="button" on:click={triggerAddTaxes} disabled={disableInput}>Add item</button>
<button class="btn btn-secondary" type="button" on:click={triggerRemoveTaxes} disabled={disableInput}>Remove item</button>
<hr>