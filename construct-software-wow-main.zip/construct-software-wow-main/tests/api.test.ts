import { CustomerInfo, find as findCustomerInfo } from "$lib/models/cust_info"
import { Invoice } from "$lib/models/invoice"
import { MerchantInfo } from "$lib/models/merch_info";
import { ObjectId } from "mongodb";
import { expect, test, type APIRequestContext } from "@playwright/test";
import { existsSync, readFile } from "fs";
import { setCookieVals } from "./setCookieVals";
import { generateRandomString, generateRandomNum } from "./random_generator";

let request: APIRequestContext;

test.beforeAll(async ({ browser }) => {
  const browserContext = await browser.newContext()
  const cookievals = await setCookieVals();
  browserContext.addCookies(cookievals);
  request = browserContext.request;
});

/************************* CustomerInfo - POST ********************************* */

test.describe('Testing POST APIs for CustomerInfo', () => {
  const customer_info = new CustomerInfo();
  const customer_info_other = new CustomerInfo();
  let customer_id = new ObjectId();
  let customer_id_other = new ObjectId();

  test('POST one customer_info object with valid values', async ({ }) => {
    customer_info.customer_name = generateRandomString();
    customer_info.customer_address = generateRandomString();
    const cust_post_request = { obj: customer_info, add_if_null: false };
    const post_reply = await request.post('/api/cust_info', { data: cust_post_request });

    expect(post_reply.status()).toEqual(200);

    //Delete it in the end
    customer_id = (await post_reply.json()).id;
    await request.delete('/api/cust_info', { data: { obj_id: customer_id } });
  });

  test('POST one customer_info object with null values, but add_if_null is true', async ({ }) => {
    customer_info.customer_name = null;
    customer_info.customer_address = generateRandomString();
    const cust_post_request = { obj: customer_info, add_if_null: true };
    const post_reply = await request.post('/api/cust_info', { data: cust_post_request });

    expect(post_reply.status()).toEqual(200);

    //Delete it in the end
    customer_id = (await post_reply.json()).id;
    await request.delete('/api/cust_info', { data: { obj_id: customer_id } });
  });

  test('POST one customer_info object with null values, but add_if_null is false', async ({ }) => {
    customer_info.customer_name = null;
    customer_info.customer_address = generateRandomString();
    const cust_post_request = { obj: customer_info, add_if_null: false };
    const post_reply = await request.post('/api/cust_info', { data: cust_post_request });

    expect(post_reply.status()).toEqual(400);
  });

  test('POST one customer_info object with same name, different address', async ({ }) => {
    customer_info.customer_name = generateRandomString();
    customer_info.customer_address = generateRandomString();
    const cust_post_request = { obj: customer_info, add_if_null: false };
    const post_reply = await request.post('/api/cust_info', { data: cust_post_request });

    customer_info_other.customer_name = customer_info.customer_name;
    customer_info_other.customer_address = generateRandomString();
    const cust_post_request2 = { obj: customer_info_other, add_if_null: false };
    const post_reply2 = await request.post('/api/cust_info', { data: cust_post_request2 });

    expect(post_reply2.status()).toEqual(200);

    //Delete it in the end
    customer_id = (await post_reply.json()).id;
    await request.delete('/api/cust_info', { data: { obj_id: customer_id } });
    customer_id_other = (await post_reply2.json()).id;
    await request.delete('/api/cust_info', { data: { obj_id: customer_id_other } });
  });

  test('POST one customer_info object with same address, different name', async ({ }) => {
    customer_info.customer_name = generateRandomString();
    customer_info.customer_address = generateRandomString();
    const cust_post_request = { obj: customer_info, add_if_null: false };
    const post_reply = await request.post('/api/cust_info', { data: cust_post_request });

    customer_info_other.customer_name = generateRandomString();
    customer_info_other.customer_address = customer_info.customer_address;
    const cust_post_request2 = { obj: customer_info_other, add_if_null: false };
    const post_reply2 = await request.post('/api/cust_info', { data: cust_post_request2 });

    expect(post_reply2.status()).toEqual(200);

    //Delete it in the end
    customer_id = (await post_reply.json()).id;
    await request.delete('/api/cust_info', { data: { obj_id: customer_id } });
    customer_id_other = (await post_reply2.json()).id;
    await request.delete('/api/cust_info', { data: { obj_id: customer_id_other } });
  });

  test('POST one customer_info object with same name, same address', async ({ }) => {
    customer_info.customer_name = generateRandomString();
    customer_info.customer_address = generateRandomString();
    const cust_post_request = { obj: customer_info, add_if_null: false };
    const post_reply = await request.post('/api/cust_info', { data: cust_post_request });

    customer_info_other.customer_name = customer_info.customer_name;
    customer_info_other.customer_address = customer_info.customer_address;
    const cust_post_request2 = { obj: customer_info_other, add_if_null: false };
    const post_reply2 = await request.post('/api/cust_info', { data: cust_post_request2 });

    expect(post_reply2.status()).toEqual(401);

    //Delete it in the end
    customer_id = (await post_reply.json()).id;
    await request.delete('/api/cust_info', { data: { obj_id: customer_id } });
  });
})

/************************* CustomerInfo - PATCH ********************************* */

test.describe('Testing PATCH APIs for CustomerInfo', () => {
  const customer_info = new CustomerInfo();
  const customer_info_other = new CustomerInfo();
  let customer_id = new ObjectId();
  let customer_id_other = new ObjectId();

  test.beforeEach(async ({ }) => { //Add something to edit
    customer_info.customer_name = generateRandomString();
    customer_info.customer_address = generateRandomString();
    const cust_add_request = { obj: customer_info, add_if_null: false };
    const cust_reply = await request.post('/api/cust_info', { data: cust_add_request });
    customer_id = (await cust_reply.json()).id;

    customer_info_other.customer_name = generateRandomString();
    customer_info_other.customer_address = generateRandomString();
    const cust_add_request_other = { obj: customer_info_other, add_if_null: false };
    const cust_reply_other = await request.post('/api/cust_info', { data: cust_add_request_other });
    customer_id_other = (await cust_reply_other.json()).id;
  })

  test.afterEach(async ({ }) => {
    await request.delete('/api/cust_info', { data: { obj_id: customer_id } });
    await request.delete('/api/cust_info', { data: { obj_id: customer_id_other } });
  })

  test('Edit customer_info object once', async ({ }) => {
    customer_info.customer_name = generateRandomString();
    customer_info.customer_address = generateRandomString();
    const cust_edit_request = { obj_id: customer_id, editted_obj: customer_info, add_if_null: false };
    const edit_reply = await request.patch('/api/cust_info', { data: cust_edit_request });

    expect(edit_reply.status()).toEqual(200);
  });

  test('Edit customer_info object with null name/address, but add_if_null is true', async ({ }) => {
    customer_info.customer_name = generateRandomString();
    customer_info.customer_address = null;
    const cust_edit_request = { obj_id: customer_id, editted_obj: customer_info, add_if_null: true };
    const edit_reply = await request.patch('/api/cust_info', { data: cust_edit_request });

    expect(edit_reply.status()).toEqual(200);
  });

  test('Edit customer_info object once with null name/address, but add_if_null is false', async ({ }) => {
    customer_info.customer_name = null;
    customer_info.customer_address = generateRandomString();
    const cust_edit_request = { obj_id: customer_id, editted_obj: customer_info, add_if_null: false };
    const edit_reply = await request.patch('/api/cust_info', { data: cust_edit_request });

    expect(edit_reply.status()).toEqual(400);
  });

  test('Edit same customer_info object twice', async ({ }) => {
    customer_info.customer_name = generateRandomString();
    customer_info.customer_address = generateRandomString();
    let cust_edit_request = { obj_id: customer_id, editted_obj: customer_info, add_if_null: false };
    let edit_reply = await request.patch('/api/cust_info', { data: cust_edit_request });
    expect(edit_reply.status()).toEqual(200);

    customer_info.customer_name = generateRandomString();
    customer_info.customer_address = generateRandomString();
    cust_edit_request = { obj_id: customer_id, editted_obj: customer_info, add_if_null: false };
    edit_reply = await request.patch('/api/cust_info', { data: cust_edit_request });
    expect(edit_reply.status()).toEqual(200);
  });

  test('Edit customer_info object but to a value to an existing entry', async ({ }) => {
    customer_info.customer_name = customer_info_other.customer_name;
    customer_info.customer_address = customer_info_other.customer_address;
    const cust_edit_request = { obj_id: customer_id, editted_obj: customer_info, add_if_null: false };
    const edit_reply = await request.patch('/api/cust_info', { data: cust_edit_request });

    expect(edit_reply.status()).toEqual(401);
  });

  test('Edit customer_info object, but provide a non-existent objectID', async ({ }) => {
    customer_info.customer_name = generateRandomString();
    customer_info.customer_address = generateRandomString();
    const cust_edit_request = { obj_id: new ObjectId(), editted_obj: customer_info, add_if_null: false };
    const edit_reply = await request.patch('/api/cust_info', { data: cust_edit_request });

    expect(edit_reply.status()).toEqual(400);
  });
})


/************************* CustomerInfo - DELETE ********************************* */

test.describe('Testing DELETE APIs for CustomerInfo', () => {
  const customer_info = new CustomerInfo();
  let customer_id = new ObjectId();

  test('DELETE one customer_info object', async ({ }) => {
    //Add it
    customer_info.customer_name = generateRandomString();
    customer_info.customer_address = generateRandomString();
    const cust_post_request = { obj: customer_info, add_if_null: false };
    const post_reply = await request.post('/api/cust_info', { data: cust_post_request });

    //Delete it
    customer_id = (await post_reply.json()).id;
    const delete_reply = await request.delete('/api/cust_info', { data: { obj_id: customer_id } });
    expect(delete_reply.status()).toEqual(200);
  });

  test('DELETE one customer_info object two times', async ({ }) => {
    //Add it
    customer_info.customer_name = generateRandomString();
    customer_info.customer_address = generateRandomString();
    const cust_post_request = { obj: customer_info, add_if_null: false };
    const post_reply = await request.post('/api/cust_info', { data: cust_post_request });

    //Delete it
    customer_id = (await post_reply.json()).id;
    await request.delete('/api/cust_info', { data: { obj_id: customer_id } });
    const delete_reply = await request.delete('/api/cust_info', { data: { obj_id: customer_id } });
    expect(delete_reply.status()).toEqual(400);
  });

  test('Delete an objectid that doesnt even exist', async ({ }) => {
    customer_id = new ObjectId()
    const delete_reply = await request.delete('/api/cust_info', { data: { obj_id: customer_id } });
    expect(delete_reply.status()).toEqual(400);
  });

})

/************************* CustomerInfo - GET ********************************* */

test('Search for customer info', async ({ }) => {
  const getResponse = await request.get('/api/cust_info');
  expect(getResponse.status()).toEqual(200)
});

/************************* MerchantInfo - POST ********************************* */

test.describe('Testing POST APIs for MerchantInfo', () => {
  const merchant_info = new MerchantInfo();
  const merchant_info_other = new MerchantInfo();
  let merchant_id = new ObjectId();
  let merchant_id_other = new ObjectId();

  test('POST one merchant_info object with valid values', async ({ }) => {
    merchant_info.merchant_name = generateRandomString();
    merchant_info.merchant_address = generateRandomString();
    const merch_post_request = { obj: merchant_info, add_if_null: false };
    const post_reply = await request.post('/api/merch_info', { data: merch_post_request });

    expect(post_reply.status()).toEqual(200);

    //Delete it in the end
    merchant_id = (await post_reply.json()).id;
    await request.delete('/api/merch_info', { data: { obj_id: merchant_id } });
  });

  test('POST one merchant_info object with null values, but add_if_null is true', async ({ }) => {
    merchant_info.merchant_name = null;
    merchant_info.merchant_address = generateRandomString();
    const merch_post_request = { obj: merchant_info, add_if_null: true };
    const post_reply = await request.post('/api/merch_info', { data: merch_post_request });

    expect(post_reply.status()).toEqual(200);

    //Delete it in the end
    merchant_id = (await post_reply.json()).id;
    await request.delete('/api/merch_info', { data: { obj_id: merchant_id } });
  });

  test('POST one merchant_info object with null values, but add_if_null is false', async ({ }) => {
    merchant_info.merchant_name = null;
    merchant_info.merchant_address = generateRandomString();
    const merch_post_request = { obj: merchant_info, add_if_null: false };
    const post_reply = await request.post('/api/merch_info', { data: merch_post_request });

    expect(post_reply.status()).toEqual(400);
  });

  test('POST one merchant_info object with same name, different address', async ({ }) => {
    merchant_info.merchant_name = generateRandomString();
    merchant_info.merchant_address = generateRandomString();
    const merch_post_request = { obj: merchant_info, add_if_null: false };
    const post_reply = await request.post('/api/merch_info', { data: merch_post_request });

    merchant_info_other.merchant_name = merchant_info.merchant_name;
    merchant_info_other.merchant_address = generateRandomString();
    const merch_post_request2 = { obj: merchant_info_other, add_if_null: false };
    const post_reply2 = await request.post('/api/merch_info', { data: merch_post_request2 });

    expect(post_reply2.status()).toEqual(200);

    //Delete it in the end
    merchant_id = (await post_reply.json()).id;
    await request.delete('/api/merch_info', { data: { obj_id: merchant_id } });
    merchant_id_other = (await post_reply2.json()).id;
    await request.delete('/api/merch_info', { data: { obj_id: merchant_id_other } });
  });

  test('POST one merchant_info object with same address, different name', async ({ }) => {
    merchant_info.merchant_name = generateRandomString();
    merchant_info.merchant_address = generateRandomString();
    const merch_post_request = { obj: merchant_info, add_if_null: false };
    const post_reply = await request.post('/api/merch_info', { data: merch_post_request });

    merchant_info_other.merchant_name = generateRandomString();
    merchant_info_other.merchant_address = merchant_info.merchant_address;
    const merch_post_request2 = { obj: merchant_info_other, add_if_null: false };
    const post_reply2 = await request.post('/api/merch_info', { data: merch_post_request2 });

    expect(post_reply2.status()).toEqual(200);

    //Delete it in the end
    merchant_id = (await post_reply.json()).id;
    await request.delete('/api/merch_info', { data: { obj_id: merchant_id } });
    merchant_id_other = (await post_reply2.json()).id;
    await request.delete('/api/merch_info', { data: { obj_id: merchant_id_other } });
  });

  test('POST one merchant_info object with same name, same address', async ({ }) => {
    merchant_info.merchant_name = generateRandomString();
    merchant_info.merchant_address = generateRandomString();
    const merch_post_request = { obj: merchant_info, add_if_null: false };
    const post_reply = await request.post('/api/merch_info', { data: merch_post_request });

    merchant_info_other.merchant_name = merchant_info.merchant_name;
    merchant_info_other.merchant_address = merchant_info.merchant_address;
    const merch_post_request2 = { obj: merchant_info_other, add_if_null: false };
    const post_reply2 = await request.post('/api/merch_info', { data: merch_post_request2 });

    expect(post_reply2.status()).toEqual(401);

    //Delete it in the end
    merchant_id = (await post_reply.json()).id;
    await request.delete('/api/merch_info', { data: { obj_id: merchant_id } });
  });
})

/************************* MerchantInfo - PATCH ********************************* */

test.describe('Testing PATCH APIs for MerchantInfo', () => {
  const merchant_info = new MerchantInfo();
  const merchant_info_other = new MerchantInfo();
  let merchant_id = new ObjectId();
  let merchant_id_other = new ObjectId();

  test.beforeEach(async ({ }) => { //Add something to edit
    merchant_info.merchant_name = generateRandomString();
    merchant_info.merchant_address = generateRandomString();
    const merch_add_request = { obj: merchant_info, add_if_null: false };
    const merch_reply = await request.post('/api/merch_info', { data: merch_add_request });
    merchant_id = (await merch_reply.json()).id;

    merchant_info_other.merchant_name = generateRandomString();
    merchant_info_other.merchant_address = generateRandomString();
    const merch_add_request_other = { obj: merchant_info_other, add_if_null: false };
    const merch_reply_other = await request.post('/api/merch_info', { data: merch_add_request_other });
    merchant_id_other = (await merch_reply_other.json()).id;
  })

  test.afterEach(async ({ }) => {
    await request.delete('/api/merch_info', { data: { obj_id: merchant_id } });
    await request.delete('/api/merch_info', { data: { obj_id: merchant_id_other } });
  })

  test('Edit merchant_info object once', async ({ }) => {
    merchant_info.merchant_name = generateRandomString();
    merchant_info.merchant_address = generateRandomString();
    const merch_edit_request = { obj_id: merchant_id, editted_obj: merchant_info, add_if_null: false };
    const edit_reply = await request.patch('/api/merch_info', { data: merch_edit_request });

    expect(edit_reply.status()).toEqual(200);
  });

  test('Edit merchant_info object with null name/address, but add_if_null is true', async ({ }) => {
    merchant_info.merchant_name = generateRandomString();
    merchant_info.merchant_address = null;
    const merch_edit_request = { obj_id: merchant_id, editted_obj: merchant_info, add_if_null: true };
    const edit_reply = await request.patch('/api/merch_info', { data: merch_edit_request });

    expect(edit_reply.status()).toEqual(200);
  });

  test('Edit merchant_info object once with null name/address, but add_if_null is false', async ({ }) => {
    merchant_info.merchant_name = null;
    merchant_info.merchant_address = generateRandomString();
    const merch_edit_request = { obj_id: merchant_id, editted_obj: merchant_info, add_if_null: false };
    const edit_reply = await request.patch('/api/merch_info', { data: merch_edit_request });

    expect(edit_reply.status()).toEqual(400);
  });

  test('Edit same merchant_info object twice', async ({ }) => {
    merchant_info.merchant_name = generateRandomString();
    merchant_info.merchant_address = generateRandomString();
    let merch_edit_request = { obj_id: merchant_id, editted_obj: merchant_info, add_if_null: false };
    let edit_reply = await request.patch('/api/merch_info', { data: merch_edit_request });
    expect(edit_reply.status()).toEqual(200);

    merchant_info.merchant_name = generateRandomString();
    merchant_info.merchant_address = generateRandomString();
    merch_edit_request = { obj_id: merchant_id, editted_obj: merchant_info, add_if_null: false };
    edit_reply = await request.patch('/api/merch_info', { data: merch_edit_request });
    expect(edit_reply.status()).toEqual(200);
  });

  test('Edit merchant_info object but to a value to an existing entry', async ({ }) => {
    merchant_info.merchant_name = merchant_info_other.merchant_name;
    merchant_info.merchant_address = merchant_info_other.merchant_address;
    const merch_edit_request = { obj_id: merchant_id, editted_obj: merchant_info, add_if_null: false };
    const edit_reply = await request.patch('/api/merch_info', { data: merch_edit_request });

    expect(edit_reply.status()).toEqual(401);
  });

  test('Edit merchant_info object, but provide a non-existent objectID', async ({ }) => {
    merchant_info.merchant_name = generateRandomString();
    merchant_info.merchant_address = generateRandomString();
    const merch_edit_request = { obj_id: new ObjectId(), editted_obj: merchant_info, add_if_null: false };
    const edit_reply = await request.patch('/api/merch_info', { data: merch_edit_request });

    expect(edit_reply.status()).toEqual(400);
  });
})


/************************* MerchantInfo - DELETE ********************************* */

test.describe('Testing DELETE APIs for MerchantInfo', () => {
  const merchant_info = new MerchantInfo();
  let merchant_id = new ObjectId();

  test('DELETE one merchant_info object', async ({ }) => {
    //Add it
    merchant_info.merchant_name = generateRandomString();
    merchant_info.merchant_address = generateRandomString();
    const merch_post_request = { obj: merchant_info, add_if_null: false };
    const post_reply = await request.post('/api/merch_info', { data: merch_post_request });

    //Delete it
    merchant_id = (await post_reply.json()).id;
    const delete_reply = await request.delete('/api/merch_info', { data: { obj_id: merchant_id } });
    expect(delete_reply.status()).toEqual(200);
  });

  test('DELETE one merchant_info object two times', async ({ }) => {
    //Add it
    merchant_info.merchant_name = generateRandomString();
    merchant_info.merchant_address = generateRandomString();
    const merch_post_request = { obj: merchant_info, add_if_null: false };
    const post_reply = await request.post('/api/merch_info', { data: merch_post_request });

    //Delete it
    merchant_id = (await post_reply.json()).id;
    await request.delete('/api/merch_info', { data: { obj_id: merchant_id } });
    const delete_reply = await request.delete('/api/merch_info', { data: { obj_id: merchant_id } });
    expect(delete_reply.status()).toEqual(400);
  });

  test('Delete an objectid that doesnt even exist', async ({ }) => {
    merchant_id = new ObjectId()
    const delete_reply = await request.delete('/api/merch_info', { data: { obj_id: merchant_id } });
    expect(delete_reply.status()).toEqual(400);
  });

})

/************************* MerchantInfo - GET ********************************* */

test('Search for merchant info', async ({ }) => {
  const getResponse = await request.get('/api/merch_info');
  expect(getResponse.status()).toEqual(200)
});

/************************* Invoice - POST ********************************* */

test.describe('Testing Invoice APIs', () => {
  const merchant_info = new MerchantInfo();
  const customer_info = new CustomerInfo();
  let merch_id = new ObjectId();
  let cust_id = new ObjectId();
  let invoice_id = new ObjectId();

  test.beforeAll(async ({ }) => { //Add dummy customer and merchants
    merchant_info.merchant_name = generateRandomString();
    merchant_info.merchant_address = generateRandomString();
    customer_info.customer_name = generateRandomString();
    customer_info.customer_address = generateRandomString();

    const cust_add_request = { obj: customer_info, add_if_null: false };
    const merch_add_request = { obj: merchant_info, add_if_null: false };
    const cust_reply = await request.post('/api/cust_info', { data: cust_add_request });
    const merch_reply = await request.post('/api/merch_info', { data: merch_add_request });

    cust_id = (await cust_reply.json()).id;
    merch_id = (await merch_reply.json()).id;
  })

  test.afterEach(async ({ }) => { //Delete invoices after each tests.
    await request.delete('api/invoice', { data: { obj_id: invoice_id } });
  })

  test.afterAll(async ({ }) => { //Delete those dummies
    await request.delete('/api/cust_info', { data: { obj_id: cust_id } })
    await request.delete('/api/merch_info', { data: { obj_id: merch_id } })
  })

  test('POST a single, valid invoice', async ({ }) => {
    let invoice_obj: any = new Invoice();

    invoice_obj.customer_information = customer_info;
    invoice_obj.merchant_information = merchant_info;
    invoice_obj.invoice_number = generateRandomString();
    invoice_obj.amount_due = generateRandomNum();

    const invoice_add_request = { obj: invoice_obj, cust_autoadd: false, cust_allownull: false, merch_autoadd: false, merch_allownull: false, img: "data:image/jpeg;base64,/9j/4AAQSkZJ" };
    const response = await request.post('/api/invoice', { data: invoice_add_request });
    invoice_id = (await response.json()).result._id;

    expect(response.status()).toEqual(200);
  });
  test('Testing DELETE function for an invoice', async ({ }) => {
    let invoice_obj: any = new Invoice();

    invoice_obj.customer_information = customer_info;
    invoice_obj.merchant_information = merchant_info;
    invoice_obj.invoice_number = generateRandomString();
    invoice_obj.amount_due = generateRandomNum();

    const invoice_add_request = { obj: invoice_obj, cust_autoadd: false, cust_allownull: false, merch_autoadd: false, merch_allownull: false, img: "data:image/jpeg;base64,/9j/4AAQSkZJ" };
    const response = await request.post('/api/invoice', { data: invoice_add_request });
    invoice_id = (await response.json()).result._id;

    expect(response.status()).toEqual(200);
  });

  test('Add the same valid invoice two times. Should return an error', async ({ }) => {
    let invoice_obj: any = new Invoice();

    invoice_obj.customer_information = customer_info;
    invoice_obj.merchant_information = merchant_info;
    invoice_obj.invoice_number = generateRandomString();
    invoice_obj.amount_due = generateRandomNum();

    const invoice_add_request = { obj: invoice_obj, cust_autoadd: false, cust_allownull: false, merch_autoadd: false, merch_allownull: false, img: "data:image/jpeg;base64,/9j/4AAQSkZJ" };
    let response = await request.post('/api/invoice', { data: invoice_add_request });
    invoice_id = (await response.json()).result._id;

    expect(response.status()).toEqual(200); //The first time, it should succeed

    response = await request.post('/api/invoice', { data: invoice_add_request });
    expect(response.status()).toEqual(401); //The second time, it should fail.
  });

});


/************************* Upload File, Delete Folder, Export CSV ********************************* */
test.describe('[Upload Invoice APIs]', () => {
  function readFileAsBase64(filePath) {
    // Read the file asynchronously
    return new Promise((resolve, reject) => {
      readFile(filePath, (err, data) => {
        if (err) {
          reject(err);
          return;
        }

        // Convert the file data to base64 string
        const base64String = data.toString('base64');
        resolve(base64String);
      });
    });
  }


  /************************* Upload File Test ********************************* */
  test('Create Temporary Invoice File then delete temp folder', async ({ }) => {
    const filename = "testingfile.png"
    const fileData = await readFileAsBase64("tests/sample_files/" + filename);
    const username = "TestingFileName"
    // Usage example
    const data = { filename: filename, data: fileData, username: username };
    let response = await request.post('api/writeFile', { data });


    let expected_data = {
      status: 200,
      body: { msg: `File created successfully: ${filename}` },
    };

    await expect(response.status()).toEqual(200);
    await expect(await response.json()).toEqual(expected_data);

    const filePath = 'src/lib/python_files/tempFiles/' + username + "/" + filename; // Replace with the actual path to the file you want to check

    // Use the fs.existsSync() function to check if the file exists
    const fileExists = existsSync(filePath);

    // Expect the file to exist
    await expect(fileExists).toBe(true);

  });

  /************************* OCR API Test **********************************/

  test('OCR API Test', async ({ }) => {
    const filename = "testingfile.png"
    // const fileData = await readFileAsBase64("tests/sample_files/" + filename);
    const username = "TestingFileName"
    // Usage example
    const data = {
      filename: filename,
      username: username,
    }
    const response = await request.post('api/eden_api', { data });

    const jsonRes = await response.json()
    const responsestatus = jsonRes.status
    const responseBody = jsonRes.body

    const comparator = { "customer_information": { "customer_name": null, "customer_id": null, "customer_tax_id": null, "customer_mailing_address": null, "customer_billing_address": null, "customer_shipping_address": null, "customer_service_address": null, "customer_remittance_address": null, "abn_number": null, "gst_number": null, "pan_number": null, "vat_number": null }, "merchant_information": { "merchant_name": "Stanford Plumbing & Heating", "merchant_address": "Stanford Plumbing & Heating\n123 Madison drive, Seattle, WA, 7829Q", "merchant_phone": "990-120-4560", "merchant_email": null, "merchant_fax": null, "merchant_website": "www.plumbingstanford.com", "merchant_tax_id": null, "merchant_siret": null, "merchant_siren": null, "abn_number": null, "gst_number": null, "pan_number": null, "vat_number": null }, "invoice_number": "#INV02081", "invoice_total": 2844.8, "invoice_subtotal": 2540, "gratuity": null, "amount_due": 2844.8, "previous_unpaid_balance": null, "discount": 50, "taxes": [{ "value": 304.8, "rate": null }], "service_charge": null, "payment_term": null, "purchase_order": null, "date": "11/11/18", "due_date": "12/01/18", "service_date": null, "service_due_date": null, "po_number": null, "locale": { "currency": "USD", "language": null }, "bank_informations": { "account_number": null, "iban": null, "bsb": null, "sort_code": null, "vat_number": null, "rooting_number": null, "swift": null }, "item_lines": [{ "description": "Installed new kitchen sink (hours)", "quantity": 3, "amount": 150, "unit_price": 50, "discount": null, "product_code": null, "date_item": null, "tax_item": null, "tax_rate": null }, { "description": "Toto sink", "quantity": 1, "amount": 500, "unit_price": 500, "discount": null, "product_code": null, "date_item": null, "tax_item": null, "tax_rate": null }, { "description": "Worcester greenstar magnetic system filter", "quantity": 1, "amount": 190, "unit_price": 190, "discount": null, "product_code": null, "date_item": null, "tax_item": null, "tax_rate": null }, { "description": "Nest smart thermostat", "quantity": 1, "amount": 250, "unit_price": 250, "discount": null, "product_code": null, "date_item": null, "tax_item": null, "tax_rate": null }, { "description": "Worcester Greenstar 30i", "quantity": 1, "amount": 1500, "unit_price": 1500, "discount": null, "product_code": null, "date_item": null, "tax_item": null, "tax_rate": null }] }
    const equalornot = haveSameKeys(comparator, responseBody.invoice)
    await expect(equalornot).toEqual(true)

  });

  test('Delete Temporary Folder', async ({ }) => {
    const filename = "testingfile.png"
    // const fileData = await readFileAsBase64("tests/sample_files/" + filename);
    const username = "TestingFileName"
    // Usage example
    const data = { username: username };
    let response = await request.post('api/deleteUserFolder', { data });


    let expected_data = { status: 200, body: { msg: 'Folder deleted successfully.' } };

    await expect(response.status()).toEqual(200);
    await expect(await response.json()).toEqual(expected_data);

    const filePath = 'src/lib/python_files/tempFiles/' + username + "/" + filename; // Replace with the actual path to the file you want to check

    // Use the fs.existsSync() function to check if the file exists
    const fileExists = existsSync(filePath);

    // Expect the file to exist
    await expect(fileExists).toBe(false);

  });

  const invoice1 = { "customer_information": { "_id": 1, "customer_name": "test_customer_A", "customer_address": "test_customer_address_A", "customer_email": null, "customer_id": null, "customer_tax_id": null, "customer_mailing_address": null, "customer_billing_address": null, "customer_shipping_address": null, "customer_service_address": null, "customer_remittance_address": null, "abn_number": null, "gst_number": null, "pan_number": null, "vat_number": null }, "merchant_information": { "_id": 2, "merchant_name": "test_merchant_B", "merchant_address": "test_merchant_address_B", "merchant_phone": null, "merchant_email": null, "merchant_fax": null, "merchant_website": null, "merchant_tax_id": null, "merchant_siret": null, "merchant_siren": null, "abn_number": null, "gst_number": null, "pan_number": null, "vat_number": null }, "taxes": [{ "value": 39.66, "rate": null }], "locale": { "currency": "USD", "language": null }, "bank_informations": { "account_number": null, "iban": null, "bsb": null, "sort_code": null, "vat_number": null, "rooting_number": null, "swift": null }, "item_lines": [{ "description": "FAB LAVENDER 5X2.1KG (3720)", "quantity": null, "amount": 19, "unit_price": 19, "discount": null, "product_code": "APF2100L", "date_item": null, "tax_item": null, "tax_rate": null }, { "description": "FAB PERFECT 5X2.3KG (4031)", "quantity": null, "amount": 38, "unit_price": 19, "discount": null, "product_code": "APF2300P", "date_item": null, "tax_item": null, "tax_rate": null }, { "description": "FAB PERFECT 18X720G (3294)", "quantity": 1, "amount": 25.2, "unit_price": 25.2, "discount": null, "product_code": "APF720P", "date_item": null, "tax_item": null, "tax_rate": null }, { "description": "PALKON MED SOAP 6X24'S (18021)", "quantity": 24, "amount": 13.2, "unit_price": 79.2, "discount": null, "product_code": "SC01", "date_item": null, "tax_item": null, "tax_rate": null }, { "description": "SIMILAC 3 2FL 6X850G (2029)", "quantity": 3, "amount": 121.11, "unit_price": 242.22, "discount": null, "product_code": "4505885", "date_item": null, "tax_item": null, "tax_rate": null }, { "description": "ENSURE LIFE VANILLA HMB 12X850G (1726)", "quantity": 2, "amount": 67.28, "unit_price": 403.68, "discount": null, "product_code": "4506027", "date_item": null, "tax_item": null, "tax_rate": null }], "invoice_number": "21074270", "invoice_total": null, "invoice_subtotal": 566.57, "gratuity": null, "amount_due": null, "previous_unpaid_balance": null, "discount": null, "service_charge": null, "payment_term": "CASH", "purchase_order": null, "date": "03/06/2020", "due_date": null, "service_date": null, "service_due_date": null, "po_number": "" };

  const invoice2 = { "customer_information": { "_id": 1, "customer_name": "test_customer_A", "customer_address": "test_customer_address_A", "customer_email": null, "customer_id": null, "customer_tax_id": null, "customer_mailing_address": null, "customer_billing_address": null, "customer_shipping_address": null, "customer_service_address": null, "customer_remittance_address": null, "abn_number": null, "gst_number": null, "pan_number": null, "vat_number": null }, "merchant_information": { "_id": 1, "merchant_name": "test_merchant_A", "merchant_address": "test_merchant_address_A", "merchant_phone": null, "merchant_email": null, "merchant_fax": null, "merchant_website": null, "merchant_tax_id": null, "merchant_siret": null, "merchant_siren": null, "abn_number": null, "gst_number": null, "pan_number": null, "vat_number": null }, "taxes": [{ "value": 24, "rate": null }], "locale": { "currency": null, "language": null }, "bank_informations": { "account_number": null, "iban": null, "bsb": null, "sort_code": null, "vat_number": null, "rooting_number": null, "swift": null }, "item_lines": [{ "description": "Shou Ding Tea", "quantity": 1250, "amount": 9, "unit_price": 8.8, "discount": null, "product_code": null, "date_item": null, "tax_item": null, "tax_rate": null }, { "description": "Green Tea\n+ X # K\nChinese Tea Teabag G/J/T/P", "quantity": 4, "amount": 680, "unit_price": 220, "discount": null, "product_code": null, "date_item": null, "tax_item": null, "tax_rate": null }, { "description": "Hill Bird Brand Tea Dust", "quantity": 200, "amount": 1150, "unit_price": 2.4, "discount": null, "product_code": null, "date_item": null, "tax_item": null, "tax_rate": null }], "invoice_number": "287811\nA", "invoice_total": 18.97, "invoice_subtotal": 1830, "gratuity": null, "amount_due": 18.97, "previous_unpaid_balance": null, "discount": -57, "service_charge": null, "payment_term": null, "purchase_order": null, "date": "27-10-2021", "due_date": null, "service_date": null, "service_due_date": null, "po_number": null };

  test('Single Invoices to CSV', async ({ }) => {
    // Usage example
    const data = { json_array: [invoice1] };
    const response = await request.post('api/saveFile', { data });
    const expected_data = { status: 200, csvSTRING: `CategoryName,ItemNo,ItemName,ItemDescription,UOM,Qty,CostPrice\n"null","APF2100L","FAB LAVENDER 5X2.1KG (3720)","FAB LAVENDER 5X2.1KG (3720)","null","null","19"\n"null","APF2300P","FAB PERFECT 5X2.3KG (4031)","FAB PERFECT 5X2.3KG (4031)","null","null","19"\n"null","APF720P","FAB PERFECT 18X720G (3294)","FAB PERFECT 18X720G (3294)","null","1","25.2"\n"null","SC01","PALKON MED SOAP 6X24'S (18021)","PALKON MED SOAP 6X24'S (18021)","null","24","79.2"\n"null","4505885","SIMILAC 3 2FL 6X850G (2029)","SIMILAC 3 2FL 6X850G (2029)","null","3","242.22"\n"null","4506027","ENSURE LIFE VANILLA HMB 12X850G (1726)","ENSURE LIFE VANILLA HMB 12X850G (1726)","null","2","403.68"\n` };

    expect(response.status()).toEqual(200);
    expect(await response.json()).toEqual(expected_data);


  });



  test('Multiple Invoices to CSV', async ({ }) => {
    // Usage example
    const data = { json_array: [invoice1, invoice2] };
    const response = await request.post('api/saveFile', { data });
    const expected_data = { status: 200, csvSTRING: `CategoryName,ItemNo,ItemName,ItemDescription,UOM,Qty,CostPrice\n"null","APF2100L","FAB LAVENDER 5X2.1KG (3720)","FAB LAVENDER 5X2.1KG (3720)","null","null","19"\n"null","APF2300P","FAB PERFECT 5X2.3KG (4031)","FAB PERFECT 5X2.3KG (4031)","null","null","19"\n"null","APF720P","FAB PERFECT 18X720G (3294)","FAB PERFECT 18X720G (3294)","null","1","25.2"\n"null","SC01","PALKON MED SOAP 6X24'S (18021)","PALKON MED SOAP 6X24'S (18021)","null","24","79.2"\n"null","4505885","SIMILAC 3 2FL 6X850G (2029)","SIMILAC 3 2FL 6X850G (2029)","null","3","242.22"\n"null","4506027","ENSURE LIFE VANILLA HMB 12X850G (1726)","ENSURE LIFE VANILLA HMB 12X850G (1726)","null","2","403.68"\n"null","null","Shou Ding Tea","Shou Ding Tea","null","1250","8.8"\n"null","null","Green Tea\n+ X # K\nChinese Tea Teabag G/J/T/P","Green Tea\n+ X # K\nChinese Tea Teabag G/J/T/P","null","4","220"\n"null","null","Hill Bird Brand Tea Dust","Hill Bird Brand Tea Dust","null","200","2.4"\n` };

    expect(response.status()).toEqual(200);
    expect(await response.json()).toEqual(expected_data);
  });


  function haveSameKeys(jsonObj1, jsonObj2) {
    const obj1Keys = Object.keys(jsonObj1);
    const obj2Keys = Object.keys(jsonObj2);

    // Sort the arrays of keys to ensure order doesn't affect the comparison
    obj1Keys.sort();
    obj2Keys.sort();

    // Check if both arrays of keys have the same elements
    return JSON.stringify(obj1Keys) === JSON.stringify(obj2Keys);
  }
});