export async function setCookieVals(){
    const cookies = [{name:"session_id",value:"123",path:"/",domain:"localhost:2424"},
                     {name:"isAdmin",value:"true",path:"/",domain:"localhost:2424"}]
    return cookies
}



export async function generateRandomString(length,type) {
    let charset;
    if(type == "all"){
       charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    }else{
      charset = "1234567890"
    }
    let randomString = '';
    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * charset.length);
      randomString += charset[randomIndex];
    }
    return randomString;
  }
