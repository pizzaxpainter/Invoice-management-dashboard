import { test, expect, type Page ,type APIRequestContext} from '@playwright/test';
import { error, json } from '@sveltejs/kit';
import { actions} from '../src/routes/invoice_upload/+page.server';
import { groupProperties } from 'src/routes/invoice_upload/InvoiceUploadFunctions';
import { chromium } from '@playwright/test';
import { errorListObject } from "../src/routes/invoice_upload/InvoiceUploadFunctions";
import { setCookieVals } from './setCookieVals';
import { generateRandomString } from './setCookieVals';

// test.describe.configure({ mode: 'parallel' }); 

test.describe("[Upload Invoice Unit Testing]" ,() => {


// #uncomment when testing mock api
let mockJson = {"amazon":{"status":"success","extracted_data":[{"customer_information":{"customer_name":"Allen Smith","customer_address":"Allen Smith\\n87 Private st, Seattle, WA","customer_email":null,"customer_id":null,"customer_tax_id":null,"customer_mailing_address":null,"customer_billing_address":null,"customer_shipping_address":null,"customer_service_address":null,"customer_remittance_address":null,"abn_number":null,"gst_number":null,"pan_number":null,"vat_number":null},"merchant_information":{"merchant_name":"Stanford Plumbing & Heating","merchant_address":"Stanford Plumbing & Heating\\n123 Madison drive, Seattle, WA 7829Q","merchant_phone":"990-120-4560","merchant_email":null,"merchant_fax":null,"merchant_website":"www.plumbingstanford.com","merchant_tax_id":null,"merchant_siret":null,"merchant_siren":null,"abn_number":null,"gst_number":null,"pan_number":null,"vat_number":null},"invoice_number":"#INV02081TESTINGOCRRECT","invoice_total":2844.8,"invoice_subtotal":2540.0,"gratuity":null,"amount_due":2844.8,"previous_unpaid_balance":null,"discount":50.0,"taxes":[{"value":304.8,"rate":null}],"service_charge":null,"payment_term":null,"purchase_order":null,"date":"11/11/18","due_date":"12/01/18","service_date":null,"service_due_date":null,"po_number":null,"locale":{"currency":"USD","language":null},"bank_informations":{"account_number":null,"iban":null,"bsb":null,"sort_code":null,"vat_number":null,"rooting_number":null,"swift":null},"item_lines":[{"description":"Installed new kitchen sink (hours)","quantity":3,"amount":150.0,"unit_price":50.0,"discount":null,"product_code":null,"date_item":null,"tax_item":null,"tax_rate":null},{"description":"Toto sink","quantity":1,"amount":500.0,"unit_price":500.0,"discount":null,"product_code":null,"date_item":null,"tax_item":null,"tax_rate":null},{"description":"Worcester greenstar magnetic system filter","quantity":1,"amount":190.0,"unit_price":190.0,"discount":null,"product_code":null,"date_item":null,"tax_item":null,"tax_rate":null},{"description":"Nest smart thermostat","quantity":1,"amount":250.0,"unit_price":250.0,"discount":null,"product_code":null,"date_item":null,"tax_item":null,"tax_rate":null},{"description":"Worcester Greenstar 30","quantity":1,"amount":1500.0,"unit_price":1500.0,"discount":null,"product_code":null,"date_item":null,"tax_item":null,"tax_rate":null}]}]},"eden-ai":{"status":"success","extracted_data":[{"customer_information":{"customer_name":"Allen Smith","customer_address":"Allen Smith\\n87 Private st, Seattle, WA","customer_email":null,"customer_id":null,"customer_tax_id":null,"customer_mailing_address":null,"customer_billing_address":null,"customer_shipping_address":null,"customer_service_address":null,"customer_remittance_address":null,"abn_number":null,"gst_number":null,"pan_number":null,"vat_number":null},"merchant_information":{"merchant_name":"Stanford Plumbing & Heating","merchant_address":"Stanford Plumbing & Heating\\n123 Madison drive, Seattle, WA 7829Q","merchant_phone":"990-120-4560","merchant_email":null,"merchant_fax":null,"merchant_website":"www.plumbingstanford.com","merchant_tax_id":null,"merchant_siret":null,"merchant_siren":null,"abn_number":null,"gst_number":null,"pan_number":null,"vat_number":null},"invoice_number":"#INV02081","invoice_total":2844.8,"invoice_subtotal":2540.0,"gratuity":null,"amount_due":2844.8,"previous_unpaid_balance":null,"discount":50.0,"taxes":[{"value":304.8,"rate":null}],"service_charge":null,"payment_term":null,"purchase_order":null,"date":"11/11/18","due_date":"12/01/18","service_date":null,"service_due_date":null,"po_number":null,"locale":{"currency":"USD","language":null},"bank_informations":{"account_number":null,"iban":null,"bsb":null,"sort_code":null,"vat_number":null,"rooting_number":null,"swift":null},"item_lines":[{"description":"Installed new kitchen sink (hours)","quantity":3,"amount":150.0,"unit_price":50.0,"discount":null,"product_code":null,"date_item":null,"tax_item":null,"tax_rate":null},{"description":"Toto sink","quantity":1,"amount":500.0,"unit_price":500.0,"discount":null,"product_code":null,"date_item":null,"tax_item":null,"tax_rate":null},{"description":"Worcester greenstar magnetic system filter","quantity":1,"amount":190.0,"unit_price":190.0,"discount":null,"product_code":null,"date_item":null,"tax_item":null,"tax_rate":null},{"description":"Nest smart thermostat","quantity":1,"amount":250.0,"unit_price":250.0,"discount":null,"product_code":null,"date_item":null,"tax_item":null,"tax_rate":null},{"description":"Worcester Greenstar 30","quantity":1,"amount":1500.0,"unit_price":1500.0,"discount":null,"product_code":null,"date_item":null,"tax_item":null,"tax_rate":null}]}]}}
let jsonForOCR = mockJson.amazon.extracted_data[0]
let jsoncopy = mockJson.amazon.extracted_data[0]
groupProperties(jsonForOCR)


const mockedResponseData = 
{
  "type": "success",
  "status": 200,
  "data": "[{\"successOcr\":1,\"customerList\":2,\"merchantList\":24,\"invoiceJson\":35},true,[3,7,11,15,19],{\"_id\":4,\"customer_name\":5,\"customer_address\":6,\"customer_email\":6,\"customer_id\":6,\"customer_tax_id\":6,\"customer_mailing_address\":6,\"customer_billing_address\":6,\"customer_shipping_address\":6,\"customer_service_address\":6,\"customer_remittance_address\":6,\"abn_number\":6,\"gst_number\":6,\"pan_number\":6,\"vat_number\":6},-1,\"Please select an outlet from this list\",null,{\"_id\":8,\"customer_name\":9,\"customer_address\":10,\"customer_email\":6,\"customer_id\":6,\"customer_tax_id\":6,\"customer_mailing_address\":6,\"customer_billing_address\":6,\"customer_shipping_address\":6,\"customer_service_address\":6,\"customer_remittance_address\":6,\"abn_number\":6,\"gst_number\":6,\"pan_number\":6,\"vat_number\":6},\"64ce57ce0a754305cd0bfe60\",\"outlet A\",\"outlet address A\",{\"_id\":12,\"customer_name\":13,\"customer_address\":14,\"customer_email\":6,\"customer_id\":6,\"customer_tax_id\":6,\"customer_mailing_address\":6,\"customer_billing_address\":6,\"customer_shipping_address\":6,\"customer_service_address\":6,\"customer_remittance_address\":6,\"abn_number\":6,\"gst_number\":6,\"pan_number\":6,\"vat_number\":6},\"64ce5867ac22fb5e9f1c6c48\",\"jonathan\",\"malaysia\",{\"_id\":16,\"customer_name\":17,\"customer_address\":18,\"customer_email\":6,\"customer_id\":6,\"customer_tax_id\":6,\"customer_mailing_address\":6,\"customer_billing_address\":6,\"customer_shipping_address\":6,\"customer_service_address\":6,\"customer_remittance_address\":6,\"abn_number\":6,\"gst_number\":6,\"pan_number\":6,\"vat_number\":6},\"64ce90410dbdf4c13bdbff7e\",\"outlet B\",\"outlet address B\",{\"_id\":20,\"customer_name\":21,\"customer_address\":22,\"customer_email\":23,\"customer_id\":23,\"customer_tax_id\":23,\"customer_mailing_address\":23,\"customer_billing_address\":23,\"customer_shipping_address\":23,\"customer_service_address\":23,\"customer_remittance_address\":23,\"abn_number\":23,\"gst_number\":23,\"pan_number\":23,\"vat_number\":23},\"64cf8ab3441aaeee66cf8ef1\",\"Alex\",\"12345^TFGHUJHNBGFreswe4rTGHUY^trfDE$RF\",\"\",[25,27,31],{\"_id\":4,\"merchant_name\":26,\"merchant_address\":6,\"merchant_phone\":6,\"merchant_email\":6,\"merchant_fax\":6,\"merchant_website\":6,\"merchant_tax_id\":6,\"merchant_siret\":6,\"merchant_siren\":6,\"abn_number\":6,\"gst_number\":6,\"pan_number\":6,\"vat_number\":6},\"Please select a supplier from this list\",{\"_id\":28,\"merchant_name\":29,\"merchant_address\":30,\"merchant_phone\":6,\"merchant_email\":6,\"merchant_fax\":6,\"merchant_website\":6,\"merchant_tax_id\":6,\"merchant_siret\":6,\"merchant_siren\":6,\"abn_number\":6,\"gst_number\":6,\"pan_number\":6,\"vat_number\":6},\"64ce583cac22fb5e9f1c6c46\",\"Supplier AB\",\"Supplier address AB\",{\"_id\":32,\"merchant_name\":33,\"merchant_address\":34,\"merchant_phone\":6,\"merchant_email\":6,\"merchant_fax\":6,\"merchant_website\":6,\"merchant_tax_id\":6,\"merchant_siret\":6,\"merchant_siren\":6,\"abn_number\":6,\"gst_number\":6,\"pan_number\":6,\"vat_number\":6},\"64ce584eac22fb5e9f1c6c47\",\"John Ng\",\"bedok \",{\"customer_information\":3,\"merchant_information\":25,\"taxes\":36,\"locale\":39,\"bank_informations\":41,\"item_lines\":42,\"direct_access\":61},[37],{\"value\":38,\"rate\":6},304.8,{\"currency\":40,\"language\":6},\"USD\",{\"account_number\":6,\"iban\":6,\"bsb\":6,\"sort_code\":6,\"vat_number\":6,\"rooting_number\":6,\"swift\":6},[43,48,52,55,58],{\"description\":44,\"quantity\":45,\"amount\":46,\"unit_price\":47,\"discount\":6,\"product_code\":6,\"date_item\":6,\"tax_item\":6,\"tax_rate\":6},\"Installed new kitchen sink (hours)\",3,150,50,{\"description\":49,\"quantity\":50,\"amount\":51,\"unit_price\":51,\"discount\":6,\"product_code\":6,\"date_item\":6,\"tax_item\":6,\"tax_rate\":6},\"Toto sink\",1,500,{\"description\":53,\"quantity\":50,\"amount\":54,\"unit_price\":54,\"discount\":6,\"product_code\":6,\"date_item\":6,\"tax_item\":6,\"tax_rate\":6},\"Worcester greenstar magnetic system filter\",190,{\"description\":56,\"quantity\":50,\"amount\":57,\"unit_price\":57,\"discount\":6,\"product_code\":6,\"date_item\":6,\"tax_item\":6,\"tax_rate\":6},\"Nest smart thermostat\",250,{\"description\":59,\"quantity\":50,\"amount\":60,\"unit_price\":60,\"discount\":6,\"product_code\":6,\"date_item\":6,\"tax_item\":6,\"tax_rate\":6},\"Worcester Greenstar 30i\",1500,{\"invoice_number\":62,\"invoice_total\":63,\"invoice_subtotal\":64,\"gratuity\":6,\"amount_due\":63,\"previous_unpaid_balance\":6,\"discount\":47,\"service_charge\":6,\"payment_term\":6,\"purchase_order\":6,\"date\":65,\"due_date\":66,\"service_date\":6,\"service_due_date\":6,\"po_number\":6},\"#INV02081\",2844.8,2540,\"11/11/18\",\"12/01/18\"]"
}
const fulfilroutes = {
  status: 200,
  contentType: 'application/json',
  body: JSON.stringify(mockedResponseData),
}

const mockedDatabaseResponse = {
  "type": "redirect",
  "status": 300,
  "location": "/upload_confirmation"
}

const dbfulfilResponse =  {
  status: 200,
  contentType: 'application/json',
  body: JSON.stringify(mockedDatabaseResponse),
}


// //__to generate traces__

// test('Trace generate', async ({request}) => {
//   //TRACE CODE
// let browser = await chromium.launch()
// let context = await browser.newContext()
// await context.tracing.start({ screenshots: true, snapshots: true });
// let page = await context.newPage()
// await page.goto("/")
// await context.tracing.startChunk()
// // ---
// // await context.tracing.stopChunk({ path: 'trace1.zip' });
//   test.setTimeout(120000);
//   await page.goto('/');
//   await page.goto('/invoice_upload');
//   await page.getByRole('textbox').click({timeout:60000} );

//   await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
//   await page.getByRole('button', { name: 'Upload to OCR software' }).click({timeout:60000} );
  
//   // await expect(page.getByRole('button', { name: 'dashboard' })).toBeVisible({timeout:60000} );
//   await page.route('**/submitToOcr', async route => {
//     await route.fulfill(fulfilFailRoutes)
//   });

//   await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
//   await page.getByRole('button', { name: 'Upload to OCR software' }).click({timeout:60000} );
  
//   // await expect(page.getByRole('button', { name: 'dashboard' })).toBeVisible({timeout:60000} );
//   await context.tracing.stopChunk({ path: 'trace1.zip' });
//   // await page.getByLabel('invoice_number').click();
//   // await page.getByLabel('invoice_number').fill(temporaryInvoiceID);

//   // //Prepare the invoice page and compile 
//   // await page.getByLabel('Options').selectOption('64ce57ce0a754305cd0bfe60');
//   // await page.locator('#selectFromList').nth(1).selectOption('64ce583cac22fb5e9f1c6c46');
//   // await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000} );
//   // await expect(page.getByRole('button', { name: 'Submit to Database' })).toBeVisible({timeout:60000});

//   // // Submit Invoice
//   // await page.getByRole('button', { name: 'Submit to Database' }).click({timeout:60000});
//   // await expect(page.getByRole('heading', { name: 'Navigation to other pages' })).toBeVisible({timeout:60000});
//   // const newExtension = await page.evaluate(() => window.location.pathname);
//   // await expect(newExtension).toBe('/upload_confirmation');

//   });

let page: Page;

//-----------------Unit tests-----------------
test.beforeEach(async ({ browser }) => {
  const browserContext = await browser.newContext()
  const cookievals = await setCookieVals();
  browserContext.addCookies(cookievals);
  page = await browserContext.newPage()
});

// 'Unit_test_1: Dashboard navigation to Invoice Upload Route:'
test('Unit_test_1: Dashboard navigation to Invoice Upload Route', async ({ }) => {
  // const browserContext = await browser.newContext()
  // const cookievals = await setCookieVals();
  // browserContext.addCookies(cookievals);
  // const page_with_cookies = await browserContext.newPage()

  test.setTimeout(120000);
  await page.goto('/');
  await page.getByRole('link', { name: 'Invoice Upload' }).click({timeout:60000} );
  await expect(page.getByRole('heading', { name: 'Please select your invoice here' })).toBeVisible({timeout:60000} );
})

// 'Unit_test_2: Invoice selected is invalid --> Submit to OCR available (button enabled)'
test('Unit_test_2: Invoice selected is invalid --> Submit to OCR available (button enabled)', async ({}) => {
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto('/invoice_upload');
  
  await page.getByRole('textbox').click({timeout:60000} );
  await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
 
  await expect(await page.getByRole('textbox').inputValue()).not.toBe("");
  await expect(page.getByRole('button', { name: 'Upload to OCR software' })).toBeEnabled({timeout:60000} );
})

// 'Unit_test_3: Invoice selected is invalid --> Submit to OCR unavailable (button disabled) --> Swap file to valid --> Button enabled'
test('Unit_test_3: Invoice selected is invalid --> Submit to OCR unavailable (button disabled) --> Swap file to valid --> Button enabled', async ({ }) => {
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto('/invoice_upload');
  
  await page.getByRole('textbox').click({timeout:60000} );
  await page.getByRole('textbox').setInputFiles('tests/sample_files/wrongFileType.docx');
 
  await expect(page.getByRole('button', { name: 'Upload to OCR software' })).toBeDisabled({timeout:60000} );
  await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
 
  await expect(page.getByRole('button', { name: 'Upload to OCR software' })).toBeEnabled({timeout:60000} );
})

// 'Unit_test_4: File --> Mock OCR API --> View invoice --> Compile --> Mock Invoice Submission API --> Submission Success'
test('Unit_test_4: File --> Mock OCR API --> View invoice --> Compile --> Mock Invoice Submission API --> Submission Success', async ({}) => {
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto('/invoice_upload');
  await page.getByRole('textbox').click({timeout:60000});

  //Mock OCR API
  await page.route('**/submitToOcr', async route => {
    await route.fulfill(fulfilroutes)
  });

  await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
  await page.getByRole('button', { name: 'Upload to OCR software' }).click({timeout:60000} );
  await expect(page.getByRole('heading', { name: 'OCR Result' })).toBeVisible({timeout:60000})
  await expect(page.getByRole('heading', { name: 'Click me to see image of invoice' })).toBeVisible({timeout:60000})

  //Prepare the invoice page and compile 
  await page.getByLabel('Options').selectOption('64ce57ce0a754305cd0bfe60');
  await page.locator('#selectFromList').nth(1).selectOption('64ce583cac22fb5e9f1c6c46');
  await page.getByLabel('Invoice Number').fill('FillInvoice');
  await page.getByLabel('Date', { exact: true }).fill('3012-03-12');
  await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000} );
  
  await expect(page.getByRole('button', { name: 'Submit to Database' })).toBeVisible({timeout:60000});

  //Mock DB API
  await page.route('**/submitToDatabase', async route => {
    await route.fulfill(dbfulfilResponse)
  });

  // Submit Invoice
  await page.getByRole('button', { name: 'Submit to Database' }).click({timeout:60000});
  await expect(page.getByRole('heading', { name: 'Navigation to other pages' })).toBeVisible({timeout:60000});
  const newExtension = await page.evaluate(() => window.location.pathname);
  await expect(newExtension).toBe('/upload_confirmation');

  });

// 'Unit_test_5: File --> Mock OCR API --> View Invoice --> Edit Invoice --> Compile --> Mock Invoice Submission API --> Submission Success'
test('Unit_test_5: File --> Mock OCR API --> View Invoice --> Edit Invoice --> Compile --> Mock Invoice Submission API --> Submission Success', async ({ }) => {
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto('/invoice_upload');
  await page.getByRole('textbox').click({timeout:60000} );

  //Mock OCR API
  await page.route('**/submitToOcr', async route => {
    await route.fulfill(fulfilroutes)
  });

  await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
  // Make api call for intercept
  await page.getByRole('button', { name: 'Upload to OCR software' }).click({timeout:60000} );
  await expect(page.getByRole('heading', { name: 'OCR Result' })).toBeVisible({timeout:60000})
  await expect(page.getByRole('heading', { name: 'Click me to see image of invoice' })).toBeVisible({timeout:60000})


  //Test Editable Page.
  await page.getByLabel('Invoice Number').click({timeout:60000} );
  await expect(page.getByLabel('Invoice Number')).toBeEditable({timeout:60000} );
  await expect(page.getByLabel('Options')).toBeVisible({timeout:60000} );
  await page.getByRole('button', { name: 'Add item' }).nth(1).click({timeout:60000} );
  await expect(page.getByRole('rowheader', { name: '6' })).toBeVisible({timeout:60000} );
  await expect(page.locator('[id="\\35 \\,description"]')).toBeEditable({timeout:60000} );
  await expect(page.locator('[id="\\35 \\,quantity"]')).toBeEditable({timeout:60000} );
  await expect(page.locator('[id="\\35 \\,unit_price"]')).toBeEditable({timeout:60000} );
  await expect(page.locator('[id="\\35 \\,amount"]')).toBeEditable({timeout:60000} );
  await expect(page.locator('[id="\\35 \\,discount"]')).toBeEditable({timeout:60000} );
  await expect(page.locator('[id="\\35 \\,product_code"]')).toBeEditable({timeout:60000} );
  await expect(page.locator('[id="\\35 \\,date_item"]')).toBeEditable({timeout:60000} );
  await expect(page.locator('[id="\\35 \\,tax_item"]')).toBeEditable({timeout:60000} );
  await expect(page.locator('[id="\\35 \\,tax_rate"]')).toBeEditable({timeout:60000} );

  await page.getByRole('button', { name: 'Remove item' }).nth(1).click({timeout:60000} );
  await expect(page.getByRole('rowheader', { name: '6' })).toBeHidden({timeout:60000} );

  await page.getByLabel('Options').selectOption('64ce57ce0a754305cd0bfe60');
  await page.locator('#selectFromList').nth(1).selectOption('64ce583cac22fb5e9f1c6c46');
  await page.getByLabel('Invoice Number').fill('FillInvoice');
  await page.getByLabel('Date', { exact: true }).fill('3012-03-12');
  await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000} );
  await expect(page.getByRole('button', { name: 'Submit to Database' })).toBeVisible({timeout:60000});

  //Mock DB API
  await page.route('**/submitToDatabase', async route => {
    await route.fulfill(dbfulfilResponse)
  });

  // Submit Invoice
  await page.getByRole('button', { name: 'Submit to Database' }).click({timeout:60000});
  await expect(page.getByRole('heading', { name: 'Navigation to other pages' })).toBeVisible({timeout:60000});
  const newExtension = await page.evaluate(() => window.location.pathname);
  await expect(newExtension).toBe('/upload_confirmation');
  });


// 'Unit_test_6: File --> Mock OCR API --> View invoice (Dont select both Merchants/Customer) --> Pop up warning message'
test('Unit_test_6: File --> Mock OCR API --> View invoice (Dont select both Merchants/Customer --> Pop up warning message)', async ({ }) => {
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto('/invoice_upload');
  await page.getByRole('textbox').click({timeout:60000} );

  //Mock OCR API
  await page.route('**/submitToOcr', async route => {
    await route.fulfill(fulfilroutes)
  });
  await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
  // Make api call for intercept
  await page.getByRole('button', { name: 'Upload to OCR software' }).click({timeout:60000} );
  await expect(page.getByRole('heading', { name: 'OCR Result' })).toBeVisible({timeout:60000})
  await expect(page.getByRole('heading', { name: 'Click me to see image of invoice' })).toBeVisible({timeout:60000})


  page.on('dialog', async (dialog) => {
    console.log("Pop up appear")
    await expect(dialog.message()).toEqual("Please choose a customer");
    await dialog.accept();
  });
  await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000} );
});

// 'Unit_test_7: File --> Mock OCR API --> View invoice (Dont select Merchants) --> Pop up warning message'
test('Unit_test_7: File --> Mock OCR API --> View invoice (Dont select Merchants) --> Pop up warning message', async ({ }) => {
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto('/invoice_upload');
  await page.getByRole('textbox').click({timeout:60000});

  //Mock OCR API
  await page.route('**/submitToOcr', async route => {
    await route.fulfill(fulfilroutes)
  });
  await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
  // Make api call for intercept
  await page.getByRole('button', { name: 'Upload to OCR software' }).click({timeout:60000} );
  await expect(page.getByRole('heading', { name: 'OCR Result' })).toBeVisible({timeout:60000})
  await expect(page.getByRole('heading', { name: 'Click me to see image of invoice' })).toBeVisible({timeout:60000})


page.on('dialog', async (dialog) => {
  console.log("Pop up appear")
await expect(dialog.message()).toEqual("Please choose a merchant");
await dialog.accept();
});
  await page.getByLabel('Options').selectOption('64ce57ce0a754305cd0bfe60');
  await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000} );

});


// 'Unit_test_8: File --> Mock OCR API --> View invoice (Dont select Customers) --> Pop up warning message'
test('Unit_test_8: File --> Mock OCR API --> View invoice (Dont select Customers) --> Pop up warning message', async ({ }) => {
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto('/invoice_upload');
  await page.getByRole('textbox').click({timeout:60000} );

  //Mock OCR API
  await page.route('**/submitToOcr', async route => {
    await route.fulfill(fulfilroutes)
  });
  await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
  // Make api call for intercept
  await page.getByRole('button', { name: 'Upload to OCR software' }).click({timeout:60000} );
  await expect(page.getByRole('heading', { name: 'OCR Result' })).toBeVisible({timeout:60000})
  await expect(page.getByRole('heading', { name: 'Click me to see image of invoice' })).toBeVisible({timeout:60000})


      page.on('dialog', async (dialog) => {
        console.log("Pop up appear")
    await expect(dialog.message()).toEqual("Please choose a customer");
    await dialog.accept();
  });

  await page.locator('#selectFromList').nth(1).selectOption('64ce583cac22fb5e9f1c6c46');
  await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000} );
});

// 'Unit_test_9: File --> Mock OCR API --> View invoice (Blank Invoice Number) --> Pop up warning message'
test('Unit_test_9: File --> Mock OCR API --> View invoice (Blank Invoice Number) --> Pop up warning message', async ({ }) => {
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto('/invoice_upload');
  await page.getByRole('textbox').click({timeout:60000} );

  //Mock OCR API
  await page.route('**/submitToOcr', async route => {
    await route.fulfill(fulfilroutes)
  });
  await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
  // Make api call for intercept
  await page.getByRole('button', { name: 'Upload to OCR software' }).click({timeout:60000} );
  await expect(page.getByRole('heading', { name: 'OCR Result' })).toBeVisible({timeout:60000})
  await expect(page.getByRole('heading', { name: 'Click me to see image of invoice' })).toBeVisible({timeout:60000})

      page.on('dialog', async (dialog) => {
        console.log("Pop up appear")
    await expect(dialog.message()).toEqual("Please enter an invoice number");
    await dialog.accept();
  });

  await page.getByLabel('Invoice Number').fill('');
  await page.getByLabel('Options').selectOption('64ce57ce0a754305cd0bfe60');
  await page.locator('#selectFromList').nth(1).selectOption('64ce583cac22fb5e9f1c6c46');
  await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000} );
});


// 'Unit_test_10: Upload Invoice Page --> Refresh --> Upload Invoice Page reset'
test('Unit_test_10: Upload Invoice Page --> Refresh --> Upload Invoice Page reset', async ({ }) => {
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto('/invoice_upload');
  await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
  await page.reload()
  await expect(await page.getByRole('textbox').inputValue()).toBe("");
});

// 'Unit_test_11: View Invoice Page --> Refresh --> Upload Invoice Page reset'
test('Unit_test_11: View Invoice Page --> Refresh --> Upload Invoice Page reset', async ({ }) => {
  test.setTimeout(120000);
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto('/invoice_upload');
  await page.getByRole('textbox').click({timeout:60000} );

  //Mock OCR API
  await page.route('**/submitToOcr', async route => {
    await route.fulfill(fulfilroutes)
  });
  await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
  // Make api call for intercept
  await page.getByRole('button', { name: 'Upload to OCR software' }).click({timeout:60000} );
  await expect(page.getByRole('heading', { name: 'OCR Result' })).toBeVisible({timeout:60000})
  await expect(page.getByRole('heading', { name: 'Click me to see image of invoice' })).toBeVisible({timeout:60000})

  await page.reload()
  await expect(await page.getByRole('textbox').inputValue()).toBe("");
});

// 'Unit_test_12: Invoice Compiled Page --> Refresh --> Upload Invoice Page reset'
test('Unit_test_12: Invoice Compiled Page --> Refresh --> Upload Invoice Page reset', async ({ }) => {
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto('/invoice_upload');
  await page.getByRole('textbox').click({timeout:60000} );

  //Mock OCR API
  await page.route('**/submitToOcr', async route => {
    await route.fulfill(fulfilroutes)
  });

  await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
  await page.getByRole('button', { name: 'Upload to OCR software' }).click({timeout:60000} );
  await expect(page.getByRole('heading', { name: 'OCR Result' })).toBeVisible({timeout:60000})
  await expect(page.getByRole('heading', { name: 'Click me to see image of invoice' })).toBeVisible({timeout:60000})


  //Prepare the invoice page and compile 
  await page.getByLabel('Options').selectOption('64ce57ce0a754305cd0bfe60');
  await page.locator('#selectFromList').nth(1).selectOption('64ce583cac22fb5e9f1c6c46');
  await page.getByLabel('Invoice Number').fill('FillInvoice');
  await page.getByLabel('Date', { exact: true }).fill('3012-03-12');
  await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000} );
  await expect(page.getByRole('button', { name: 'Submit to Database' })).toBeVisible({timeout:60000});
  await page.reload()
  await expect(await page.getByRole('textbox').inputValue()).toBe("");
});

// 'Unit_test_13: Upload Confirmation Page --> Navigate to '
test('Unit_test_13: Invoice Submitted Page --> Refresh --> Upload Invoice Page reset', async ({ }) => {
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto('/invoice_upload');
  await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
  await page.reload()
  await expect(await page.getByRole('textbox').inputValue()).toBe("");
});

//

//Error Page Testings
test('Error_Unit_Testing_1: Error Page', async ({}) => {
  test.setTimeout(120000);

  for (const key in errorListObject){
    console.log(key, errorListObject[key])
  await page.goto('/');
  await page.goto('/invoice_upload');
  await page.getByRole('textbox').click({timeout:60000} );
  const mockedResponseFail = 
  {
    "type": "error",
    "error": {
      "message": errorListObject[key]
    }
  }
  const fulfilFailRoutes =  {
    status: 200,
    contentType: 'application/json',
    body: JSON.stringify(mockedResponseFail),
  }
  await page.route('**/submitToOcr', async route => {
    await route.fulfill(fulfilFailRoutes)
  });

  await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
  await page.getByRole('button', { name: 'Upload to OCR software' }).click({timeout:60000} );
  await expect(page.getByRole('heading', { name: errorListObject[key] })).toBeVisible({timeout:60000} );
  }
  });

//-----------------Unit Change Testing-----------------

test('Unit_Change_test_1: Upload Confirmation page --> Dashboard', async ({ }) => {
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto("/upload_confirmation")
  await page.getByRole('button', { name: 'Dashboard' }).click({timeout:60000} );
  await new Promise((resolve) => setTimeout(resolve, 2000));
  const newExtension = await page.evaluate(() => window.location.pathname);
  await expect(newExtension).toBe('/protected');
});

test('Unit_Change_test_2: Upload Confirmation page --> Upload Invoice Page', async ({ }) => {
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto("/upload_confirmation")
  await page.getByRole('button', { name: 'Invoice Upload' }).click({timeout:60000} );
  await new Promise((resolve) => setTimeout(resolve, 2000));
  const newExtension = await page.evaluate(() => window.location.pathname);
  await expect(newExtension).toBe('/invoice_upload');
});

test('Unit_Change_test_3: Upload Confirmation page --> Invoice Search Page', async ({ }) => {
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto("/upload_confirmation")
  await page.getByRole('button', { name: 'Invoice Search' }).click({timeout:60000} );
  await new Promise((resolve) => setTimeout(resolve, 2000));
  const newExtension = await page.evaluate(() => window.location.pathname);
  await expect(newExtension).toBe('/invoice_search');
});

test('Unit_Change_test_4: Upload Confirmation page --> Add/edit supplier page', async ({ }) => {
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto("/upload_confirmation")
  await page.getByRole('button', { name: 'Add/Edit Suppliers' }).click({timeout:60000} );
  await new Promise((resolve) => setTimeout(resolve, 2000));
  const newExtension = await page.evaluate(() => window.location.pathname);
  await expect(newExtension).toBe('/edit_merchants');
});

test('Unit_Change_test_5: Upload Confirmation page --> Add/edit outlets page', async ({ }) => {
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto("/upload_confirmation")
  await page.getByRole('button', { name: 'Add/Edit Outlets' }).click({timeout:60000} );
  await new Promise((resolve) => setTimeout(resolve, 2000));
  const newExtension = await page.evaluate(() => window.location.pathname);
  await expect(newExtension).toBe('/edit_customers');
});

test('Unit_Change_test_6: Invoice View Page --> Add/edit supplier page', async ({ }) => {
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto('/invoice_upload');
  await page.getByRole('textbox').click({timeout:60000} );

  //Mock OCR API
  await page.route('**/submitToOcr', async route => {
    await route.fulfill(fulfilroutes)
  });

  await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
  await page.getByRole('button', { name: 'Upload to OCR software' }).click({timeout:60000} );
  await expect(page.getByRole('heading', { name: 'OCR Result' })).toBeVisible({timeout:60000})
  await expect(page.getByRole('heading', { name: 'Click me to see image of invoice' })).toBeVisible({timeout:60000})


  await page.getByRole('button', { name: 'add/edit outlets' }).click()
  
  await new Promise((resolve) => setTimeout(resolve, 2000));
  const newExtension = await page.evaluate(() => window.location.pathname);
  await expect(newExtension).toBe('/edit_customers');
});

test('Unit_Change_test_7: Invoice View Page --> Add/edit supplier page', async ({ }) => {
  test.setTimeout(120000);
  await page.goto('/');
  await page.goto('/invoice_upload');
  await page.getByRole('textbox').click({timeout:60000});

  //Mock OCR API
  await page.route('**/submitToOcr', async route => {
    await route.fulfill(fulfilroutes)
  });

  await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
  await page.getByRole('button', { name: 'Upload to OCR software' }).click({timeout:60000} );
  await expect(page.getByRole('heading', { name: 'OCR Result' })).toBeVisible({timeout:60000})
  await expect(page.getByRole('heading', { name: 'Click me to see image of invoice' })).toBeVisible({timeout:60000})


  await page.getByRole('button', { name: 'add/edit suppliers' }).click()
  
  await new Promise((resolve) => setTimeout(resolve, 2000));
  const newExtension = await page.evaluate(() => window.location.pathname);
  await expect(newExtension).toBe('/edit_merchants');
});

});

// //TRACE CODE
// let browser = await chromium.launch()
// let context = await browser.newContext()
// await context.tracing.start({ screenshots: true, snapshots: true });
// let page = await context.newPage()
// await page.goto("/")
// await context.tracing.startChunk()
// ---
// await context.tracing.stopChunk({ path: 'trace1.zip' });

