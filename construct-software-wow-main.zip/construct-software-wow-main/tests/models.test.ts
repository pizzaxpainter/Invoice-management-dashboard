import { expect, test } from "@playwright/test";
import * as cust_info from "$lib/models/cust_info";
import * as invoice from "$lib/models/invoice";
import { generateRandomString } from "./setCookieVals";
/************************* Customer Info - Adding ********************************* */
test.describe("[Models Testing]" ,() => {
test('Constructor for CustomerInfo object', () => {
    const customer_info = new cust_info.CustomerInfo();
    expect(customer_info.customer_name).toStrictEqual("");
    expect(customer_info.customer_id).toStrictEqual("");
    expect(customer_info.abn_number).toStrictEqual("");
    expect(customer_info._id).toBeUndefined;
})

test.describe('Convert parsed JSON to CustomerInfo', () => {
    let expected_object = new cust_info.CustomerInfo();

    test.beforeEach(() => {
        expected_object = {
            _id: undefined,
            customer_name: null,
            customer_address: null,
            customer_email: null,
            customer_id: null,
            customer_tax_id: null,
            customer_mailing_address: null,
            customer_billing_address: null,
            customer_shipping_address: null,
            customer_service_address: null,
            customer_remittance_address: null,
            abn_number: null,
            gst_number: null,
            pan_number: null,
            vat_number: null,
        }
    })
    
    test('Empty JSON', async() => {
        const parsed_json = {};
        const converted_object = cust_info.convertToCustomerInfo(parsed_json);
        expect(converted_object).toEqual(expected_object)
    })

    test('JSON with only valid values', async() => {
        const parsed_json = {customer_name: "Bobby Smith", customer_address: "Tampines", abn_number: "ABC123"};
        const converted_object = cust_info.convertToCustomerInfo(parsed_json);
        expected_object.customer_name = "Bobby Smith";
        expected_object.customer_address = "Tampines";
        expected_object.abn_number = "ABC123";
        expect(converted_object).toEqual(expected_object)
    })

    test('JSON with some properties that dont exist (they should be ignored)', async() => {
        const parsed_json = {blabblab: true, customer_name: "Alex Smith", customer_address: "SUTD", blub_blub: "ABC123"};
        const converted_object = cust_info.convertToCustomerInfo(parsed_json);
        expected_object.customer_name = "Alex Smith";
        expected_object.customer_address = "SUTD";
        expect(converted_object).toEqual(expected_object)
        
    })
    
    test('JSON with some valid properties but wrong types (they should be ignored)', async() => {
        const parsed_json = {customer_name: "Alex Smith", customer_address: "SUTD", abn_number: 123, gst_number: false};
        const converted_object = cust_info.convertToCustomerInfo(parsed_json);
        expected_object.customer_name = "Alex Smith";
        expected_object.customer_address = "SUTD";
        expect(converted_object).toEqual(expected_object)
    })

    test('JSON with only invalid properties and wrong types', async() => {
        const parsed_json = {customer_name: ["Alex Smith"], customer_address: 123.14, foo: "bar"};
        const converted_object = cust_info.convertToCustomerInfo(parsed_json);
        expect(converted_object).toEqual(expected_object)
    })
})

test.describe('Convert parsed JSON to Invoice Object', () => {
    
    test('Testing date conversion. Some valid, some invalid', async() => {
        const parsed_json = {"invoice_number": "ABC123", "date": "03/05/19", "due_date": "2020-05-12", "service_date": "Im  not a date"}
        const converted_object = invoice.convertToInvoice(parsed_json);
        expect(converted_object.invoice_number).toEqual("ABC123")
        expect(converted_object.date).toBeInstanceOf(Date) //No strict equality because the testing code seem to use a different time zone
        expect(converted_object.due_date).toBeInstanceOf(Date)
        expect(converted_object.service_date).toBeNull()
        expect(converted_object.service_due_date).toBeNull()
    })
})

test('Testing db queries for CustomerInfo', async() => {
    const to_add = new cust_info.CustomerInfo();
    let random = await generateRandomString(40)
    to_add.customer_name = "Alex";
    to_add.customer_address = random; //I lazy make new database. So let's just test with a gibberish value that will never duplicate
    let reply: any = await cust_info.insertOne(to_add);
    expect(reply.status).toEqual('Success')
    expect(reply.msg).toEqual("One customer info added"); //Add one value.

    let document: cust_info.CustomerInfo[] = await cust_info.find({customer_address: { $regex: random, $options: 'i'}}) //Surely no address will contain BgfREs right?
    expect(document.length).toEqual(1) //Find it. See if we get exactly 1 result

    reply = await cust_info.isExist({customer_address: random}); //See if it exists
    expect(reply).toStrictEqual(true)

    const document_id = document[0]._id.toJSON(); //Get the string version of the id
    reply = await cust_info.remove(document_id);
    expect(reply).toEqual({status:'Success', msg: "Deleted successfully"}); //Delete it

    document = await cust_info.find({customer_address: { $regex: random, $options: 'i'}})
    expect(document.length).toEqual(0) //Find it. See if we get 0 result

    reply = await cust_info.isExist({customer_address: random}); //See if it stops existing
    expect(reply).toStrictEqual(false)
})

});