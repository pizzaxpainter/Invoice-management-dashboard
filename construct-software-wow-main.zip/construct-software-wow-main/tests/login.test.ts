import { test, expect,type Page } from '@playwright/test';
import {getUserByEmail, createSession} from '../src/store/db.js';
import { generateRandomString } from './setCookieVals.js';
// test.describe.configure({ mode: 'parallel' });

test.describe("[Log in Functionality Testing]" ,() => {

//-----------------Unit tests-----------------
//test sign-in with admin rights -> can signup -> signout
test('Test_1: test login admin', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('heading', { name: 'Hi, login/register to get started' })).toBeVisible();
    await page.getByRole('link', { name: 'Sign in' }).click();
    await page.getByLabel('Email').click();
    await page.getByLabel('Email').fill('master@master.com');
    await page.getByLabel('Password').click();
    await page.getByLabel('Password').fill('master');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await expect(page.getByRole('heading', { name: 'Welcome, master@master.com!' })).toBeVisible();
    await expect(page.getByRole('link', { name: 'Sign up' })).toBeVisible();
    await page.getByRole('button', { name: 'Sign out' }).click();
    await expect(page.getByRole('heading', { name: 'Hi, login/register to get started' })).toBeVisible();
  });
 

//test sign-in without adminrights -> cannot signup -> signout
test('Test_2: test login non admin', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('heading', { name: 'Hi, login/register to get started' })).toBeVisible();
    await page.getByRole('link', { name: 'Sign in' }).click();
    await page.getByLabel('Email').click();
    await page.getByLabel('Email').fill('user@master.com');
    await page.getByLabel('Password').click();
    await page.getByLabel('Password').fill('user');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await expect(page.getByRole('heading', { name: 'Welcome, user@master.com!'})).toBeVisible();
    await expect(page.getByRole('link', { name: 'Sign up' })).toBeVisible({visible:false});
    await page.getByRole('button', { name: 'Sign out' }).click();
    await expect(page.getByRole('heading', { name: 'Hi, login/register to get started' })).toBeVisible();
  });

// test findUserbyEmail
  test('Test_3: find master account', async({ page }) => {
    let session = await createSession("user@master.com", "user", false);
    console.log("session created:" + session);
    let currentuser = await getUserByEmail("user@master.com");
    expect(currentuser.id).not.toEqual(null);
    expect(currentuser.isAdmin).toEqual(false);
    expect(currentuser.email).toEqual('user@master.com');
    expect(currentuser.password).toEqual('user');
})

test('Test_4: create admin account', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Hi, login/register to get started' })).toBeVisible();
  await page.getByRole('link', { name: 'Sign in' }).click();
  await page.getByLabel('Email').click();
  await page.getByLabel('Email').fill('master@master.com');
  await page.getByLabel('Password').click();
  await page.getByLabel('Password').fill('master');
  await page.getByRole('button', { name: 'Sign In' }).click();
  await expect(page.getByRole('heading', { name: 'Welcome, master@master.com!' })).toBeVisible();
  await page.getByRole('link', { name: 'Sign up' }).click();
  await page.getByLabel('Email').click();
  await page.getByLabel('Email').fill('123@123.com');
  await page.getByLabel('Password', { exact: true }).fill('123');
  await page.getByLabel('Confirm Password').click();
  await page.getByLabel('Confirm Password').fill('123');
  await page.getByLabel('Admin Rights').check();
  await page.getByRole('button', { name: 'Sign up' }).click();
  await expect(page.getByRole('heading', { name: 'Welcome, 123@123.com!' })).toBeVisible()
  await expect(page.getByRole('link', { name: 'Sign up' })).toHaveCount(1);
});

// newly created non-admin account test
test('Test_5: create non-admin account', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Hi, login/register to get started' })).toBeVisible();
  await page.getByRole('link', { name: 'Sign in' }).click();
  await page.getByLabel('Email').click();
  await page.getByLabel('Email').fill('master@master.com');
  await page.getByLabel('Password').click();
  await page.getByLabel('Password').fill('master');
  await page.getByRole('button', { name: 'Sign In' }).click();
  await expect(page.getByRole('heading', { name: 'Welcome, master@master.com!' })).toBeVisible();
  await page.getByRole('link', { name: 'Sign up' }).click();
  await page.getByLabel('Email').click();
  await page.getByLabel('Email').fill('1234@1234.com');
  await page.getByLabel('Password', { exact: true }).fill('1234');
  await page.getByLabel('Confirm Password').click();
  await page.getByLabel('Confirm Password').fill('1234');
  await page.getByLabel('Admin Rights').uncheck();
  await page.getByRole('button', { name: 'Sign up' }).click();
  await expect(page.getByRole('heading', { name: 'Welcome, 1234@1234.com!' })).toBeVisible()
  await expect(page.getByRole('link', { name: 'Sign up' })).toHaveCount(0);
});

test('Test_6: Fake Route should not work, will lead to',async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Hi, login/register to get started' })).toBeVisible();
  await page.getByRole('link', { name: 'Sign in' }).click();
  await page.getByLabel('Email').click();
  await page.getByLabel('Email').fill('master@master.com');
  await page.getByLabel('Password').click();
  await page.getByLabel('Password').fill('master');
  await page.getByRole('button', { name: 'Sign In' }).click();
  await expect(page.getByRole('heading', { name: 'Welcome, master@master.com!' })).toBeVisible();
  //Generate random routes
  const randomRoute = generateRandomString(10,"all");
  await page.goto(`/${randomRoute}`);
  await expect(page.getByRole('heading', { name: 'Not Found' })).toBeVisible();
});





});