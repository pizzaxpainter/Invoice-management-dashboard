import { ObjectId } from "mongodb";
import { CustomerInfo, empty_customer_info } from "$lib/models/cust_info";
import { MerchantInfo, empty_merchant_info } from "$lib/models/merch_info";

export function generateRandomString(): string {
    const charset = `0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!"#$%&'()*+, -./:;<=>?@[\]^_{|}~`;
    let randomString = '';
    for (let i = 0; i < 30; i++) {
        const randomIndex = Math.floor(Math.random() * charset.length);
        randomString += charset[randomIndex];
    }
    return randomString;
}

export function generateRandomNum(): number {
    const maximum = 1000000
    return Math.random() * maximum
}

export function generateRandomDate(): Date {
    const date_in_int = (10000000000000 * Math.random()) - 5000000000000
    return new Date(date_in_int)
}

export function generateRandomBoolean(): boolean {
    return (Math.random() > 0.5)
}

export function generateRandomArray(): any[] {
    const random_array: any[] = []
    const length = 5 //Arrays will always be this length
    for (let i = 0; i < length; i++) {
        const random_data_types: any = {
            string: generateRandomString(),
            number: generateRandomNum(),
            date: generateRandomDate(),
            boolean: generateRandomBoolean(),
            array: [],
            Object: {},
            null: null,
            undefined: undefined
        }
        random_array.push(selectIncorrectType(random_data_types, []))
    }
    return random_array
}

export function generateRandomVariable(): any {
    const random_data_types: any = {
        string: generateRandomString(),
        number: generateRandomNum(),
        date: generateRandomDate(),
        boolean: generateRandomBoolean(),
        array: generateRandomArray(),
        empty_array: [],
        Object: {},
        ObjectId: new ObjectId(),
        null: null,
        undefined: undefined
    }
    return selectIncorrectType(random_data_types, [])
}

export function shouldPropertyBeValid(): boolean {
    const cutoff = 0.7; //Probability that this property will be valid
    if (Math.random() < cutoff) { return true; }
    else return false;
}

export function shouldPropertyExist(): boolean {
    const cutoff = 0.75; //Probability that this property will be exist
    if (Math.random() < cutoff) { return true; }
    else return false;
}

export function shouldObjectNotBeObject(): boolean {
    const cutoff = 0.15; //Probability that the object will not even be an object!
    if (Math.random() < cutoff) { return true; }
    else return false;
}

export function selectIncorrectType(type_to_value_mapping: Object, correct_types: string[]): any {
    //Randomly selects an incorrect type

    const incorrect_value: any[] = []

    for (const [type, value] of Object.entries(type_to_value_mapping)) {
        if (!correct_types.includes(type)) { //If incorrect type, then append
            incorrect_value.push(value)
        }
    }

    return incorrect_value[Math.floor(Math.random() * incorrect_value.length)]
}

export function generateRandomCustomerInfo(): [any, CustomerInfo] {
    const customer_property_list = {
        customer_name: "string",
        customer_address: "string",
        customer_email: "string",
        customer_id: "string",
        customer_tax_id: "string",
        customer_mailing_address: "string",
        customer_billing_address: "string",
        customer_shipping_address: "string",
        customer_service_address: "string",
        customer_remittance_address: "string",
        abn_number: "string",
        gst_number: "string",
        pan_number: "string",
        vat_number: "string",
    }

    let obj_to_test: any = new CustomerInfo();
    let obj_to_expect = new CustomerInfo();

    //Small chance to not even return an object!
    if (shouldObjectNotBeObject()) {
        obj_to_test = generateRandomVariable();
        obj_to_expect = empty_customer_info;
    }
    else {
        for (const [property, property_type] of Object.entries(customer_property_list)) {
            const random_data_types: any = {
                string: generateRandomString(),
                number: generateRandomNum(),
                date: generateRandomDate(),
                boolean: generateRandomBoolean(),
                null: null
            }

            if (shouldPropertyBeValid()) {
                obj_to_test[property] = random_data_types[property_type];
                obj_to_expect[property as keyof CustomerInfo] = random_data_types[property_type];
            }
            else if (shouldPropertyExist()) {
                delete obj_to_test[property]
                obj_to_expect[property as keyof CustomerInfo] = null;
            }
            else {
                if (property_type === "string") {
                    obj_to_test[property] = selectIncorrectType(random_data_types, ["string"])
                    obj_to_expect[property as keyof CustomerInfo] = null;
                }
            }
        }
        obj_to_test[generateRandomString()] = generateRandomVariable() //Add a random property name
    }

    return [obj_to_test, obj_to_expect]
}

export function generateRandomMerchantInfo(): [any, MerchantInfo] {
    const merchant_property_list = {
        merchant_name: "string",
        merchant_address: "string",
        merchant_phone: "string",
        merchant_email: "string",
        merchant_fax: "string",
        merchant_website: "string",
        merchant_tax_id: "string",
        merchant_siret: "string",
        merchant_siren: "string",
        abn_number: "string",
        gst_number: "string",
        pan_number: "string",
        vat_number: "string"
    }

    let obj_to_test: any = new MerchantInfo();
    let obj_to_expect = new MerchantInfo();

    //Small chance to not even return an object!
    if (shouldObjectNotBeObject()) {
        obj_to_test = generateRandomVariable();
        obj_to_expect = empty_merchant_info;
    }
    else {
        for (const [property, property_type] of Object.entries(merchant_property_list)) {
            const random_data_types: any = {
                string: generateRandomString(),
                number: generateRandomNum(),
                date: generateRandomDate(),
                boolean: generateRandomBoolean(),
                array: [],
                null: null
            }

            if (shouldPropertyBeValid()) {
                obj_to_test[property] = random_data_types[property_type];
                obj_to_expect[property as keyof MerchantInfo] = random_data_types[property_type];
            }
            else if (shouldPropertyExist()) {
                delete obj_to_test[property]
                obj_to_expect[property as keyof MerchantInfo] = null;
            }
            else {
                if (property_type === "string") {
                    obj_to_test[property] = selectIncorrectType(random_data_types, ["string"])
                    obj_to_expect[property as keyof MerchantInfo] = null;
                }
            }
        }
        obj_to_test[generateRandomString()] = generateRandomVariable() //Add a random property name
    }

    return [obj_to_test, obj_to_expect]
}