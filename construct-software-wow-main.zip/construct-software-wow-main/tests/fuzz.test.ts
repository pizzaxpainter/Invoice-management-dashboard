import { CustomerInfo, convertToCustomerInfo, empty_customer_info } from "$lib/models/cust_info"
import { MerchantInfo, empty_merchant_info, convertToMerchantInfo } from "$lib/models/merch_info";
import { expect, test, type APIRequestContext } from "@playwright/test";
import { ObjectId } from "mongodb";
import { setCookieVals } from "./setCookieVals";
import * as Randomizer from "./random_generator"

const NUMBER_OF_TESTS_FOR_EACH = 10

//========================= START OF TESTS ====================================
let request: APIRequestContext;

test.beforeAll(async ({ browser }) => {
    const browserContext = await browser.newContext()
    const cookievals = await setCookieVals();
    browserContext.addCookies(cookievals);
    request = browserContext.request;
});

test.describe('Converting random objects to CustomerInfo', () => {
    for (let i = 0; i < NUMBER_OF_TESTS_FOR_EACH; i++) {
        test(`Testing customer_info number_${i}`, () => {
            const [obj_to_test, obj_to_expect] = Randomizer.generateRandomCustomerInfo()
            const output = convertToCustomerInfo(obj_to_test)
            expect(output).toEqual(obj_to_expect)
        })
    }
})

test.describe('Converting random objects to MerchantInfo', () => {
    for (let i = 0; i < NUMBER_OF_TESTS_FOR_EACH; i++) {
        test(`Testing merchant_info number_${i}`, () => {
            const [obj_to_test, obj_to_expect] = Randomizer.generateRandomMerchantInfo()
            const output = convertToMerchantInfo(obj_to_test)
            expect(output).toEqual(obj_to_expect)
        })
    }
})

test.describe('Bombard CustomerInfo POST API', () => {
    for (let i = 0; i < NUMBER_OF_TESTS_FOR_EACH; i++) {
        test(`Testing POST request number_${i}`, async() => {
            let obj_to_test: any = {}

            const post_property_list = {
                add_if_null: "boolean"
            }

            //Small chance to not even return an object!
            if (Randomizer.shouldObjectNotBeObject()) {
                obj_to_test = Randomizer.generateRandomVariable();
            }
            else {
                for (const [property, property_type] of Object.entries(post_property_list)) {
                    const random_data_types: any = {
                        string: Randomizer.generateRandomString(),
                        number: Randomizer.generateRandomNum(),
                        date: Randomizer.generateRandomDate(),
                        boolean: Randomizer.generateRandomBoolean(),
                        array: [],
                        null: null
                    }

                    if (Randomizer.shouldPropertyBeValid()) {
                        obj_to_test[property] = random_data_types[property_type];
                    }
                    else if (Randomizer.shouldPropertyExist()) {
                        delete obj_to_test[property]
                    }
                    else {
                        if (property_type === "string") {
                            obj_to_test[property] = Randomizer.selectIncorrectType(random_data_types, ["string"])
                        }
                        if (property_type === "boolean") {
                            obj_to_test[property] = Randomizer.selectIncorrectType(random_data_types, ["boolean"])
                        }
                    }
                }
                obj_to_test[Randomizer.generateRandomString()] = Randomizer.generateRandomVariable() //Add a random property name

                if (Randomizer.shouldPropertyExist()){ //Randomizer.generate the customerinfo with a chance
                    obj_to_test.obj = Randomizer.generateRandomCustomerInfo()[0];
                }
            }

            const response = await request.post('/api/cust_info', {data: obj_to_test});
            expect(response.status()).not.toEqual(500);
        })
    }
})

test.describe('Bombard MerchantInfo POST API', () => {

    for (let i = 0; i < NUMBER_OF_TESTS_FOR_EACH; i++) {
        test(`Testing POST request number_${i}`, async() => {
            let obj_to_test: any = {}

            const post_property_list = {
                add_if_null: "boolean"
            }

            //Small chance to not even return an object!
            if (Randomizer.shouldObjectNotBeObject()) {
                obj_to_test = Randomizer.generateRandomVariable();
            }
            else {
                for (const [property, property_type] of Object.entries(post_property_list)) {
                    const random_data_types: any = {
                        string: Randomizer.generateRandomString(),
                        number: Randomizer.generateRandomNum(),
                        date: Randomizer.generateRandomDate(),
                        boolean: Randomizer.generateRandomBoolean(),
                        array: [],
                        null: null
                    }

                    if (Randomizer.shouldPropertyBeValid()) {
                        obj_to_test[property] = random_data_types[property_type];
                    }
                    else if (Randomizer.shouldPropertyExist()) {
                        delete obj_to_test[property]
                    }
                    else {
                        if (property_type === "string") {
                            obj_to_test[property] = Randomizer.selectIncorrectType(random_data_types, ["string"])
                        }
                        if (property_type === "boolean") {
                            obj_to_test[property] = Randomizer.selectIncorrectType(random_data_types, ["boolean"])
                        }
                    }
                }
                obj_to_test[Randomizer.generateRandomString()] = Randomizer.generateRandomVariable() //Add a random property name

                if (Randomizer.shouldPropertyExist()){ //Randomizer.generate the customerinfo with a chance
                    obj_to_test.obj = Randomizer.generateRandomMerchantInfo()[0];
                }
            }

            const response = await request.post('/api/merch_info', {data: obj_to_test});
            expect(response.status()).not.toEqual(500);
        })
    }
})