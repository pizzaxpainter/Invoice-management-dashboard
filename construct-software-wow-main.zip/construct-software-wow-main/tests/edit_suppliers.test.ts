import { test, expect ,type Page} from '@playwright/test';
import { generateRandomString, setCookieVals } from './setCookieVals';
import { describe } from 'vitest';


const tempname = "testSupplier1" + await generateRandomString(15,"all")
const tempname2 = "testSupplier2" + await generateRandomString(15,"all")
const tempadress1 = 'supplier A address' + await generateRandomString(15,"all")
const tempadress2 = 'supplier B address' + await generateRandomString(15,"all")

test.describe("[Edit Supplier Functionality Testing]" ,() => {
let page: Page;


//-----------------Unit tests-----------------
test.beforeEach(async ({ browser }) => {
  const browserContext = await browser.newContext()
  const cookievals = await setCookieVals();
  browserContext.addCookies(cookievals);
  page = await browserContext.newPage()
});
// test.describe.configure({ mode: 'parallel' });

// passes
test('test:1 Add/Edit Supplier button in Welcome page', async ({}) => {
    await page.goto('/');
    await page.locator('div').filter({ hasText: /^Add\/Edit Suppliers Add\/Edit Suppliers$/ }).getByRole('link').click();
    await expect(page.getByRole('heading', { name: 'Add and Edit Suppliers Here!' })).toBeVisible();
  });

// passes
test('test:2 Add/Edit Supplier button in Navigation bar', async ({}) => {
    await page.goto('/'); 
    await page.locator('#navbarNavAltMarkup').getByRole('link', { name: 'Add/Edit Suppliers' }).click();
    await page.getByRole('heading', { name: 'Add and Edit Suppliers Here!' }).click();
});

// passes
test('test:3 [add Supplier] Dialogue pops up when address not filled', async ({}) => {
    await page.goto('/'); 
    await page.goto('/edit_merchants');
    await page.getByLabel('Supplier\'s Name').click({timeout:60000});
    await page.getByLabel('Supplier\'s Name').fill('Alice');
    page.once('dialog', async (dialog) => {
        await expect(dialog.message()).toEqual("Please fill up merchant_address");
        await dialog.accept();
    });
    await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000});
})

// Passes
test('test:4 [add Supplier] Dialogue pops up when name not filled', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_merchants');
    await page.getByLabel('Supplier\'s Address').click();
    await page.getByLabel('Supplier\'s Address').fill('SUTD');
    page.once('dialog', async (dialog) => {
        await expect(dialog.message()).toEqual("Please fill up merchant_name");
        await dialog.accept();
    });
    await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000});
})

// change the fields (supplier fields are different)
test('test:5 [add Supplier] Fill in name and address and other fields and click Compile Data button', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_merchants');
    await page.getByLabel('Supplier\'s Name').click();
    await page.getByLabel('Supplier\'s Name').fill(tempname);
    await page.getByLabel('Supplier\'s Address').click();
    await page.getByLabel('Supplier\'s Address').fill(tempadress1);
    await page.getByLabel('Supplier\'s Phone').click();
    await page.getByLabel('Supplier\'s Phone').fill('12345678');
    await page.getByLabel('Supplier\'s Email').click();
    await page.getByLabel('Supplier\'s Email').fill('sally@abc.com');
    await page.getByLabel('Supplier\'s Fax').click();
    await page.getByLabel('Supplier\'s Fax').fill('123');
    await page.getByLabel('Supplier\'s Website').click();
    await page.getByLabel('Supplier\'s Website').fill('www.sally.com');
    await page.getByLabel('Supplier\'s Tax Id').click();
    await page.getByLabel('Supplier\'s Tax Id').fill('123');
    await page.getByLabel('Supplier\'s Siret').click();
    await page.getByLabel('Supplier\'s Siret').fill('123');
    await page.getByLabel('Supplier\'s Siren').click();
    await page.getByLabel('Supplier\'s Siren').fill('123');
    await page.getByLabel('ABN Number').click();
    await page.getByLabel('ABN Number').fill('123');
    await page.getByLabel('GST Number').click();
    await page.getByLabel('GST Number').fill('123');
    await page.locator('div:nth-child(12)').click();
    await page.getByLabel('PAN Number').fill('123');
    await page.getByLabel('VAT Number').click();
    await page.getByLabel('VAT Number').fill('123');
    await page.getByRole('button', { name: 'Compile Data' }).click();
    await page.getByRole('button', { name: 'Submit to Database' }).click();
    await expect(page.getByRole('heading', { name: 'Supplier has been uploaded' })).toBeVisible({timeout:300000});
})

// change name and address to be the same as an existing merchant
test('test:6 [add Supplier] Add a merchant that has the same name and address as an existing merchant', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_merchants');
    await page.getByLabel('Supplier\'s Name').click();
    await page.getByLabel('Supplier\'s Name').fill(tempname);
    await page.getByLabel('Supplier\'s Address').click();
    await page.getByLabel('Supplier\'s Address').fill(tempadress1);
    await page.getByRole('button', { name: 'Compile Data' }).click();
    await page.getByRole('button', { name: 'Submit to Database' }).click();
    await expect(page.getByRole('heading', { name: 'Duplicate entry with same merchant name and address exists already.' })).toBeVisible(); // do I need to include this test?
}) // passes after removing mode parallel

// passes
test('test:7 [add Supplier] Add a merchant that has the same name but different address as an existing merchant', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_merchants');
    await page.getByLabel('Supplier\'s Name').click();
    await page.getByLabel('Supplier\'s Name').fill(tempname);
    await page.getByLabel('Supplier\'s Address').click();
    await page.getByLabel('Supplier\'s Address').fill(tempadress2);
    await page.getByRole('button', { name: 'Compile Data' }).click();
    await page.getByRole('button', { name: 'Submit to Database' }).click();
    await expect(page.getByRole('heading', { name: 'Supplier has been uploaded' })).toBeVisible({timeout:60000});
})

// passes
test('test:8 [add Supplier] Add a merchant that has the same address but different name as an existing merchant', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_merchants');
    await page.getByLabel('Supplier\'s Address').click();
    await page.getByLabel('Supplier\'s Address').fill(tempadress1);
    await page.getByLabel('Supplier\'s Name').click();
    await page.getByLabel('Supplier\'s Name').fill(tempname2);
    await page.getByRole('button', { name: 'Compile Data' }).click();
    await page.getByRole('button', { name: 'Submit to Database' }).click();
    await page.getByRole('heading', { name: 'Supplier has been uploaded' }).click({timeout:60000});
})

// change object id
test('test:9 [edit Suppliers] Name and address of existing Supplier are displayed', async ({}) => {
    await page.goto('/');
    await page.locator('div').filter({ hasText: /^Add\/Edit Suppliers Add\/Edit Suppliers$/ }).getByRole('link').click();
    await page.getByLabel('Options').selectOption({ label: tempname }); // supplier B
    await expect(page.getByLabel('Supplier\'s Name') && page.getByLabel('Supplier\'s Address')).not.toBe('');
})

// change object id
test('test:10 [edit Suppliers] Update another field', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_merchants');
    await page.getByLabel('Options').selectOption({ label: tempname }); // supplier B
    await page.getByLabel('Supplier\'s Email').click();
    await page.getByLabel('Supplier\'s Email').fill('abc@gmail.com');
    await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000});
    await page.getByRole('button', { name: 'Submit to Database' }).click({timeout:60000}); // error here
    await expect(page.getByRole('link', { name: 'dashboard' })).toBeVisible();
})

// change object id
test('test:11 [edit Suppliers] Delete name field and click Compile Data button', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_merchants');
    await page.getByLabel('Options').selectOption({ label: tempname });
    await page.getByLabel('Supplier\'s Name').click();
    await page.getByLabel('Supplier\'s Name').fill('');
    page.once('dialog', async (dialog) => {
        await expect(dialog.message()).toEqual("Please fill up merchant_name");
        await dialog.accept();
    });
    await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000});
})

// change object id
test('test:12 [edit Suppliers] Delete address field and click Compile Data button', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_merchants');
    await page.getByLabel('Options').selectOption({ label: tempname });
    await page.getByLabel('Supplier\'s Address').click();
    await page.getByLabel('Supplier\'s Address').fill('');
    page.once('dialog', async (dialog) => {
        await expect(dialog.message()).toEqual("Please fill up merchant_address"); // sometimes error here
        await dialog.accept();
    });
    await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000});
})

test('test:13 [delete Supplier] Delete an Supplier', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_merchants');
    await page.getByLabel('Options').selectOption({ label: tempname });
    await page.getByRole('button', { name: 'Delete Supplier' }).click({timeout:60000});
    await expect(page.getByRole('heading', { name: 'Supplier has been deleted' })).toBeVisible({timeout:60000})
    await page.goto('/edit_merchants');
    await page.getByLabel('Options').selectOption({ label: tempname });
    await page.getByRole('button', { name: 'Delete Supplier' }).click({timeout:60000});
    await expect(page.getByRole('heading', { name: 'Supplier has been deleted' })).toBeVisible({timeout:60000})
    await page.goto('/edit_merchants');
    await page.getByLabel('Options').selectOption({ label: tempname2 });
    await page.getByRole('button', { name: 'Delete Supplier' }).click({timeout:60000});
    await expect(page.getByRole('heading', { name: 'Supplier has been deleted' })).toBeVisible({timeout:60000})
})

// passes
test('test:14 [delete supplier] Delete button should not be clickable when no supplier is selected', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_merchants');    
    await page.getByLabel('Supplier\'s Name').click();
    await page.getByLabel('Supplier\'s Name').fill('Zoe');
    await expect(page.locator('form')).toBeVisible(); // expect delete button to be visible
    await expect(page.getByRole('button', { name: 'Delete supplier' })).toBeDisabled(); // expect delete button not to be clickable
})});