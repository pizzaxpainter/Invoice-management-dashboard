import { test, expect ,type Page} from '@playwright/test';
import { setCookieVals } from './setCookieVals';
//CHECK WITH RYAN
const searchDb = {}
const dbresults = {}

test.describe("[Invoice Search test]",()=>{

  let page: Page;

//-----------------Unit tests-----------------
test.beforeEach(async ({ browser }) => {
  const browserContext = await browser.newContext()
  const cookievals = await setCookieVals();
  browserContext.addCookies(cookievals);
  page = await browserContext.newPage()
});

test('test_1: Invoice Search Page Test: Search without any fields', async ({}) => {
    await page.goto('/');
    await page.goto('/invoice_search');

    await page.getByRole('button', { name: 'Search' }).click();

    await expect(page.getByText('Please enter at least one search field.')).toBeVisible();

  }); //can

  test('test_2: Invoice Search Page Test: Search with a single field', async ({}) => {
    await page.goto('/');
    await page.goto('/invoice_search');
    
    await page.getByRole('combobox').first().selectOption('supplier A');
    await page.getByRole('button', { name: 'Search' }).click();
    await expect(page.getByRole('heading', { name: 'Search Results' })).toBeVisible();
    
 });  //can


  test('test_3: Invoice Search Page Test: Add and remove additional search fields', async ({}) => {
    await page.goto('/');
    await page.goto('/invoice_search');


    await page.getByRole('button', { name: 'Add Supplier Name' }).click();

    await page.getByRole('combobox').nth(1).selectOption('supplier A');
    await page.getByRole('button', { name: 'Add Supplier Name' }).click();
    await page.getByRole('combobox').nth(2).selectOption('B');
    await page.getByRole('button', { name: 'Remove' }).nth(1).click();
    await page.getByRole('button', { name: 'Search' }).click();
    await expect(page.getByRole('heading', { name: 'Search Results' })).toBeVisible();

  });  //can

  test('test_4a: Invoice Search Page Test: Search with only one date input', async ({}) => {
    await page.goto('/');
    await page.goto('/invoice_search');


    await page.getByPlaceholder('End date').fill('2023-08-01');
    await page.getByRole('button', { name: 'Search' }).click();
    await expect(page.getByText('Both start date and end date must be provided.')).toBeVisible();
    

    await page.goto('/invoice_search');

    await page.getByPlaceholder('Start date').fill('2023-08-19');
    await page.getByRole('button', { name: 'Search' }).click();
    await expect(page.getByText('Both start date and end date must be provided.')).toBeVisible();

  });  //can

  test('test_4b: Invoice Search Page Test: Search with invalid date range', async ({}) => {
    await page.goto('/');
    await page.goto('/invoice_search');

    await page.getByPlaceholder('Start date').fill('2023-08-19');
    await page.getByPlaceholder('End date').fill('2023-08-01');
    await page.getByRole('button', { name: 'Search' }).click();
    await expect(page.getByText('Invalid date range. Start date must be before or equal to end date.')).toBeVisible();
    
  });  //can

    // Test Case 5a: Perform search with valid parameters and verify results.
  test('test_5a: Perform search with valid parameters and verify results', async ({}) => {
    await page.goto('/');
    await page.goto('/invoice_search');
   
    await page.getByRole('combobox').first().selectOption('supplier A');
    await page.getByPlaceholder('Start date').fill('2021-10-16');
    await page.getByPlaceholder('End date').fill('2021-10-30');
    await page.getByRole('button', { name: 'Search' }).click();
   
    await expect(page.getByRole('heading', { name: 'Search Results' })).toBeVisible();
  });

  // Test case 5b: Perform search with valid parameters and verify No results message.
  test('test_5b: Perform search with valid parameters and verify results ==> No results', async ({}) => {
    await page.goto('/');
    await page.goto('/invoice_search');   

    await page.getByRole('combobox').first().selectOption('supplier A');
    await page.getByPlaceholder('Start date').fill('2021-10-16');
    await page.getByPlaceholder('End date').fill('2021-10-30');
    await page.getByRole('button', { name: 'Search' }).click();
   
    await expect(page.getByRole('heading', { name: 'Search Results' })).toBeVisible();
  });

  // Test Case 6: Export selected invoices to CSV.
  test('test_6: Export selected invoices to CSV', async ({}) => {
    await page.goto('/');
    await page.goto('/invoice_search');

    //regular search
    await page.getByRole('combobox').first().selectOption('supplier A');
    await page.getByPlaceholder('Start date').fill('2000-01-01');
    await page.getByPlaceholder('End date').fill('2023-08-31');

    //Search
    await page.getByRole('button', { name: 'Search' }).click();
    await page.locator('.form-check-input').first().check();
    await page.locator('div:nth-child(5) > .form-check-input').check();
    await page.locator('div:nth-child(6) > .form-check-input').check();
    const downloadPromise = page.waitForEvent('download');
    await expect(page.getByRole('button', { name: 'Export to CSV' })).toBeVisible();
    await page.getByRole('button', { name: 'Export to CSV' }).click();
    const download = await downloadPromise;

  });

  test('test_7: Invoice Search Page Test: Export to CSV with One Invoice Selected', async ({}) => {
    await page.goto('/');
    await page.goto('/invoice_search');
    
    await page.goto('/');
    await page.goto('/invoice_search');

    //regular search
    await page.getByRole('combobox').first().selectOption('supplier A');
    await page.getByPlaceholder('Start date').fill('2000-01-01');
    await page.getByPlaceholder('End date').fill('2023-08-31');

    //Search
    await page.getByRole('button', { name: 'Search' }).click();
    await page.locator('.form-check-input').first().check();

    const downloadPromise = page.waitForEvent('download');
    await expect(page.getByRole('button', { name: 'Export to CSV' })).toBeVisible();
    await page.getByRole('button', { name: 'Export to CSV' }).click();
    const download = await downloadPromise;
  });
  
    //Test 8: Export button should not be visible
    test('test_8: Invoice Search Page Test: Export to CSV with No Invoice Selected', async ({}) => {
      await page.goto('/');
      await page.goto('/invoice_search');

      await page.getByRole('combobox').first().selectOption('supplier A');
    await page.getByPlaceholder('Start date').fill('2000-01-01');
    await page.getByPlaceholder('End date').fill('2023-08-31');

    //Search
    await page.getByRole('button', { name: 'Search' }).click();

    await expect(page.getByRole('button', { name: 'Export to CSV' })).toBeHidden();

      });
    
    test('test_9: Invoice Search Page Test: Click on Invoice Details', async ({}) => {
    await page.goto('/');
    await page.goto('/invoice_search');
    
    await page.getByPlaceholder('Start date').fill('2000-01-01');
    await page.getByPlaceholder('End date').fill('2023-08-31');
    await page.getByRole('button', { name: 'Search' }).click();
    const page1Promise = page.waitForEvent('popup');
    await page.getByRole('button', { name: 'Click to view invoice invoiceslugs#123', exact: true }).click();
    const page1 = await page1Promise;
    await expect(page1.getByRole('heading', { name: 'Invoice Details' })).toBeVisible();
  });




  // use case 10: enter Dashboard ⇢ Enter Invoice Upload page + login first
test('test_10: Dashboard to Upload Search page', async ({}) => {
  await page.goto('/');
  await page.locator('#navbarNavAltMarkup').getByRole('link', { name: 'Invoice Search' }).click();
  await expect(page.getByRole('heading', { name: 'Invoice Search' })).toBeVisible();
})










});