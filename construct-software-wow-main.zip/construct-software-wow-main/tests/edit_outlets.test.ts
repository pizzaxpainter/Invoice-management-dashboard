import { test, expect ,type Page} from '@playwright/test';
import { setCookieVals } from './setCookieVals';
import { generateRandomString } from './setCookieVals';



const tempname = "testOutlet1" + await generateRandomString(15,"all")
const tempname2 = "testOutlet2" + await generateRandomString(15,"all")
const tempadress1 = 'outlet A address' + await generateRandomString(15,"all")
const tempadress2 = 'outlet B address'+ await generateRandomString(15,"all")

test.describe("[Edit Outlets Functionality Testing]" ,() => {
let page: Page;


//-----------------Unit tests-----------------
test.beforeEach(async ({ browser }) => {
  const browserContext = await browser.newContext()
  const cookievals = await setCookieVals();
  browserContext.addCookies(cookievals);
  page = await browserContext.newPage()
});
// test.describe.configure({ mode: 'parallel' });

// passes
test('test:1 Add/Edit Outlet button in Welcome page', async ({}) => {
    await page.goto('/');
    await page.locator('div').filter({ hasText: /^Add\/Edit Outlets Add\/Edit Outlets$/ }).getByRole('link').click();
    await expect(page.getByRole('heading', { name: 'Add and Edit Outlets Here!' })).toBeVisible();
  });

// passes
test('test:2 Add/Edit Outlet button in Navigation bar', async ({}) => {
    await page.goto('/'); 
    await page.locator('#navbarNavAltMarkup').getByRole('link', { name: 'Add/Edit Outlets' }).click();
    await page.getByRole('heading', { name: 'Add and Edit Outlets Here!' }).click();
});

// passes
test('test:3 [add outlet] Dialogue pops up when address not filled', async ({}) => {
    await page.goto('/'); 
    await page.goto('/edit_customers');
    await page.getByLabel('Outlet\'s Name').click({timeout:60000});
    await page.getByLabel('Outlet\'s Name').fill('Alice');
    page.once('dialog', async (dialog) => {
        await expect(dialog.message()).toEqual("Please fill up customer_address");
        await dialog.accept();
    });
    await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000});
})

// Passes
test('test:4 [add outlet] Dialogue pops up when name not filled', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_customers');
    await page.getByLabel('Outlet\'s Address').click();
    await page.getByLabel('Outlet\'s Address').fill('SUTD');
    page.once('dialog', async (dialog) => {
        await expect(dialog.message()).toEqual("Please fill up customer_name");
        await dialog.accept();
    });
    await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000});
})

// passes
test('test:5 [add outlet] Fill in name and address and other fields and click Compile Data button', async ({}) => {
    // await page.getByLabel('Options').selectOption({ label: tempname });
    await page.goto('/');
    await page.goto('/edit_customers');
    await page.getByLabel('Outlet\'s Name').click();
    await page.getByLabel('Outlet\'s Name').fill(tempname);
    await page.getByLabel('Outlet\'s Address').click();
    await page.getByLabel('Outlet\'s Address').fill(tempadress1);
    await page.getByLabel('Outlet\'s Email').click();
    await page.getByLabel('Outlet\'s Email').fill('sally@abc.com');
    await page.getByLabel('Outlet\'s Id').click();
    await page.getByLabel('Outlet\'s Id').fill('1005123');
    await page.getByLabel('Outlet\'s Tax Id').click();
    await page.getByLabel('Outlet\'s Tax Id').fill('123');
    await page.getByLabel('Outlet\'s Mailing Address').click();
    await page.getByLabel('Outlet\'s Mailing Address').fill('sutd');
    await page.getByLabel('Outlet\'s Billing Address').click();
    await page.getByLabel('Outlet\'s Billing Address').fill('sutd');
    await page.getByLabel('Outlet\'s Shipping Address').click();
    await page.getByLabel('Outlet\'s Shipping Address').fill('sutd');
    await page.getByLabel('Outlet\'s Service Address').click();
    await page.getByLabel('Outlet\'s Service Address').fill('sutd');
    await page.getByLabel('Outlet\'s Remittance Address').click();
    await page.getByLabel('Outlet\'s Remittance Address').fill('sutd');
    await page.getByLabel('ABN Number').click();
    await page.getByLabel('ABN Number').fill('123');
    await page.getByLabel('GST Number').click();
    await page.getByLabel('GST Number').fill('123');
    await page.getByLabel('PAN Number').click();
    await page.getByLabel('PAN Number').fill('123');
    await page.getByLabel('VAT Number').click();
    await page.getByLabel('VAT Number').fill('123');
    await page.getByRole('button', { name: 'Compile Data' }).click();
    await page.getByRole('button', { name: 'Submit to Database' }).click();
    await expect(page.getByRole('heading', { name: 'Outlet has been uploaded' })).toBeVisible({timeout:300000});
})

// passes
test('test:6 [add outlet] Add a customer that has the same name and address as an existing customer', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_customers');
    await page.getByLabel('Outlet\'s Name').click();
    await page.getByLabel('Outlet\'s Name').fill(tempname);
    await page.getByLabel('Outlet\'s Address').click();
    await page.getByLabel('Outlet\'s Address').fill(tempadress1);
    await page.getByRole('button', { name: 'Compile Data' }).click();
    await page.getByRole('button', { name: 'Submit to Database' }).click();
    await expect(page.getByRole('heading', { name: 'Duplicate entry with same customer name and address exists already.' })).toBeVisible(); // do I need to include this test?
}) // passes after removing mode parallel

// passes
test('test:7 [add outlet] Add a customer that has the same name but different address as an existing customer', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_customers');
    await page.getByLabel('Outlet\'s Name').click();
    await page.getByLabel('Outlet\'s Name').fill(tempname);
    await page.getByLabel('Outlet\'s Address').click();
    await page.getByLabel('Outlet\'s Address').fill(tempadress2);
    await page.getByRole('button', { name: 'Compile Data' }).click();
    await page.getByRole('button', { name: 'Submit to Database' }).click();
    await expect(page.getByRole('heading', { name: 'Outlet has been uploaded' })).toBeVisible({timeout:60000});
})

// passes
test('test:8 [add outlet] Add a customer that has the same address but different name as an existing customer', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_customers');
    await page.getByLabel('Outlet\'s Address').click();
    await page.getByLabel('Outlet\'s Address').fill(tempadress1);
    await page.getByLabel('Outlet\'s Name').click();
    await page.getByLabel('Outlet\'s Name').fill(tempname2);
    await page.getByRole('button', { name: 'Compile Data' }).click();
    await page.getByRole('button', { name: 'Submit to Database' }).click();
    await page.getByRole('heading', { name: 'Outlet has been uploaded' }).click({timeout:60000});
})

// passes
test('test:9 [edit outlets] Name and address of existing outlet are displayed', async ({}) => {
    await page.goto('/');
    await page.locator('div').filter({ hasText: /^Add\/Edit Outlets Add\/Edit Outlets$/ }).getByRole('link').click();
    await page.getByLabel('Options').selectOption({ label: tempname });
    await expect(page.getByLabel('Outlet\'s Name') && page.getByLabel('Outlet\'s Address')).not.toBe('');
})

// passes
test('test:10 [edit outlets] Update another field', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_customers');
    await page.getByLabel('Options').selectOption({ label: tempname });
    await page.getByLabel('Outlet\'s Email').click();
    await page.getByLabel('Outlet\'s Email').fill('abc@gmail.com');
    await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000});
    await page.getByRole('button', { name: 'Submit to Database' }).click({timeout:60000}); // error here
    await expect(page.getByRole('link', { name: 'dashboard' })).toBeVisible();
})

// passes
test('test:11 [edit outlets] Delete name field and click Compile Data button', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_customers');
    await page.getByLabel('Options').selectOption({ label: tempname });
    await page.getByLabel('Outlet\'s Name').click();
    await page.getByLabel('Outlet\'s Name').fill('');
    page.once('dialog', async (dialog) => {
        await expect(dialog.message()).toEqual("Please fill up customer_name");
        await dialog.accept();
    });
    await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000});
})

// passes
test('test:12 [edit outlets] Delete address field and click Compile Data button', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_customers');
    await page.getByLabel('Options').selectOption({ label: tempname });
    await page.getByLabel('Outlet\'s Address').click();
    await page.getByLabel('Outlet\'s Address').fill('');
    page.once('dialog', async (dialog) => {
        await expect(dialog.message()).toEqual("Please fill up customer_address"); // sometimes error here
        await dialog.accept();
    });
    await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000});
})


test('test:13 [delete outlet] Delete the test outlets', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_customers');
    await page.getByLabel('Options').selectOption({ label: tempname });
    await page.getByRole('button', { name: 'Delete Outlet' }).click({timeout:60000});
    await expect(page.getByRole('heading', { name: 'Outlet has been deleted' })).toBeVisible({timeout:60000})
    await page.goto('/edit_customers');
    await page.getByLabel('Options').selectOption({ label: tempname });
    await page.getByRole('button', { name: 'Delete Outlet' }).click({timeout:60000});
    await expect(page.getByRole('heading', { name: 'Outlet has been deleted' })).toBeVisible({timeout:60000})
    await page.goto('/edit_customers');
    await page.getByLabel('Options').selectOption({ label: tempname2 });
    await page.getByRole('button', { name: 'Delete Outlet' }).click({timeout:60000});
    await expect(page.getByRole('heading', { name: 'Outlet has been deleted' })).toBeVisible({timeout:60000})
})

// passes
test('test:14 [delete outlet] Delete button should not be clickable when no outlet is selected', async ({}) => {
    await page.goto('/');
    await page.goto('/edit_customers');    
    await page.getByLabel('Outlet\'s Name').click();
    await page.getByLabel('Outlet\'s Name').fill('Zoe');
    await expect(page.locator('form')).toBeVisible(); // expect delete button to be visible
    await expect(page.getByRole('button', { name: 'Delete Outlet' })).toBeDisabled(); // expect delete button not to be clickable
})});


