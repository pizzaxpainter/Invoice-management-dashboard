import { test, expect ,type Page} from '@playwright/test';
import { generateRandomString } from './setCookieVals';
import { all } from 'axios';
import { setCookieVals } from './setCookieVals';

let page: Page;

//-----------------Unit tests-----------------
test.beforeEach(async ({ browser }) => {
  const browserContext = await browser.newContext()
  const cookievals = await setCookieVals();
  browserContext.addCookies(cookievals);
  page = await browserContext.newPage()
});



function seeItems() {
    console.log("firstInvoiceId is", firstInvoiceId)
    console.log("secondInvoiceId is", secondInvoiceId)
}

// to edit on testing "branch"
const testCustomerId = '64d0c878e88df78fbc7c59ef'
const testMerchantId = '64d0c86ae88df78fbc7c59ee'



let firstInvoiceId 
let secondInvoiceId 
const randomval = await generateRandomString(30,"all")
const firstInvoiceNumber = randomval+'invoiceslugs#123' 
const secondInvoiceNumber = randomval+'invoiceslugs#123A' 


test('Init sequence: Creating 2 invoices with same supplier and different invoice number', async ({ }) => {
    test.setTimeout(120000);
    // first invoice creation
    await page.goto('/invoice_upload');
    // // const newString = page.url().split("/").slice(-1)[0]
    // // console.log(newString)
    // await page.getByRole('textbox').click();
    await page.getByRole('textbox').setInputFiles('tests/sample_files/Nam Wan Tea.pdf',{timeout:600000});
    await page.getByRole('button', { name: 'Upload to OCR software' }).click();
    await expect(page.getByRole('heading', { name: 'OCR Result' })).toBeVisible({timeout:60000})
    await page.getByLabel('Invoice Number').fill(firstInvoiceNumber);
    await page.getByLabel('Options').selectOption(testCustomerId);
    await page.locator('#selectFromList').nth(1).selectOption(testMerchantId);
    await page.getByRole('button', { name: 'Compile Data' }).click();
    await page.getByRole('button', { name: 'Submit to Database' }).click();
    await expect(page.getByRole('heading', { name: 'Invoice Submitted' })).toBeVisible({timeout:60000})
    // get invoice id of newly created invoice and store it in firstInvoiceId
    await page.getByRole('link', { name: 'Check out your recently uploaded invoice!' }).click();
    await new Promise(r => setTimeout(r, 2000));
    firstInvoiceId = page.url().split("/").slice(-1)[0]
    console.log("first invoice created")

    await page.goto('/invoice_upload');
    await page.getByRole('textbox').setInputFiles('tests/sample_files/Nam Wan Tea.pdf',{timeout:600000});
    await page.getByRole('button', { name: 'Upload to OCR software' }).click();
    await expect(page.getByRole('heading', { name: 'OCR Result' })).toBeVisible({timeout:60000})
    await page.getByLabel('Invoice Number').fill(secondInvoiceNumber);
    await page.getByLabel('Options').selectOption('64d0c878e88df78fbc7c59ef');
    await page.locator('#selectFromList').nth(1).selectOption('64d0c86ae88df78fbc7c59ee');
    await page.getByRole('button', { name: 'Compile Data' }).click();
    await page.getByRole('button', { name: 'Submit to Database' }).click();
    await expect(page.getByRole('heading', { name: 'Invoice Submitted' })).toBeVisible({timeout:60000})
    // here to get invoice id of newly created invoice and store it in secondInvoiceId
    await page.getByRole('link', { name: 'Check out your recently uploaded invoice!' }).click();
    await new Promise(r => setTimeout(r, 2000));
    secondInvoiceId = page.url().split("/").slice(-1)[0]
    console.log("second invoice created")
})

test('Unit Test 1 and 2: Invoice Page --> Both Edit and Delete buttons enabled & viewable --> Compile --> Both buttons are disabled & viewable', async ({}) => {
    // seeItems()
    const invoiceIdToCheck = firstInvoiceId
    await page.goto('/invoice_search/invoice/' + invoiceIdToCheck);
    await new Promise(r => setTimeout(r, 1000));
    
    await expect(page.getByRole('button', { name: 'Edit Invoice' })).toBeVisible({timeout:60000})
    await expect(page.getByRole('button', { name: 'Edit Invoice' })).toBeEnabled()
    await expect(page.getByRole('button', { name: 'Delete Invoice' })).toBeVisible()
    await expect(page.getByRole('button', { name: 'Delete Invoice' })).toBeEnabled()
    
    await page.getByRole('button', { name: 'Compile Data' }).click();
    await new Promise(r => setTimeout(r, 1000));
    await expect(page.getByRole('button', { name: 'Edit Invoice' })).toBeDisabled({timeout:60000})
    await expect(page.getByRole('button', { name: 'Delete Invoice' })).toBeDisabled()
})

test('Unit test 3: Invoice Page --> input fields are disabled and not editable --> "Edit Invoice" clicked --> input fields are enabled and editable', async ({ }) => {
    // seeItems()
    const invoiceIdToCheck = firstInvoiceId
    await page.goto('/invoice_search/invoice/' + invoiceIdToCheck);
    await new Promise(r => setTimeout(r, 1000));
    await expect(page.getByRole('heading', { name: 'Invoice Details' })).toBeVisible({timeout:60000})
    
    await expect(page.getByLabel('Invoice Total')).toBeDisabled()
    await expect(page.getByLabel('Invoice Total')).not.toBeEditable()
    
    await page.getByRole('button', { name: 'Edit Invoice' }).click();
    await new Promise(r => setTimeout(r, 1000));
    await expect(page.getByRole('button', { name: 'Finish Edit' })).toBeVisible({timeout:60000})
    await expect(page.getByLabel('Invoice Total')).toBeEnabled()
    await expect(page.getByLabel('Invoice Total')).toBeEditable()
})

test('Integration test 1: Invoice Page --> edit "Invoice Total" field --> Compile and Submit --> upload success --> Page Invoice --> change observed', async ({ }) => {
    // seeItems()
    const invoiceIdToCheck = firstInvoiceId
    await page.goto('/invoice_search/invoice/' + invoiceIdToCheck);
    await new Promise(r => setTimeout(r, 1000));
    await expect(page.getByRole('heading', { name: 'Invoice Details' })).toBeVisible({timeout:60000})

    await page.getByRole('button', { name: 'Edit Invoice' }).click();
    await new Promise(r => setTimeout(r, 1000));
    await page.getByLabel('Invoice Total').click();
    await page.getByLabel('Invoice Total').fill('123');
    await page.getByRole('button', { name: 'Compile Data' }).click();
    await new Promise(r => setTimeout(r, 1000));
    await page.getByRole('button', { name: 'Submit to Database' }).click();
    await new Promise(r => setTimeout(r, 1000));
    await expect(page.getByRole('heading', { name: 'Invoice Submitted' })).toBeVisible({timeout:60000})

    await page.getByRole('link', { name: 'Check out your recently uploaded invoice!' }).click();
    await new Promise(r => setTimeout(r, 1000));
    await expect(page.getByRole('heading', { name: 'Invoice Details' })).toBeVisible({timeout:60000})
    // check url link is referencing the same invoiceId
    await expect(page).toHaveURL(new RegExp('/'+invoiceIdToCheck+'$'))
    await expect(page.getByLabel('Invoice Total')).toHaveValue("123")
})

test('Integration test 2: Invoice Page --> change "Invoice Number" field to that of an existing invoice --> Compile and Submit --> error of duplicate invoice shown', async ({ }) => {
    // seeItems()
    const invoiceIdToCheck = firstInvoiceId
    await page.goto('/invoice_search/invoice/' + invoiceIdToCheck);
    await new Promise(r => setTimeout(r, 1000));
    await expect(page.getByRole('heading', { name: 'Invoice Details' })).toBeVisible({timeout:60000})

    await page.getByRole('button', { name: 'Edit Invoice' }).click();
    await new Promise(r => setTimeout(r, 1000));
    await page.getByLabel('Invoice Total').click();
    await page.getByLabel('Invoice Number').fill(secondInvoiceNumber);
    await page.getByRole('button', { name: 'Compile Data' }).click();
    await new Promise(r => setTimeout(r, 1000));
    await page.getByRole('button', { name: 'Submit to Database' }).click();
    await new Promise(r => setTimeout(r, 1000));
    await expect(page.getByRole('heading', { name: 'Duplicate invoice with same merchant information and invoice number detected. Can\'t edit to this.' })).toBeVisible()
})

test('Unit test 4: Invoice Page --> "Delete Invoice" clicked --> invoice deleted', async ({ }) => {
    const invoiceIdToCheck = firstInvoiceId
    await page.goto('/invoice_search/invoice/' + invoiceIdToCheck);
    await new Promise(r => setTimeout(r, 1000));
    await expect(page.getByRole('heading', { name: 'Invoice Details' })).toBeVisible({timeout:60000})

    await page.getByRole('button', { name: 'Delete invoice' }).click();
    await new Promise(r => setTimeout(r, 1000));
    await expect(page.getByRole('heading', { name: 'Invoice has been deleted' })).toBeVisible()
    console.log("first invoice deleted")
})

test('Shutdown sequence: deleting 2nd invoice', async ({ }) => {
    await page.goto('/invoice_search/invoice/' + secondInvoiceId);
    await new Promise(r => setTimeout(r, 1000));
    await expect(page.getByRole('heading', { name: 'Invoice Details' })).toBeVisible({timeout:60000})

    await page.getByRole('button', { name: 'Delete invoice' }).click();
    await new Promise(r => setTimeout(r, 1000));
    await expect(page.getByRole('heading', { name: 'Invoice has been deleted' })).toBeVisible()
    console.log("second invoice deleted")
})
