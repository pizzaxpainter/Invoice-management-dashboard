import { test, expect ,type Page} from '@playwright/test';
import { error, json } from '@sveltejs/kit';
import { actions} from '../src/routes/invoice_upload/+page.server';
import { groupProperties } from 'src/routes/invoice_upload/InvoiceUploadFunctions';
import { chromium } from '@playwright/test';
import { errorListObject } from "../src/routes/invoice_upload/InvoiceUploadFunctions";
import { setCookieVals } from './setCookieVals';


test.describe("[Upload Invoice Integration Testing]" ,() => {
let page: Page;

//-----------------Unit tests-----------------
test.beforeEach(async ({ browser }) => {
  const browserContext = await browser.newContext()
  const cookievals = await setCookieVals();
  browserContext.addCookies(cookievals);
  page = await browserContext.newPage()
});


//Update these IDS if the database is purged

const OutletID = '64d0c878e88df78fbc7c59ef';
const SupplierID = '64d0c86ae88df78fbc7c59ee';

function generateRandomString(length,type) {
    let charset;
    if(type == "all"){
       charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    }else{
      charset = "1234567890"
    }
    let randomString = '';
    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * charset.length);
      randomString += charset[randomIndex];
    }
    return randomString;
  }
  

//-----------------Integration tests-----------------


test('Integration_test_1: File --> OCR API --> View invoice --> Compile --> Submission API --> Submission Success', async ({}) => {
    test.setTimeout(120000);
    const temporaryInvoiceID = "##TestingInvoiceUploadIntegration##" + generateRandomString(30,"all");
    await page.goto('/');
    await page.goto('/invoice_upload');
    await page.getByRole('textbox').click({timeout:60000} );
  
    await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
    await page.getByRole('button', { name: 'Upload to OCR software' }).click({timeout:60000} );
    await expect(page.getByRole('heading', { name: 'OCR Result' })).toBeVisible({timeout:60000})
    await expect(page.getByRole('heading', { name: 'Click me to see image of invoice' })).toBeVisible({timeout:60000})
  
    await page.getByLabel('Invoice Number').click();
    await page.getByLabel('Invoice Number').fill(temporaryInvoiceID);
  
    //Prepare the invoice page and compile 
    await page.getByLabel('Options').selectOption(OutletID);
    await page.locator('#selectFromList').nth(1).selectOption(SupplierID);
    await page.getByLabel('Date', { exact: true }).fill('3012-03-12');
    await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000} );
    await expect(page.getByRole('button', { name: 'Submit to Database' })).toBeVisible({timeout:60000});
  
    // Submit Invoice
    await page.getByRole('button', { name: 'Submit to Database' }).click({timeout:60000});
    await expect(page.getByRole('heading', { name: 'Navigation to other pages' })).toBeVisible({timeout:60000});
    const newExtension = await page.evaluate(() => window.location.pathname);
    await expect(newExtension).toBe('/upload_confirmation');
  
    });
  
  
  test('Integration_test_2: File --> OCR API --> View invoice --> Edit Invoice --> Compile --> Submission API --> Submission Success', async ({ }) => {
    test.setTimeout(120000);
    const temporaryInvoiceID = "##TestingInvoiceUploadIntegration##" + generateRandomString(30,"all");
    await page.goto('/');
    await page.goto('/invoice_upload');
    await page.getByRole('textbox').click({timeout:60000} );
  
    await page.getByRole('textbox').setInputFiles('tests/sample_files/tempImage.png',{timeout:600000});
    await page.getByRole('button', { name: 'Upload to OCR software' }).click({timeout:60000} );
    await expect(page.getByRole('heading', { name: 'OCR Result' })).toBeVisible({timeout:60000})
    await expect(page.getByRole('heading', { name: 'Click me to see image of invoice' })).toBeVisible({timeout:60000})
  
    await page.getByLabel('Invoice Number').click();
    await page.getByLabel('Invoice Number').fill(temporaryInvoiceID);
  
    //Edit values randomly 
    await page.getByRole('button', { name: 'Add item' }).nth(1).click({timeout:60000} );
    await page.locator('[id="\\35 \\,description"]').fill(generateRandomString(10,"all"));
    await page.locator('[id="\\35 \\,quantity"]').fill(generateRandomString(5,"nums"));
    await page.getByRole('row', { name: '6' }).getByRole('spinbutton').nth(1).fill(generateRandomString(5,"nums"));
    await page.locator('[id="\\35 \\,unit_price"]').fill(generateRandomString(5,"nums"));
    await page.locator('[id="\\35 \\,discount"]').fill(generateRandomString(5,"nums"));
    await page.locator('[id="\\35 \\,product_code"]').fill(generateRandomString(5,"nums"));
    await page.locator('[id="\\35 \\,date_item"]').fill(generateRandomString(5,"nums"));
    await page.locator('[id="\\35 \\,tax_item"]').fill(generateRandomString(5,"nums"));
    await page.locator('[id="\\35 \\,tax_rate"]').fill(generateRandomString(5,"nums"));
  
  
    //Prepare the invoice page and compile 
    await page.getByLabel('Options').selectOption(OutletID);
    await page.locator('#selectFromList').nth(1).selectOption(SupplierID);
    await page.getByLabel('Date', { exact: true }).fill('3012-03-12');
    await page.getByRole('button', { name: 'Compile Data' }).click({timeout:60000} );
    await expect(page.getByRole('button', { name: 'Submit to Database' })).toBeVisible({timeout:60000});
  
    // Submit Invoice
    await page.getByRole('button', { name: 'Submit to Database' }).click({timeout:60000});
    await expect(page.getByRole('heading', { name: 'Navigation to other pages' })).toBeVisible({timeout:60000});
    const newExtension = await page.evaluate(() => window.location.pathname);
    await expect(newExtension).toBe('/upload_confirmation');
  });
});
  